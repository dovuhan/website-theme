<?php 

/*
=============================*/
/*
 = Custom Post Type Resgister
/*=============================*/

add_action( 'init', 'iori_job_listing_init' );

function iori_job_listing_init() {

	$labels = array(
		'name'               => _x( 'Job Listing', 'post type general name', 'iori' ),
		'singular_name'      => _x( 'Job Listing', 'post type singular name', 'iori' ),
		'menu_name'          => __( 'Job Listing', 'iori' ),
		'name_admin_bar'     => __( 'Job Listing', 'iori' ),
		'add_new'            => __( 'Add New', 'iori' ),
		'add_new_item'       => __( 'Add New Listing', 'iori' ),
		'new_item'           => __( 'New Listing', 'iori' ),
		'edit_item'          => __( 'Edit Listing', 'iori' ),
		'view_item'          => __( 'View Listing', 'iori' ),
		'all_items'          => __( 'All Job Posts', 'iori' ),
		'search_items'       => __( 'Search Listings', 'iori' ),
		'parent_item_colon'  => __( 'Parent Listings:', 'iori' ),
		'not_found'          => __( 'No Listings found.', 'iori' ),
		'not_found_in_trash' => __( 'No Listings found in Trash.', 'iori' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => true,
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => true,
		'menu_position'      => null,
		'taxonomies'         => array( 'post_tag' ),
		'menu_icon'          => 'dashicons-admin-post',
		'supports'           => array( 'comments', 'title', 'editor', 'thumbnail' ),
	);

	register_post_type( 'job_listing', $args );
}

/*
 Texonomy
=====================================================*/

function create_iori_job_listing_taxonomies() {
	$labels = array(
		'name'                  => _x( 'Job Listing', 'Taxonomy plural name', 'iori' ),
		'singular_name'         => _x( 'Job Listing Cat', 'Taxonomy singular name', 'iori' ),
		'search_items'          => __( 'Search Job Listing Cat', 'iori' ),
		'popular_items'         => __( 'Popular Job Listing Cat', 'iori' ),
		'all_items'             => __( 'All Categories', 'iori' ),
		'parent_item'           => __( 'Parent Job Listing', 'iori' ),
		'parent_item_colon'     => __( 'Parent Job Listing Cat', 'iori' ),
		'edit_item'             => __( 'Edit Job Listing Cat', 'iori' ),
		'update_item'           => __( 'Update Job Listing Cat', 'iori' ),
		'add_new_item'          => __( 'Add New Category', 'iori' ),
		'new_item_name'         => __( 'New Job Listing Menu Name', 'iori' ),
		'add_or_remove_items'   => __( 'Add or remove Job Listing', 'iori' ),
		'choose_from_most_used' => __( 'Choose from most used text-domain', 'iori' ),
		'menu_name'             => __( 'Job Listing Cat', 'iori' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => true,
		'hierarchical'      => true,
		'show_tagcloud'     => true,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => true,
		'query_var'         => true,
		'capabilities'      => array(),
	);

	register_taxonomy( 'job_listing_tax', array( 'job_listing' ), $args );
}

add_action( 'init', 'create_iori_job_listing_taxonomies' );
