<?php

/**
 * Plugin Name: Iori Master
 * Description: Iori Master is a recommanded plugin for Iori theme. Theme and plugin Developed By xstheme team.
 * Plugin URI: http://jthemes.org
 * Author: jThemes
 * Author URI: http://jthemes.org
 * Version: 1.0.7
 * License: GPL3
 * Text Domain: iori
 * Elementor requires at least: 3.0
 * Elementor tested up to: 3.20.3
 */

/*
Copyright (C) 2020

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
define( 'IORI_PLG_URL', plugin_dir_url( __FILE__ ) );
define( 'IORI_PLG_DIR', dirname( __FILE__ ) );
define( 'IORI_ACTIVE_SHORTCODE', false ); // default false
define( 'IORI_ACTIVE_LIGHT_THEME', true ); // default false

/**
 * Required supporting tile
 */
require_once IORI_PLG_DIR . '/demo-importer/one-click-installer.php';
require_once IORI_PLG_DIR . '/framework/framework.php';
require_once IORI_PLG_DIR . '/elementor-blocks/init.php';
require_once IORI_PLG_DIR . '/elementor-blocks/elementor.php';
require_once IORI_PLG_DIR . '/gutenberg-blocks/blocks.php';
require_once IORI_PLG_DIR . '/custom-posttype.php';

/**
 * register custom widget for iori
 *
 * Widgets
 * ===========================================================
 */
require_once IORI_PLG_DIR . '/widgets/class-widget-wph.php';

/**
 * Some helpfull funcitons
 * =========================
 */
if ( ! function_exists( 'iori_compress' ) ) {

	function iori_compress( $variable ) {
		return base64_encode( $variable );
	}
}

if ( ! function_exists( 'iori_get_file' ) ) {

	function iori_get_file( $variable ) {
		return file_get_contents( $variable );
	}
}

if ( ! function_exists( 'iori_decompress' ) ) {

	function iori_decompress( $variable ) {
		return base64_decode( $variable );
	}
}

/**
 * Getting help form woo mart theme
 */
if ( ! function_exists( 'iori_get_svg' ) ) {

	function iori_get_svg( $file ) {
		if ( ! apply_filters( 'iori_svg_cache', true ) ) {
			return file_get_contents( $file );
		}

		$file_path = array_reverse( explode( '/', $file ) );
		$slug      = 'wdm-svg-' . $file_path[2] . '-' . $file_path[1] . '-' . $file_path[0];
		$content   = get_transient( $slug );

		if ( ! $content ) {
			$file_get_contents = file_get_contents( $file );

			if ( strstr( $file_get_contents, '<svg' ) ) {
				$content = iori_compress( $file_get_contents );
				set_transient( $slug, $content, apply_filters( 'iori_svg_cache_time', 60 * 60 * 24 * 7 ) );
			}
		}

		return iori_decompress( $content );
	}
}

/**
 *  Enable the use of shortcodes in text widgets.
 */
add_filter( 'widget_text', 'do_shortcode' );

/**
 * If php core function 'getallheaders' not exist
 * This could be usefull for ngnix
 *
 * ref https://www.php.net/manual/en/function.getallheaders.php
 */
if ( ! function_exists( 'getallheaders' ) ) {

	function getallheaders() {
		$headers = array();
		foreach ( $_SERVER as $name => $value ) {
			if ( substr( $name, 0, 5 ) == 'HTTP_' ) {
				$headers[ str_replace( ' ', '-', ucwords( strtolower( str_replace( '_', ' ', substr( $name, 5 ) ) ) ) ) ] = $value;
			}
		}
		return $headers;
	}
}

/**
 * Its Request pjax helpful for nginx
 */
if ( ! function_exists( 'iori_is_pjax' ) ) {

	function iori_is_pjax() {
		$headers_req = function_exists( 'getallheaders' ) ? getallheaders() : array();

		return isset( $_REQUEST['_pjax'] ) && ( ( isset( $headers_req['X-Requested-With'] ) && 'xmlhttprequest' === strtolower( $headers_req['X-Requested-With'] ) ) || ( isset( $_SERVER['HTTP_X_REQUESTED_WITH'] ) && 'xmlhttprequest' === strtolower( $_SERVER['HTTP_X_REQUESTED_WITH'] ) ) );
	}
}


// Create shortcode
function iori_toc_shortcode() {
	if ( function_exists( 'iori_get_toc' ) ) {
		return iori_get_toc_shortcode( get_the_content() );
	} else {
		return false;
	}
}
add_shortcode( 'TOC', 'iori_toc_shortcode' );

add_filter( 'big_image_size_threshold', '__return_false' );
