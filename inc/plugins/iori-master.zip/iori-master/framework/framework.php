<?php if ( ! defined( 'ABSPATH' ) ) {
	die; } // Cannot access pages directly.

// ------------------------------------------------------------------------------------------------
require_once IORI_PLG_DIR . '/framework/framework-path.php';
// ------------------------------------------------------------------------------------------------

if ( ! function_exists( 'iori_framework_init' ) && ! class_exists( 'IORIFramework' ) ) {

	function iori_framework_init() {

		// active modules
		defined( 'IORI_ACTIVE_FRAMEWORK' ) or define( 'IORI_ACTIVE_FRAMEWORK', true );
		defined( 'IORI_ACTIVE_METABOX' ) or define( 'IORI_ACTIVE_METABOX', true );
		defined( 'IORI_ACTIVE_TAXONOMY' ) or define( 'IORI_ACTIVE_TAXONOMY', true );
		defined( 'IORI_ACTIVE_SHORTCODE' ) or define( 'IORI_ACTIVE_SHORTCODE', true );
		defined( 'IORI_ACTIVE_CUSTOMIZE' ) or define( 'IORI_ACTIVE_CUSTOMIZE', true );
		defined( 'IORI_ACTIVE_LIGHT_THEME' ) or define( 'IORI_ACTIVE_LIGHT_THEME', false );

		// helpers
		require_once IORI_PLG_DIR . '/framework/functions/deprecated.php';
		require_once IORI_PLG_DIR . '/framework/functions/fallback.php';
		require_once IORI_PLG_DIR . '/framework/functions/helpers.php';
		require_once IORI_PLG_DIR . '/framework/functions/actions.php';
		require_once IORI_PLG_DIR . '/framework/functions/enqueue.php';
		require_once IORI_PLG_DIR . '/framework/functions/sanitize.php';
		require_once IORI_PLG_DIR . '/framework/functions/validate.php';

		// classes
		require_once IORI_PLG_DIR . '/framework/classes/abstract.class.php';
		require_once IORI_PLG_DIR . '/framework/classes/options.class.php';
		require_once IORI_PLG_DIR . '/framework/classes/framework.class.php';
		require_once IORI_PLG_DIR . '/framework/classes/metabox.class.php';
		require_once IORI_PLG_DIR . '/framework/classes/taxonomy.class.php';
		require_once IORI_PLG_DIR . '/framework/classes/shortcode.class.php';
		require_once IORI_PLG_DIR . '/framework/classes/customize.class.php';

		// configs
		require_once IORI_PLG_DIR . '/framework/config/framework.config.php';
		require_once IORI_PLG_DIR . '/framework/config/metabox.config.php';
		require_once IORI_PLG_DIR . '/framework/config/taxonomy.config.php';
		require_once IORI_PLG_DIR . '/framework/config/shortcode.config.php';
		require_once IORI_PLG_DIR . '/framework/config/customize.config.php';

	}

	add_action( 'init', 'iori_framework_init', 10 );
}
