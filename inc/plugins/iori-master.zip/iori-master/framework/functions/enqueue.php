<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Framework admin enqueue style and scripts
 *
 * @since 1.0.0
 * @version 1.0.0
 */
if ( ! function_exists( 'iori_admin_enqueue_scripts' ) ) {

	function iori_admin_enqueue_scripts() {

		// admin utilities
		wp_enqueue_media();

		// wp core styles
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'wp-jquery-ui-dialog' );

		// framework core styles
		wp_enqueue_style( 'iori', IORI_PLG_URL . 'framework/assets/css/framework.min.css', array(), '1.0.0', 'all' );
		wp_enqueue_style( 'elegant-font', IORI_PLG_URL . 'framework/assets/css/elegant-font.css', array(), '4.7.0', 'all' );

		if ( IORI_ACTIVE_LIGHT_THEME ) {
			wp_enqueue_style( 'iori-framework-theme', IORI_PLG_URL . 'framework/assets/css/framework-light.min.css', array(), '1.0.0', 'all' );
		}

		if ( is_rtl() ) {
			wp_enqueue_style( 'iori-framework-rtl', IORI_PLG_URL . 'framework/assets/css/framework-rtl.min.css', array(), '1.0.0', 'all' );
		}

		// wp core scripts
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_script( 'jquery-ui-dialog' );
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_script( 'jquery-ui-accordion' );

		// framework core scripts
		wp_enqueue_script( 'iori-plugins', IORI_PLG_URL . 'framework/assets/js/plugins.min.js', array(), '1.0.0', true );
		wp_enqueue_script( 'iori', IORI_PLG_URL . 'framework/assets/js/framework.min.js', array( 'iori-plugins' ), '1.0.0', true );
	}

	add_action( 'admin_enqueue_scripts', 'iori_admin_enqueue_scripts' );
}
