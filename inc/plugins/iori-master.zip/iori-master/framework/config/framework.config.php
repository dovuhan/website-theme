<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 * Framework settings
 *
 * @since 1.0
 */

$settings = array(
	'menu_title'      => 'Iori f',
	'menu_type'       => 'submenu',
	'menu_slug'       => 'iori',
	'menu_position'   => 100,
	'ajax_save'       => false,
	'show_reset_all'  => true,
	'framework_title' => 'Iori',
);

/**
 *  FRAMEWORK OPTIONS
 */
$options = array();


// ===================================================================
// Genaral Settings =
// ===================================================================

$options[] = array(
	'name'   => 'genaral',
	'title'  => esc_html__( 'Genaral Setting', 'iori' ),
	'icon'   => 'fa fa-home',
	// begin: fields
	'fields' => array(

		array(
			'type'    => 'subheading',
			'content' => 'Header Setting',
		),

		array(
			'id'         => 'iori_preloader_enable',
			'type'       => 'switcher',
			'title'      => esc_html__( 'Preloader', 'iori' ),
		),

		array(
			'id'         => 'iori_topbar_enable',
			'type'       => 'switcher',
			'title'      => esc_html__( 'Header Top Slider', 'iori' ),
		),

		array(
			'id'         => 'iori_top_bar_color',
			'type'       => 'color_picker',
			'dependency' => array( 'iori_topbar_enable', '==', true ),
			'title'      => esc_html__( 'Topbar color', 'iori' ),
		),

		array(
			'id'         => 'iori_top_bar_text_color',
			'type'       => 'color_picker',
			'dependency' => array( 'iori_topbar_enable', '==', true ),
			'title'      => esc_html__( 'Topbar Text color', 'iori' ),
		),

		array(
			'id'              => 'top_bar_area',
			'type'            => 'group',
			'title'           => esc_html__( 'Add Notice', 'iori' ),
			'dependency'      => array( 'iori_topbar_enable', '==', true ),
			'button_title'    => 'Add New',
			'accordion_title' => 'Add New Field',
			'fields'          => array(
				array(
					'id'    => 'name',
					'type'  => 'text',
					'title' => esc_html__( 'Message', 'iori' ),
				),
			),
			'default'         => array(
				array(
					'name' => 'Black Friday and Cyber Monday 2022 Deals for Motion Designers, grab it now!',
				),
				array(
					'name' => 'Cyber Monday: Save big on the Creative Cloud All Apps plan for individuals through 2 Dec',
				),
			),
		),

		array(
			'id'         => 'iori_searchbar_enable',
			'type'       => 'switcher',
			'title'      => esc_html__( 'Header Search Bar', 'iori' ),
		),

		array(
			'id'         => 'iori_getstarted_enable',
			'type'       => 'switcher',
			'title'      => esc_html__( 'Get Started Button', 'iori' ),
		),
		array(
			'id'         => 'button_text',
			'type'       => 'text',
			'title'      => esc_html__( 'Button Text', 'iori' ),
			'default'    => 'Get Started',
		),

		array(
			'id'         => 'button_url',
			'type'       => 'text',
			'title'      => esc_html__( 'Button Link', 'iori' ),
			'default'    => '#',
		),
		
	),
);

// ===================================================================
// Mobile Menu Options =
// ===================================================================

$options[] = array(
	'name'   => 'mobile_menu_setting',
	'title'  => esc_html__( 'Mobile Menu Setting', 'iori' ),
	'icon'   => 'fa fa-rub',
	// begin: fields
	'fields' => array(

		array(
			'type'    => 'subheading',
			'content' => esc_html__( 'Mobile Menu Options', 'iori' ),
		),

		array(
			'id'    => 'mobile_menu_tabs',
			'type'  => 'switcher',
			'title' => esc_html__( 'Tab based', 'iori' ),
		),

		array(
			'id'              => 'account_list_area',
			'type'            => 'group',
			'title'           => esc_html__( 'Account tab', 'iori' ),
			'button_title'    => 'Add New',
			'accordion_title' => 'Add New Field',
			'dependency'      => array( 'mobile_menu_tabs', '==', 'true' ),
			'fields'          => array(
				array(
					'id'    => 'name',
					'type'  => 'text',
					'title' => esc_html__( 'List Name', 'iori' ),
				),
				array(
					'id'    => 'link',
					'type'  => 'text',
					'title' => esc_html__( 'List Link', 'iori' ),
				),
			),
			'default'         => array(
				array(
					'name' => 'My Profile',
					'link' => '#',
				),
			),
		),

		array(
			'id'         => 'mobile_noti_tabs',
			'type'       => 'switcher',
			'dependency' => array( 'mobile_menu_tabs', '==', 'true' ),
			'title'      => esc_html__( 'Recent Post Notification', 'iori' ),
		),

		array(
			'type'    => 'subheading',
			'content' => esc_html__( 'Mobile Menu Bottom Section', 'iori' ),
		),

		array(
			'id'       => 'mobile_bottom_text',
			'type'     => 'text',
			'title'    => esc_html__( 'Mobile Bottom Text', 'iori' ),
			'default'  => 'Download our Apps and get extra 15% Discount on your first Order…!',
		),
		array(
			'id'    => 'mobile_bottom_appstore_thumb',
			'type'  => 'upload',
			'title' => esc_html__( 'Upload Appstore Image', 'iori' ),
		),
		array(
			'id'    => 'mobile_bottom_appstore_link',
			'type'  => 'text',
			'title' => esc_html__( 'Upload Appstore Link', 'iori' ),
		),
		array(
			'id'    => 'mobile_bottom_google_play_thumb',
			'type'  => 'upload',
			'title' => esc_html__( 'Upload Googleplay Image', 'iori' ),
		),
		array(
			'id'    => 'mobile_bottom_google_play_link',
			'type'  => 'text',
			'title' => esc_html__( 'Upload Googleplay Link', 'iori' ),
		),
		array(
			'id'       => 'mobile_bottom_payment_text',
			'type'     => 'text',
			'title'    => esc_html__( 'Payment Text', 'iori' ),
			'default'  => 'Secured Payment Gateways',
		),
		array(
			'id'    => 'mobile_bottom_payment_thumb',
			'type'  => 'upload',
			'title' => esc_html__( 'Upload Payment Image', 'iori' ),
		),
	),
);


$options[] = array(
	'name'   => 'blog',
	'title'  => esc_html__('Blog Setting', 'iori'),
	'icon'   => 'fa fa-home',
	// begin: fields
	'fields' => array(
				
		array(
			'type'    => 'heading',
			'content' => esc_html__( 'Blog', 'iori' ),
		),

		array(
			'id'      => 'blog_layout',
			'type'    => 'image_select',
			'title'   => esc_html__('Page Layout Style', 'iori'),
			'options' => array(
				'full_width'    => IORI_PLG_URL . '/framework/assets/images/fullwidth.jpg',
				'left_sidebar'  => IORI_PLG_URL . '/framework/assets/images/sidebar_l.jpg',
				'right_sidebar' => IORI_PLG_URL . '/framework/assets/images/sidebar_r.jpg',
			),
			'default'	=> "full_width",
		),


		array(
			'id'         => 'iori_table_of_content_enable',
			'type'       => 'switcher',
			'title'      => esc_html__('Table of content', 'iori'),
			'dependency' => array('blog_layout_full_width', '==', 'true'),
			'default'	 => true,
		),

	),
);

if ( class_exists( 'Woocommerce' ) ) {
	// ===================================================================
	// Iori Shop Settings =
	// ===================================================================

	$options[] = array(
		'name'     => 'shop_setting',
		'title'    => esc_html__( 'WooCommerce', 'iori' ),
		'icon'     => 'fa fa-shopping-cart',
		'sections' => array(

			// -----------------------------
			// begin: text options         -
			// -----------------------------
			array(
				'name'   => 'shop_page_settings',
				'title'  => esc_html__( 'Shop', 'iori' ),
				'icon'   => 'fa fa-shopping-cart',
				// begin: fields
				'fields' => array(

					array(
						'type'    => 'heading',
						'content' => esc_html__( 'Shop Page Settings', 'iori' ),
					),

					array(
						'id'    => 'iori_shop_breadcrumb_section',
						'type'  => 'switcher',
						'title' => esc_html__( 'Breadcrumb Section', 'iori' ),
					),

					array(
						'id'         => 'iori_shop_breadcrumb_section_image',
						'type'       => 'upload',
						'dependency' => array( 'iori_shop_breadcrumb_section', '==', 'true' ),
						'title'      => esc_html__( 'Image Upload', 'iori' ),
					),

					array(
						'id'              => 'iori_shop_cat',
						'type'            => 'group',
						'title'           => esc_html__( 'Add Slider', 'iori' ),
						'button_title'    => 'Add New',
						'dependency'      => array( 'iori_shop_breadcrumb_section', '==', 'true' ),
						'accordion_title' => 'Add New Field',
						'fields'          => array(
							array(
								'id'    => 'shop_cat_title',
								'type'  => 'text',
								'title' => esc_html__( 'Title', 'iori' ),
							),
							array(
								'id'    => 'shop_cat_link',
								'type'  => 'text',
								'title' => esc_html__( 'Link', 'iori' ),
							),
						),
						'default'         => array(
							array(
								'shop_cat_title' => 'Digital Cameras',
								'shop_cat_link'  => '#',
							),
							array(
								'shop_cat_title' => 'Digital Cameras',
								'shop_cat_link'  => '#',
							),
							array(
								'shop_cat_title' => 'Camera Flashes',
								'shop_cat_link'  => '#',
							),
							array(
								'shop_cat_title' => 'Travel Camera',
								'shop_cat_link'  => '#',
							),
							array(
								'shop_cat_title' => 'Instant Camera',
								'shop_cat_link'  => '#',
							),
						),
					),

					array(
						'id'      => 'shop_layout',
						'type'    => 'image_select',
						'title'   => esc_html__( 'Shop Layout Style', 'iori' ),
						'options' => array(
							'left_sidebar'  => IORI_PLG_URL . '/framework/assets/images/sidebar_l.jpg',
							'right_sidebar' => IORI_PLG_URL . '/framework/assets/images/sidebar_r.jpg',
							'full_width'    => IORI_PLG_URL . '/framework/assets/images/fullwidth.jpg',
						),
					),

					array(
						'id'      => 'iori_shop_view',
						'type'    => 'select',
						'title'   => esc_html__( 'Shop Style', 'iori' ),
						'desc'    => 'Shop page list or grid.',
						'options' => array(
							'grid' => 'Grid',
							'list' => 'List',
						),
					),

					array(
						'id'         => 'iori_shop_grid_products_per_row',
						'type'       => 'number',
						'dependency' => array( 'iori_shop_view', '==', 'grid' ),
						'attributes' => array(
							'max'         => 5,
							'min'         => 1,
							'placeholder' => 'The maximum allowed setting is 5',
						),
						'default'    => 3,
						'title'      => esc_html__( 'Products per row', 'iori' ),
					),

					array(
						'id'         => 'swatches_limit_count',
						'type'       => 'number',
						'dependency' => array( 'iori_shop_view', '==', 'grid' ),
						'attributes' => array(
							'max'         => 5,
							'min'         => 1,
							'placeholder' => 'The maximum allowed setting is 5',
						),
						'default'    => 3,
						'title'      => esc_html__( 'Attritube swatcher show', 'iori' ),
						'desc'       => esc_html__( 'Attritube swatcher show when on hover.', 'iori' ),
					),



					array(
						'id'         => 'iori_shop_list_products_per_row',
						'type'       => 'number',
						'dependency' => array( 'iori_shop_view', '==', 'list' ),
						'attributes' => array(
							'max'         => 2,
							'min'         => 1,
							'placeholder' => 'The maximum allowed setting is 2',
						),
						'desc'       => esc_html__( 'Please select full width shop layout for perfect view.', 'iori' ),
						'title'      => esc_html__( 'Products per row', 'iori' ),
					),

					array(
						'id'         => 'iori_shop_excerpt_list',
						'type'       => 'number',
						// 'dependency' => array( 'iori_shop_view', '==', 'list' ),
						'attributes' => array(
							'max' => 250,
							'min' => 1,
						),
						'default'    => 140,
						'desc'       => esc_html__( 'Please select full width shop layout for perfect view.', 'iori' ),
						'title'      => esc_html__( 'How many word to display', 'iori' ),
					),

					array(
						'id'      => 'iori_sorting',
						'type'    => 'select',
						'title'   => esc_html__( 'Sorting Style', 'iori' ),
						'desc'    => 'Button or select option above the products.',
						'options' => array(
							'button'       => 'Button Type',
							'selectoption' => 'Option Type',
						),
					),

					array(
						'id'    => 'iori_shop_ajax',
						'type'  => 'switcher',
						'title' => esc_html__( 'Ajax', 'iori' ),
					),

					array(
						'id'      => 'iori_shop_wishlist_view',
						'type'    => 'switcher',
						'title'   => esc_html__( 'Wishlist View', 'iori' ),
						'default' => true,
					),

					// !todo
					// array(
					// 'id'      => 'iori_shop_quick_view',
					// 'type'    => 'switcher',
					// 'title'   => esc_html__( 'Quick View', 'iori' ),
					// 'default' => true,
					// ),

					array(
						'id'         => 'iori_quick_view_variable',
						'type'       => 'switcher',
						'title'      => esc_html__( 'Variable View in quick view', 'iori' ),
						'dependency' => array( 'iori_shop_quick_view', '==', 'true' ),
						'default'    => true,
					),

					// quick_view_variable

					array(
						'type'    => 'subheading',
						'content' => esc_html__( 'Grid View', 'iori' ),
					),

					array(
						'id'    => 'iori_woo_attr',
						'type'  => 'number',
						'title' => esc_html__( 'Attribute Show On Hover', 'iori' ),
					),

					array(
						'type'    => 'subheading',
						'content' => esc_html__( 'Shop Bottom View', 'iori' ),
					),

					array(
						'id'    => 'iori_featured_product',
						'type'  => 'switcher',
						'title' => esc_html__( 'Top sale/Featured/Recent Product', 'iori' ),
					),
				),
			),

			array(
				'name'   => 'shop_single_settings',
				'title'  => esc_html__( 'Shop Single', 'iori' ),
				'icon'   => 'fa fa-shopping-cart',
				// begin: fields
				'fields' => array(

					array(
						'type'    => 'heading',
						'content' => esc_html__( 'Shop Page Settings', 'iori' ),
					),

					array(
						'id'      => 'sales_badge',
						'type'    => 'text',
						'title'   => esc_html__( 'Sale Badge', 'iori' ),
						'default' => 'Sale!',
					),

					array(
						'id'    => 'sales_badge_percentage',
						'type'  => 'switcher',
						'title' => esc_html__( 'Badge Percentage', 'iori' ),
					),

				),
			),
		),
	);
}


// ===================================================================
// Footer Options =
// ===================================================================

$options[] = array(
	'name'   => 'footer_setting',
	'title'  => esc_html__( 'Footer Setting', 'iori' ),
	'icon'   => 'fa fa-rub',
	// begin: fields
	'fields' => array(

		array(
			'type'    => 'subheading',
			'content' => esc_html__( 'Copyright', 'iori' ),
		),

		array(
			'id'       => 'copyrights',
			'type'     => 'textarea',
			'title'    => esc_html__( 'Copyright Footer', 'iori' ),
			'default'  => 'Copyright &copy; 2023, Iori. Theme Developed by <a href="https://www.jthemes.com/" title="jthemes"> Jthemes</a>',
			'sanitize' => false,
		),
	),
);


// ===================================================================
// 404 Page Settings =
// ===================================================================

$options[] = array(
	'name'   => '404_page',
	'title'  => esc_html__( '404 Page Setting', 'iori' ),
	'icon'   => 'fa fa-frown-o',
	// begin: fields
	'fields' => array(

		array(
			'id'    => '404_image',
			'type'  => 'upload',
			'title' => esc_html__( 'Image Upload', 'iori' ),
		),
		array(
			'id'      => '404_page_top_title',
			'type'    => 'text',
			'title'   => 'Top Title',
			'default' => '404',
		),
		array(
			'id'      => '404_page_title',
			'type'    => 'text',
			'title'   => 'Title',
			'default' => 'Oops! You’ve got lost in space',
		),
		array(
			'id'      => '404_page_desc',
			'type'    => 'textarea',
			'title'   => 'Description',
			'default' => 'Unfortunately, we couldn\'t find what you were looking for or the page no longer exists.',
		),
	),
);


// ------------------------------
// Coming soon                 -
// ------------------------------

$options[] = array(
	'name'   => 'coming_soon_page',
	'title'  => esc_html__( 'Coming Soon', 'iori' ),
	'icon'   => 'fa fa-pencil-square-o',
	// begin: fields
	'fields' => array(

		array(
			'id'    => 'coming_soon_on_off',
			'type'  => 'switcher',
			'title' => esc_html__( 'Coming soon', 'iori' ),
		),

		array(
			'id'         => 'coming_soon_image',
			'type'       => 'upload',
			'dependency' => array( 'coming_soon_on_off', '==', 'true' ),
			'title'      => esc_html__( 'Image', 'iori' ),
		),

		array(
			'id'         => 'coming_soon_heading',
			'type'       => 'text',
			'dependency' => array( 'coming_soon_on_off', '==', 'true' ),
			'title'      => esc_html__( 'Title', 'iori' ),
			'default'    => 'We are coming soon',
		),

		array(
			'id'         => 'coming_soon_desc',
			'type'       => 'textarea',
			'dependency' => array( 'coming_soon_on_off', '==', 'true' ),
			'title'      => esc_html__( 'Description', 'iori' ),
			'default'    => 'Our design projects are fresh and simple and will benefit your business greatly. Learn more about our work!',
		),

		array(
			'id'         => 'coming_soon_time',
			'type'       => 'text',
			'dependency' => array( 'coming_soon_on_off', '==', 'true' ),
			'title'      => esc_html__( 'Expire Time', 'iori' ),
			'desc'       => 'Should be like this: 2025/12/31 00:00:00',
			'default'    => '2025/12/31 00:00:00',
		),

		array(
			'id'         => 'coming_soon_code',
			'type'       => 'text',
			'dependency' => array( 'coming_soon_on_off', '==', 'true' ),
			'title'      => esc_html__( 'MailChimp Shortcode', 'iori' ),
			'desc'       => 'Should be like this: [mc4wp_form id=1987]',
			'default'    => '[mc4wp_form id=1987]',
		),

		array(
			'id'              => 'coming_soon_social',
			'type'            => 'group',
			'title'           => esc_html__( 'Social', 'iori' ),
			'dependency'      => array( 'coming_soon_on_off', '==', 'true' ),
			'button_title'    => 'Add New',
			'accordion_title' => 'Add New Field',
			'fields'          => array(
				array(
					'id'      => 'name',
					'type'    => 'select',
					'options' => array(
						'icon-facebook'  => 'Facebook',
						'icon-twitter'   => 'X (twitter)',
						'icon-instagram' => 'Instagram',
						'icon-linkedin'  => 'Linkedin',
						'icon-youtube'   => 'Youtube',
					),
					'title'   => esc_html__( 'Social Name', 'iori' ),
				),
				array(
					'id'    => 'link',
					'type'  => 'text',
					'title' => esc_html__( 'Social Link', 'iori' ),
				),
			),
			'default'         => array(
				array(
					'name' => 'icon-facebook',
					'link' => '#',
				),
				array(
					'name' => 'icon-twitter',
					'link' => '#',
				),
			),
		),


		array(
			'id'              => 'coming_soon_address',
			'type'            => 'group',
			'title'           => esc_html__( 'Address', 'iori' ),
			'dependency'      => array( 'coming_soon_on_off', '==', 'true' ),
			'button_title'    => 'Add New',
			'accordion_title' => 'Add New Field',
			'fields'          => array(
				array(
					'id'    => 'icon',
					'type'  => 'upload',
					'title' => esc_html__( 'Icon', 'iori' ),
				),
				
				array(
					'id'    => 'title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'iori' ),
				),
				array(
					'id'    => 'desc',
					'type'  => 'textarea',
					'title' => esc_html__( 'Description', 'iori' ),
				),
			),
			'default'         => array(
				array(
					'icon'  => get_template_directory_uri() . '/assets/imgs/page/contact/headphone.png',
					'title' => 'Help & support',
					'desc'  => 'Email : <a class="color-success" href="mailto:support@jthemes.com">support@jthemes.com</a><br>For help with a current product or service or refer to FAQs and developer tools',
				),
				array(
					'icon'  => get_template_directory_uri() . '/assets/imgs/page/contact/phone.png',
					'title' => 'Call Us',
					'desc'  => 'Call us to speak to a member of our team.<br>(+01) 234 567 89<br>(+01) 456 789 21
					',
				),
				array(
					'icon'  => get_template_directory_uri() . '/assets/imgs/page/contact/chart.png',
					'title' => 'Bussiness Department',
					'desc'  => 'Contact the sales department about cooperation projects <br>
					(+01) 789 456 23',
				),
				array(
					'icon'  => get_template_directory_uri() . '/assets/imgs/page/contact/earth.png',
					'title' => 'Help & support',
					'desc'  => 'Contact us to open our branches globally. <br>
					(+01) 234 567 89 <br>
					(+01) 456 789 23',
				),
			),
		),

	),
);

// ------------------------------
// Optimization                 -
// ------------------------------

$options[] = array(
	'name'   => 'optimization_setting',
	'title'  => esc_html__( 'Optimization', 'iori' ),
	'icon'   => 'fa fa-pencil-square-o',
	// begin: fields
	'fields' => array(

		array(
			'id'    => 'iori_css_optimization',
			'type'  => 'switcher',
			'title' => esc_html__( 'CSS Optimization and Minified', 'iori' ),
		),

		array(
			'id'    => 'iori_js_optimization',
			'type'  => 'switcher',
			'title' => esc_html__( 'JS Optimization and Minified', 'iori' ),
		),

	),
);





// ------------------------------
// backup                       -
// ------------------------------
$options[] = array(
	'name'   => 'backup_section',
	'title'  => 'Backup',
	'icon'   => 'fa fa-shield',
	'fields' => array(

		array(
			'type'    => 'notice',
			'class'   => 'warning',
			'content' => 'You can save your current options. Download a Backup and Import.',
		),

		array(
			'type' => 'backup',
		),

	),
);


IORIFramework::instance( $settings, $options );
