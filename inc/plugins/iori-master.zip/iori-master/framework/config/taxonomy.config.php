<?php if ( ! defined( 'ABSPATH' ) ) {
	die; } // Cannot access pages directly.
/**
 *  TAXONOMY OPTIONS
 */
$options = array();

// -----------------------------------------
// Taxonomy Options                        -
// -----------------------------------------



IORIFramework_Taxonomy::instance( $options );
