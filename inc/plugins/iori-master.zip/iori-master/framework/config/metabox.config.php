<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *  METABOX OPTIONS
 */
$options = array();


$options[] = array(
	'id' => 'iori_pfs_settings',
	'title' => 'Portfolio single Settings',
	'post_type' => 'page',
	'context' => 'normal',
	'priority' => 'default',
	'sections' => array(

		// begin section
		array(
			'name' => 'post_settings',
			'icon' => 'fa fa-tasks',
			'fields' => array(

				array(
					'id' => 'button_on_off',
					'type' => 'switcher',
					'title' => esc_html__('Button Switcher', 'iori'),
				),

				array(
					'id' => 'pfs_btn_text',
					'type' => 'text',
					'title' => esc_html__('Button', 'iori'),
					'default' => esc_html__('Read More', 'iori'),
					'dependency' => array('button_on_off', '==', 'true'),
				),

				array(
					'id' => 'pfs_btn_link',
					'type' => 'text',
					'title' => esc_html__('Link', 'iori'),
					'default' => esc_html__('#', 'iori'),
					'dependency' => array('button_on_off', '==', 'true'),
				),
			),
		),

	),
);

$options[] = array(
	'id'        => '_iori_product_settings',
	'title'     => 'Iori Settings',
	'post_type' => 'product',
	'context'   => 'normal',
	'priority'  => 'default',
	'sections'  => array(

		// begin section
		array(
			'name'   => 'post_settings',
			'icon'   => 'fa fa-tasks',
			'fields' => array(

				array(
					'id'    => 'product_size_on_off',
					'type'  => 'switcher',
					'title' => esc_html__( 'Product Size', 'iori' ),
				),

				array(
					'id'         => 'product_size_img',
					'type'       => 'upload',
					'title'      => esc_html__( 'Image', 'iori' ),
					'dependency' => array( 'product_size_on_off', '==', 'true' ),
				),

				array(
					'id'         => 'product_size_text',
					'type'       => 'text',
					'default'    => 'Size Chart',
					'title'      => esc_html__( 'Text', 'iori' ),
					'dependency' => array( 'product_size_on_off', '==', 'true' ),
				),

				array(
					'id'      => 'product_attr',
					'type'    => 'select',
					'title'   => esc_html__( 'Display Product Attribute', 'iori' ),
					'options' => 'product_attribute',
					'desc'    => esc_html__( 'If active, selected style will disply in specific product in shop page on hover. Must be specify variation product.', 'iori' ),
				),

				array(
					'id'    => 'product_badge',
					'type'  => 'text',
					'title' => esc_html__( 'Extra Badge', 'iori' ),
					'desc'  => esc_html__( 'For example: Discount/Hot/Hurry Up/New', 'iori' ),
				),

				array(
					'id'    => 'product_attr_checkbox',
					'type'  => 'switcher',
					'title' => esc_html__( 'Product Variation Iori Style', 'iori' ),
					'desc'  => esc_html__( 'If active, variation style will be change. You have to change attritube type.', 'iori' ),
				),

			),
		),

	),
);

$options[] = array(
	'id'        => 'iori_job_details_page_settings',
	'title'     => 'Job Details Page Settings',
	'post_type' => 'job_listing',
	'context'   => 'normal',
	'priority'  => 'default',
	'sections'  => array(

		// begin section
		array(
			'name'   => 'post_settings',
			'icon'   => 'fa fa-tasks',
			'fields' => array(

				array(
					'id'         => 'job_details_banner_img',
					'type'       => 'upload',
					'title'      => esc_html__( 'Section Top Banner', 'iori' ),
				),

				array(
					'id'         => 'job_details_title',
					'type'       => 'text',
					'default'    => 'Title',
					'title'      => esc_html__( 'Text', 'iori' ),
				),

				array(
					'id'         => 'product_action_banner_title',
					'type'       => 'wysiwyg',
					'title'      => esc_html__( 'Content', 'iori' ),
					'default'    => esc_html__(
						'Our marketplace makes it easy to buy directly from small businesses across the globe.',
						'iori'
					),
				),

				array(
					'id'         => 'apply_now_btn_text',
					'type'       => 'text',
					'title'      => esc_html__( 'Apply Now Button', 'iori' ),
					'default'    => esc_html__( 'Discover', 'iori' ),
				),

				array(
					'id'         => 'apply_now_btn_link',
					'type'       => 'text',
					'title'      => esc_html__( 'Button Link', 'iori' ),
					'default'    => esc_html__( '#', 'iori' ),
				),

				array(
					'id'         => 'job_summery_title',
					'type'       => 'text',
					'title'      => esc_html__( 'Job Summery Title', 'iori' ),
					'default'    => 'Summery Title',
				),

				array(
					'id'              => 'job_summery_content',
					'type'            => 'group',
					'title'           => esc_html__( 'Add Job Info', 'iori' ),
					'button_title'    => 'Add New',
					'accordion_title' => 'Add New Field',
					'fields'          => array(

						array(
							'id'         => 'icon_image',
							'type'       => 'upload',
							'title'      => esc_html__( 'Upload Icon', 'iori' ),
							'desc' => esc_html__('Please upload 16x16 or 48x48 icon', 'iori'),
						),
						array(
							'id'    => 'name',
							'type'  => 'text',
							'title' => esc_html__( 'Name', 'iori' ),
						),

						array(
							'id'    => 'text',
							'type'  => 'text',
							'title' => esc_html__( 'Text', 'iori' ),
						),

					),
					'default'         => array(
						array(
							'icon_image' => '',
							'name'       => 'Industry',
							'text'       => '',
						),
						array(
							'icon_image' => '',
							'name'       => 'Salary',
							'text'       => '',
						),
						array(
							'icon_image' => '',
							'name'       => 'Job type',
							'text'       => '',
						),
					),
				),
				array(
					'id'         => 'apply_now_btn2_text',
					'type'       => 'text',
					'title'      => esc_html__( 'Apply Now Button', 'iori' ),
					'default'    => esc_html__( 'Apply Now', 'iori' ),
				),

				array(
					'id'         => 'apply_now_btn2_link',
					'type'       => 'text',
					'title'      => esc_html__( 'Button Link', 'iori' ),
					'default'    => esc_html__( '#', 'iori' ),
				),

			),
		),
	),
);

IORIFramework_Metabox::instance( $options );
