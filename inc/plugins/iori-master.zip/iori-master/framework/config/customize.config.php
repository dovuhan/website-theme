<?php if ( ! defined( 'ABSPATH' ) ) {
	die; } // Cannot access pages directly.
/**
 *  CUSTOMIZE SETTINGS
 */

$options = array();


IORIFramework_Customize::instance( $options );
