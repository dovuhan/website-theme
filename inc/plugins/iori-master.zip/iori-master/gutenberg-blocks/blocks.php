<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function iori_testimonial_gutenberg_block_init() {
	register_block_type(
		'iori/testimonial-four',
		array(
			'editor_script' => 'iori-testimonial-gutenberg-block-editor',
		)
	);
}
add_action( 'init', 'iori_testimonial_gutenberg_block_init' );

function iori_testimonial_gutenberg_block_editor_scripts() {

	$scripts_url = plugins_url( 'js/block-editor.js', __FILE__ );
	$scripts_var = filemtime( plugin_dir_path( __FILE__ ) . 'js/block-editor.js' );

	wp_enqueue_script(
		'iori-testimonial-gutenberg-block-editor',
		$scripts_url,
		array( 'wp-blocks', 'wp-element' ),
		$scripts_var,
		true
	);

}
add_action( 'enqueue_block_editor_assets', 'iori_testimonial_gutenberg_block_editor_scripts' );
