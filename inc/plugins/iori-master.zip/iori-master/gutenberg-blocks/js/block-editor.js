const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const { MediaUpload, InspectorControls, RichText } = wp.editor;
const { PanelBody, TextControl } = wp.components;

registerBlockType('iori/testimonial-four', {
    title: __('Testimonial Four', 'iori-testimonial-gutenberg-block'),
    icon: 'format-quote',
    category: 'common',
    attributes: {
        testimonialImg: {
            type: 'string',
        },
        testimonialDesc: {
            type: 'string',
            source: 'html',
            selector: '.testimonial_desc',
        },
        testimonialAuthorName: {
            type: 'string',
            source: 'text',
            selector: '.testimonial_author',
        },
        testimonialAuthorDesignation: {
            type: 'string',
            source: 'text',
            selector: '.designation',
        },
    },
    edit(props) {
        const { attributes, setAttributes } = props;
        const { testimonialImg, testimonialDesc, testimonialAuthorName, testimonialAuthorDesignation } = attributes;

        function onImageSelect(media) {
            setAttributes({ testimonialImg: media.url });
        }

        return (
            wp.element.createElement('div', null,
                wp.element.createElement(InspectorControls, null,
                    wp.element.createElement(PanelBody, { title: __('Testimonial Image', 'iori-testimonial-gutenberg-block') },
                        wp.element.createElement(MediaUpload, {
                            onSelect: onImageSelect,
                            type: 'image',
                            value: testimonialImg,
                            render: ({ open }) => (
                                wp.element.createElement('button', { onClick: open, className: 'button button-large' },
                                    __('Upload Image', 'iori-testimonial-gutenberg-block')
                                )
                            ),
                        })
                    )
                ),
                wp.element.createElement('div', { className: 'box-item-comment wow animate__animated animate__fadeInUp', 'data-wow-delay': '.3s' },
                    wp.element.createElement('div', { className: 'image-comment' },
                        testimonialImg && wp.element.createElement('img', { src: testimonialImg, alt: 'iori' })
                    ),
                    wp.element.createElement('div', { className: 'info-comment' },
                        wp.element.createElement(RichText, {
                            tagName: 'div',
                            className: 'testimonial_desc comment-quote mb-15',
                            value: testimonialDesc,
                            onChange: (value) => setAttributes({ testimonialDesc: value }),
                            placeholder: __('Description', 'iori-testimonial-gutenberg-block'),
                        }),
                        wp.element.createElement(TextControl, {
                            value: testimonialAuthorName,
                            onChange: (value) => setAttributes({ testimonialAuthorName: value }),
                            placeholder: __('Author Name', 'iori-testimonial-gutenberg-block'),
                        }),
                        wp.element.createElement(TextControl, {
                            value: testimonialAuthorDesignation,
                            onChange: (value) => setAttributes({ testimonialAuthorDesignation: value }),
                            placeholder: __('Designation', 'iori-testimonial-gutenberg-block'),
                        })
                    )
                )
            )
        );
    },
    save(props) {
        const { attributes } = props;
        const { testimonialImg, testimonialDesc, testimonialAuthorName, testimonialAuthorDesignation } = attributes;

        return (
            wp.element.createElement('div', { className: 'box-item-comment wow animate__animated animate__fadeInUp', 'data-wow-delay': '.3s' },
                wp.element.createElement('div', { className: 'image-comment' },
                    testimonialImg && wp.element.createElement('img', { src: testimonialImg, alt: 'iori' })
                ),
                wp.element.createElement('div', { className: 'info-comment' },
                    wp.element.createElement('div', { className: 'testimonial_desc comment-quote mb-15', dangerouslySetInnerHTML: { __html: testimonialDesc } }),
                    wp.element.createElement('span', { className: 'testimonial_author' }, testimonialAuthorName),
                    wp.element.createElement('p', { className: 'designation' }, testimonialAuthorDesignation)
                )
            )
        );
    },
});
