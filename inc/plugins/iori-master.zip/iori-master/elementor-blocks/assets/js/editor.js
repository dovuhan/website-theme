!(function (e, t, i) {
    (window.ioriGetTranslated = function (e, t) {
        return elementorCommon.translate(e, null, t, IoriEditor.i18n);
    });

    var Iori = {
        Views: {},
        Models: {},
        Collections: {},
        Behaviors: {},
        Layout: null,
        Manager: null
    };

    Iori.Models.Template = Backbone.Model.extend({
        defaults: {
            template_id: 0,
            title: "",
            type: "",
            thumbnail: "",
            url: "",
            tags: [],
            isPro: !1
        }
    });

    Iori.Collections.Template = Backbone.Collection.extend({
        model: Iori.Models.Template
    });

    Iori.Behaviors.InsertTemplate = Marionette.Behavior.extend({
        ui: {
            insertButton: ".ioriElementor__insert-button"
        },
        events: {
            "click @ui.insertButton": "onInsertButtonClick"
        },
        onInsertButtonClick: function () {
            i.library.insertTemplate({
                model: this.view.model
            });
        },
    });

    Iori.Views.EmptyTemplateCollection = Marionette.ItemView.extend({
        id: "elementor-template-library-templates-empty",
        template: "#tmpl-ioriElementor__empty",
        ui: {
            title: ".elementor-template-library-blank-title",
            message: ".elementor-template-library-blank-message"
        },
        modesStrings: {
            empty: {
                title: ioriGetTranslated("templatesEmptyTitle"),
                message: ioriGetTranslated("templatesEmptyMessage")
            },
            noResults: {
                title: ioriGetTranslated("templatesNoResultsTitle"),
                message: ioriGetTranslated("templatesNoResultsMessage")
            },
        },
        getCurrentMode: function () {
            return i.library.getFilter("text") ? "noResults" : "empty";
        },
        onRender: function () {
            var e = this.modesStrings[this.getCurrentMode()];
            this.ui.title.html(e.title), this.ui.message.html(e.message);
        },
    });

    Iori.Views.Loading = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__loading",
        id: "ioriElementor__loading"
    });

    Iori.Views.Logo = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__header-logo",
        className: "ioriElementor__header-logo",
        templateHelpers: function () {
            return {
                title: this.getOption("title")
            };
        },
    });

    Iori.Views.BackButton = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__header-back",
        id: "elementor-template-library-header-preview-back",
        className: "ioriElementor__header-back",
        events: function () {
            return {
                click: "onClick"
            };
        },
        onClick: function () {
            i.library.showTemplatesView();
        },
    });
    Iori.Views.Menu = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__header-menu",
        id: "elementor-template-library-header-menu",
        className: "ioriElementor__header-menu",
        templateHelpers: function () {
            return i.library.getTabs();
        },
        ui: {
            menuItem: ".elementor-template-library-menu-item"
        },
        events: {
            "click @ui.menuItem": "onMenuItemClick"
        },
        onMenuItemClick: function (e) {
            i.library.setFilter("tags", ""), i.library.setFilter("text", ""), i.library.setFilter("type", e.currentTarget.dataset.tab, !0), i.library.showTemplatesView();
        },
    });
    Iori.Views.ResponsiveMenu = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__header-menu-responsive",
        id: "elementor-template-library-header-menu-responsive",
        className: "ioriElementor__header-menu-responsive",
        ui: {
            items: "> .elementor-component-tab"
        },
        events: {
            "click @ui.items": "onTabItemClick"
        },
        onTabItemClick: function (t) {
            var a = e(t.currentTarget),
                n = a.data("tab");
            i.library.channels.tabs.trigger("change:device", n, a);
        },
    });
    Iori.Views.Actions = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__header-actions",
        id: "elementor-template-library-header-actions",
        ui: {
            sync: "#ioriElementor__header-sync i"
        },
        events: {
            "click @ui.sync": "onSyncClick"
        },
        onSyncClick: function () {
            var e = this;
            e.ui.sync.addClass("eicon-animation-spin"),
                i.library.requestLibraryData({
                    onUpdate: function () {
                        e.ui.sync.removeClass("eicon-animation-spin"), i.library.updateBlocksView();
                    },
                    forceUpdate: !0,
                    forceSync: !0,
                });
        },
    });

    Iori.Views.InsertWrapper = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__header-insert",
        id: "elementor-template-library-header-preview",
        behaviors: {
            insertTemplate: {
                behaviorClass: Iori.Behaviors.InsertTemplate
            }
        },
    });

    Iori.Views.Preview = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__preview",
        className: "ioriElementor__preview",
        ui: function () {
            return {
                iframe: "> iframe"
            };
        },
        onRender: function () {
            this.ui.iframe.attr("src", this.getOption("url")).hide();
            var e = this,
                t = new Iori.Views.Loading().render();
            this.$el.append(t.el),
                this.ui.iframe.on("load", function () {
                    e.$el.find("#ioriElementor__loading").remove(), e.ui.iframe.show();
                });
        },
    });

    Iori.Views.TemplateCollection = Marionette.CompositeView.extend({
        template: "#tmpl-ioriElementor__templates",
        id: "ioriElementor__templates",
        className: function () {
            return "ioriElementor__templates ioriElementor__templates--" + i.library.getFilter("type");
        },
        childViewContainer: "#ioriElementor__templates-list",
        emptyView: function () {
            return new Iori.Views.EmptyTemplateCollection();
        },
        ui: {
            templatesWindow: ".ioriElementor__templates-window",
            textFilter: "#ioriElementor__search",
            tagsFilter: "#ioriElementor__filter-tags",
            filterBar: "#ioriElementor__toolbar-filter",
            counter: "#ioriElementor__toolbar-counter",
        },
        events: {
            "input @ui.textFilter": "onTextFilterInput",
            "click @ui.tagsFilter li": "onTagsFilterClick"
        },
        getChildView: function (e) {
            return Iori.Views.Template;
        },
        initialize: function () {
            this.listenTo(i.library.channels.templates, "filter:change", this._renderChildren);
        },
        filter: function (e) {
            var t = i.library.getFilterTerms(),
                a = !0;
            return (
                _.each(t, function (t, n) {
                    var r = i.library.getFilter(n);
                    if (r && t.callback) {
                        var l = t.callback.call(e, r);
                        return l || (a = !1), l;
                    }
                }),
                a
            );
        },
        setMasonrySkin: function () {
            if ("section" === i.library.getFilter("type")) {
                var e = new elementorModules.utils.Masonry({
                    container: this.$childViewContainer,
                    items: this.$childViewContainer.children()
                });
                this.$childViewContainer.imagesLoaded(e.run.bind(e));
            }
        },
        onRenderCollection: function () {
            this.setMasonrySkin(), this.updatePerfectScrollbar(), this.setTemplatesFoundText();
        },
        setTemplatesFoundText: function () {
            var e = i.library.getFilter("type"),
                t = this.children.length;
            (text = "<b>" + t + "</b>"), (text += "section" === e ? " block" : " " + e), t > 1 && (text += "s"), (text += " found"), this.ui.counter.html(text);
        },
        onTextFilterInput: function () {
            var e = this;
            _.defer(function () {
                i.library.setFilter("text", e.ui.textFilter.val());
            });
        },
        onTagsFilterClick: function (t) {
            var a = e(t.currentTarget),
                n = a.data("tag");
            i.library.setFilter("tags", n),
                a.addClass("active").siblings().removeClass("active"),
                (n = n ? i.library.getTags()[n] : "Filter"),
                this.ui.filterBar.find(".ioriElementor__filter-btn").html(n + ' <i class="eicon-caret-down"></i>');
        },
        updatePerfectScrollbar: function () {
            this.perfectScrollbar || (this.perfectScrollbar = new PerfectScrollbar(this.ui.templatesWindow[0], {
                suppressScrollX: !0
            })), (this.perfectScrollbar.isRtl = !1), this.perfectScrollbar.update();
        },
        setTagsFilterHover: function () {
            var e = this;
            e.ui.filterBar.hoverIntent(
                function () {
                    e.ui.tagsFilter.css("display", "block"), e.ui.filterBar.find(".ioriElementor__filter-btn i").addClass("eicon-caret-down").removeClass("eicon-caret-right");
                },
                function () {
                    e.ui.tagsFilter.css("display", "none"), e.ui.filterBar.find(".ioriElementor__filter-btn i").addClass("eicon-caret-right").removeClass("eicon-caret-down");
                }, {
                    sensitivity: 50,
                    interval: 150,
                    timeout: 100
                }
            );
        },
        onRender: function () {
            this.setTagsFilterHover(), this.updatePerfectScrollbar();
        },
    });

    Iori.Views.Template = Marionette.ItemView.extend({
        template: "#tmpl-ioriElementor__template",
        className: "ioriElementor__template",
        ui: {
            previewButton: ".ioriElementor__preview-button, .ioriElementor__template-preview"
        },
        events: {
            "click @ui.previewButton": "onPreviewButtonClick"
        },
        behaviors: {
            insertTemplate: {
                behaviorClass: Iori.Behaviors.InsertTemplate
            }
        },
        onPreviewButtonClick: function () {
            i.library.showPreviewView(this.model);
        },
    });

    Iori.Modal = elementorModules.common.views.modal.Layout.extend({
        getModalOptions: function () {
            return {
                id: "ioriElementor__modal",
                hide: {
                    onOutsideClick: !1,
                    onEscKeyPress: !0,
                    onBackgroundClick: !1
                }
            };
        },
        getTemplateActionButton: function (e) {
            var t = e.isPro && !IoriEditor.hasPro ? "pro-button" : "insert-button";
            return (viewId = "#tmpl-ioriElementor__" + t), (template = Marionette.TemplateCache.get(viewId)), Marionette.Renderer.render(template);
        },
        showLogo: function (e) {
            this.getHeaderView().logoArea.show(new Iori.Views.Logo(e));
        },
        showDefaultHeader: function () {
            this.showLogo({
                title: "TEMPLATES"
            });
            var e = this.getHeaderView();
            e.tools.show(new Iori.Views.Actions()), e.menuArea.show(new Iori.Views.Menu());
        },
        showPreviewView: function (e) {
            var t = this.getHeaderView();
            t.menuArea.show(new Iori.Views.ResponsiveMenu()), t.logoArea.show(new Iori.Views.BackButton()), t.tools.show(new Iori.Views.InsertWrapper({
                model: e
            })), this.modalContent.show(new Iori.Views.Preview({
                url: e.get("url")
            }));
        },
        showTemplatesView: function (e) {
            this.showDefaultHeader(), this.modalContent.show(new Iori.Views.TemplateCollection({
                collection: e
            }));
        },
    });
    
    Iori.Manager = function () {
        function i() {
            var i = e(this).closest(".elementor-top-section"),
                a = i.data("id"),
                n = t.documents.getCurrent().container.children,
                r = i.prev(".elementor-add-section");
            n &&
                _.each(n, function (e, t) {
                    a === e.id && (p.atIndex = t);
                }),
                r.find(".elementor-add-iori-button").length || r.find(FIND_IORI_BTN_SELECTOR).before($openIoriPanel);
        }

        function n(e) {
            var t = e.find(FIND_IORI_BTN_SELECTOR);
            t.length && !e.find(".elementor-add-iori-button").length && t.before($openIoriPanel), e.on("click.onAddElement", ".elementor-editor-section-settings .elementor-editor-element-add", i);
        }

        function r(t, i) {
            i.addClass("elementor-active").siblings().removeClass("elementor-active");
            var a = devicesResponsiveMap[t] || devicesResponsiveMap.desktop;
            e(".ioriElementor__preview").css("width", a);
        }

        function l() {
            var e = window.elementor.$previewContents,
                t = setInterval(function () {
                    n(e), e.find(".elementor-add-new-section").length > 0 && clearInterval(t);
                }, 100);
            e.on("click.onAddTemplateButton", ".elementor-add-iori-button", p.showModal.bind(p)), this.channels.tabs.on("change:device", r);
        }
        var o,
            s,
            d,
            c,
            m,
            p = this;
        (FIND_IORI_BTN_SELECTOR = ".elementor-add-new-section .elementor-add-section-drag-title"),
        ($openIoriPanel = '<div class="elementor-add-section-area-button elementor-add-iori-button"> D </div>'),
        (devicesResponsiveMap = {
            desktop: "100%",
            tab: "768px",
            mobile: "360px"
        }),
        (this.atIndex = -1),
        (this.channels = {
            tabs: Backbone.Radio.channel("tabs"),
            templates: Backbone.Radio.channel("templates")
        }),
        (this.updateBlocksView = function () {
            p.setFilter("tags", "", !0), p.setFilter("text", "", !0), p.getModal().showTemplatesView(c);
        }),
        (this.setFilter = function (e, t, i) {
            p.channels.templates.reply("filter:" + e, t), i || p.channels.templates.trigger("filter:change");
        }),
        (this.getFilter = function (e) {
            return p.channels.templates.request("filter:" + e);
        }),
        (this.getFilterTerms = function () {
            return {
                tags: {
                    callback: function (e) {
                        return _.any(this.get("tags"), function (t) {
                            return t.indexOf(e) >= 0;
                        });
                    },
                },
                text: {
                    callback: function (e) {
                        return (
                            (e = e.toLowerCase()),
                            this.get("title").toLowerCase().indexOf(e) >= 0 ||
                            _.any(this.get("tags"), function (t) {
                                return t.indexOf(e) >= 0;
                            })
                        );
                    },
                },
                type: {
                    callback: function (e) {
                        return this.get("type") === e;
                    },
                },
            };
        }),
        (this.showModal = function () {
            p.getModal().showModal(), p.showTemplatesView();
        }),
        (this.closeModal = function () {
            this.getModal().hideModal();
        }),
        (this.getModal = function () {
            return o || (o = new Iori.Modal()), o;
        }),
        (this.init = function () {
            p.setFilter("type", "section", !0), t.on("preview:loaded", l.bind(this));
        }),
        (this.getTabs = function () {
            var e = this.getFilter("type");
            return (
                (tabs = {
                    section: {
                        title: "Blocks"
                    },
                    page: {
                        title: "Pages"
                    }
                }),
                _.each(tabs, function (t, i) {
                    e === i && (tabs[e].active = !0);
                }), {
                    tabs: tabs
                }
            );
        }),
        (this.getTags = function () {
            return s;
        }),
        (this.getTypeTags = function () {
            var e = p.getFilter("type");
            // console.log(d);
            return d[e];
        }),
        (this.showTemplatesView = function () {
            p.setFilter("tags", "", !0),
                p.setFilter("text", "", !0),
                c ?
                p.getModal().showTemplatesView(c) :
                p.loadTemplates(function () {
                    p.getModal().showTemplatesView(c);
                });
        }),
        (this.showPreviewView = function (e) {
            p.getModal().showPreviewView(e);
        }),
        (this.loadTemplates = function (e) {
            p.requestLibraryData({
                onBeforeUpdate: p.getModal().showLoadingView.bind(p.getModal()),
                onUpdate: function () {
                    p.getModal().hideLoadingView(), e && e();
                },
            });
        }),
        (this.requestLibraryData = function (e) {
            if (c && !e.forceUpdate) return void(e.onUpdate && e.onUpdate());
            e.onBeforeUpdate && e.onBeforeUpdate();
            var t = {
                data: {},
                success: function (t) {
                    (c = new Iori.Collections.Template(t.templates)), t.tags && (s = t.tags), t.type_tags && (d = t.type_tags), e.onUpdate && e.onUpdate();
                },
            };
            e.forceSync && (t.data.sync = !0), elementorCommon.ajax.addRequest("get_iori_library_data", t);
        }),
        (this.requestTemplateData = function (e, t) {
            var i = {
                unique_id: e,
                data: {
                    edit_mode: !0,
                    display: !0,
                    template_id: e
                }
            };
            t && jQuery.extend(!0, i, t), elementorCommon.ajax.addRequest("get_iori_template_data", i);
        }),
        (this.insertTemplate = function (e) {
            var t = e.model,
                i = this;
            i.getModal().showLoadingView(),
                i.requestTemplateData(t.get("template_id"), {
                    success: function (e) {
                        i.getModal().hideLoadingView(), i.getModal().hideModal();
                        var a = {}; -
                        1 !== i.atIndex && (a.at = i.atIndex), $e.run("document/elements/import", {
                            model: t,
                            data: e,
                            options: a
                        }), (i.atIndex = -1);
                    },
                    error: function (e) {
                        i.showErrorDialog(e);
                    },
                    complete: function (e) {
                        i.getModal().hideLoadingView(), window.elementor.$previewContents.find(".elementor-add-section .elementor-add-section-close").click();
                    },
                });
        }),
        (this.showErrorDialog = function (e) {
            if ("object" == typeof e) {
                var t = "";
                _.each(e, function (e) {
                        t += "<div>" + e.message + ".</div>";
                    }),
                    (e = t);
            } else e ? (e += ".") : (e = "<i>&#60;The error message is empty&#62;</i>");
            p.getErrorDialog()
                .setMessage('The following error(s) occurred while processing the request:<div id="elementor-template-library-error-info">' + e + "</div>")
                .show();
        }),
        (this.getErrorDialog = function () {
            return m || (m = elementorCommon.dialogsManager.createWidget("alert", {
                id: "elementor-template-library-error-dialog",
                headerMessage: "An error occurred"
            })), m;
        });
    };

    i.library = new Iori.Manager(),
    i.library.init(),
        (window.iori = i);
})(jQuery, window.elementor, window.iori || {});