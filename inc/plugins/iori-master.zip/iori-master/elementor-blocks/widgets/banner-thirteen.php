<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner Thirteen
 *
 * Elementor widget for banner thirteen
 *
 * @since 1.0.0
 */
class Banner_Thirteen extends Widget_Base {


	public function get_name() {
		return 'iori-banner-thirteen';
	}

	public function get_title() {
		return esc_html__( 'Banner Thirteen', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-thirteen', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_thirteen_section',
			array(
				'label' => __( 'Banner Thirteen', 'iori' ),
			)
		);

		$this->add_control(
			'banner_thirteen_breadcrumb_item1',
			array(
				'label'       => __( 'Item One', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_thirteen_breadcrumb_item1_link',
			array(
				'label'       => __( 'Item One Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_thirteen_breadcrumb_item2',
			array(
				'label'       => __( 'Item Two', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_thirteen_breadcrumb_item2_link',
			array(
				'label'       => __( 'Item Two Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_thirteen_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_thirteen_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_thirteen_img',
			array(
				'label'       => esc_html__( 'Banner Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->end_controls_section();

		// content style

		// title
		$this->start_controls_section(
			'banner_thirteen_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_thirteen_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .content-main .title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_thirteen_title_typography',
				'selector' => '{{WRAPPER}} .content-main .title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_thirteen_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_thirteen_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .content-main .desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_thirteen_desc_typography',
				'selector' => '{{WRAPPER}} .content-main .desc',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="section pt-40 content-term">
			<div class="box-bg-term"></div>
			<div class="container">
				<div class="breadcrumbs">
					<ul>
						<li>
							<a href="<?php echo esc_url( $settings['banner_thirteen_breadcrumb_item1_link'] ); ?>">
								<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
								</svg>
								<?php echo esc_html( $settings['banner_thirteen_breadcrumb_item1'] ); ?>
							</a>
						</li>
						<li>
							<a href="<?php echo esc_url( $settings['banner_thirteen_breadcrumb_item2_link'] ); ?>"><?php echo esc_html( $settings['banner_thirteen_breadcrumb_item2'] ); ?></a>
						</li>
					</ul>
				</div>
				<div class="content-main mt-50">
					<div class="text-center">
						<h2 class="title mb-10"><?php echo esc_html( $settings['banner_thirteen_title'] ); ?></h2>
						<div class="desc"><?php echo $settings['banner_thirteen_desc']; ?></div>
						<div class="box-image-head mt-50 mb-50">
							<img class="bd-rd8" src="<?php echo $settings['banner_thirteen_img']['url']; ?>" alt="iori">
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php
	}
}
