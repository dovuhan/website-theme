<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Gallery
 *
 * Elementor widget for gallery
 *
 * @since 1.0.0
 */
class Gallery extends Widget_Base {


	public function get_name() {
		return 'iori-gallery';
	}

	public function get_title() {
		return esc_html__( 'Gallery', 'iori' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'gallery', 'image', 'picture', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'gallery_section',
			array(
				'label' => esc_html__( 'Gallery', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_pre_style',
			array(
				'label'       => __( 'Gallery Style', 'iori' ),
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'style1'  => __( 'Style 1', 'iori' ),
					'style2'  => __( 'Style 2', 'iori' ),
					'style3'  => __( 'Style 3', 'iori' ),
					'style4'  => __( 'Style 4', 'iori' ),
					'style5'  => __( 'Style 5', 'iori' ),
					'style6'  => __( 'Style 6', 'iori' ),
					'style7'  => __( 'Style 7', 'iori' ),
					'style8'  => __( 'Style 8', 'iori' ),
					'style9'  => __( 'Style 9', 'iori' ),
					'style10' => __( 'Style 10', 'iori' ),
				),
				'default'     => 'style1',
			)
		);

		$this->add_control(
			'box_image_main',
			array(
				'label'   => esc_html__( 'Main Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'box_image_right',
			array(
				'label'   => esc_html__( 'Image Right', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'box_image_left',
			array(
				'label'   => esc_html__( 'Image Left', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->end_controls_section();

		// start style here
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<?php
		$gallery_pre_style = $settings['gallery_pre_style'];

		if ( 'style1' == $gallery_pre_style ) {

			?>
			<div class="box-images-project">
				<div class="box-images mt-50"><img class="img-main-2" src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
					<div class="image-2 shape-3"><img src="<?php echo $settings['box_image_right']['url']; ?>" alt="iori"></div>
					<div class="image-3 shape-1"><img src="<?php echo $settings['box_image_left']['url']; ?>" alt="iori"></div>
				</div>
			</div>

		<?php } elseif ( 'style2' == $gallery_pre_style ) { ?>

			<div class="box-images-project">
				<div class="box-images wow animate__animated animate__fadeIn"><img class="img-main-2" src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
					<div class="shape-1 image-4"><img src="<?php echo $settings['box_image_right']['url']; ?>" alt="iori"></div>
					<div class="shape-2 image-5"><img src="<?php echo $settings['box_image_left']['url']; ?>" alt="iori"></div>
				</div>
			</div>

		<?php } elseif ( 'style3' == $gallery_pre_style ) { ?>

			<div class="box-images-project mw-80">
				<img class="img-round-top" src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
				<div class="shape-1 image-4">
					<img class="img-round-top" src="<?php echo $settings['box_image_right']['url']; ?>" alt="iori">
				</div>
			</div>

		<?php } elseif ( 'style4' == $gallery_pre_style ) { ?>

			<div class="box-images-cover">
				<div class="box-images-inner">
					<img class="img-project bd-rd16" src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
					<div class="image-6 shape-3"><img src="<?php echo $settings['box_image_right']['url']; ?>" alt="iori">
					</div>
				</div>
			</div>

		<?php } elseif ( 'style5' == $gallery_pre_style ) { ?>

			<div class="box-images-cover text-end">
				<div class="box-images-inner">
					<img class="img-project bd-rd16" src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
					<div class="image-7 shape-3"><img src="<?php echo $settings['box_image_left']['url']; ?>" alt="iori"></div>
				</div>
			</div>

		<?php } elseif ( 'style6' == $gallery_pre_style ) { ?>

			<div class="box-banner-6">
				<div class="img-testimonials-1 shape-1">
					<img src="<?php echo $settings['box_image_left']['url']; ?>" alt="iori">
				</div>
				<div class="img-testimonials-2 shape-2">
					<img src="<?php echo $settings['box_image_right']['url']; ?>" alt="iori">
				</div>
				<img class="img-main" src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
			</div>

		<?php } elseif ( 'style7' == $gallery_pre_style ) { ?>

			<div class="box-phones">
				<div class="box-phones-inner">
					<div class="img-phone-1 wow animate__animated animate__zoomIn" data-wow-delay=".0s">
						<img src="<?php echo $settings['box_image_left']['url']; ?>" alt="iori">
					</div>
					<div class="img-phone-2 wow animate__animated animate__zoomIn" data-wow-delay=".4s">
						<img src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
					</div>
				</div>
			</div>

		<?php } elseif ( 'style8' == $gallery_pre_style ) { ?>

			<div class="box-imgs-branding text-end">
				<div class="wow animate__animated animate__fadeIn" data-wow-delay=".0s">
					<img class="img-round-top" src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
				</div>
				<div class="img-branding-small wow animate__animated animate__fadeIn" data-wow-delay=".4s">
					<img class="img-round-top-small" src="<?php echo $settings['box_image_left']['url']; ?>" alt="iori">
				</div>
			</div>

		<?php } elseif ( 'style9' == $gallery_pre_style ) { ?>

			<div class="box-banner-help">
				<div class="box-cruelty shape-1">
					<img src="<?php echo $settings['box_image_right']['url']; ?>" alt="iori">
				</div>
				<div class="banner-img-1">
					<img src="<?php echo $settings['box_image_left']['url']; ?>" alt="iori">
				</div>
				<div class="banner-img-2">
					<img src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
				</div>
			</div>

		<?php } else { ?>

			<div class="box-video mt-70">
				<img src="<?php echo $settings['box_image_main']['url']; ?>" alt="iori">
				<div class="image-1 shape-1">
					<img src="<?php echo $settings['box_image_left']['url']; ?>" alt="iori">
				</div>
			</div>

		<?php } ?>


		<?php
	}
}
