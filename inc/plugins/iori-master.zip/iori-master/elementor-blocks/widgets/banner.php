<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Banner extends Widget_Base {


	public function get_name() {
		return 'iori-banner';
	}

	public function get_title() {
		return esc_html__( 'Banner', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'banner_content',
			array(
				'label' => esc_html__( 'Banner', 'iori' ),
			)
		);

		$this->add_control(
			'banner_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'banner_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'app_btn',
			array(
				'label'       => __( 'Download App', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'app_btn_link',
			array(
				'label'   => __( 'Download App Link', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '#',
			)
		);

		$this->add_control(
			'more_btn',
			array(
				'label'       => __( 'Learn More', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'more_btn_link',
			array(
				'label'   => __( 'More Button Link', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '#',
			)
		);


		$this->end_controls_section();
		// Content options End

		// title style
		$this->start_controls_section(
			'banner_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-1 .banner_title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_title_typography',
				'selector' => '{{WRAPPER}} .banner-1 .banner_title',
				
			)
		);

		$this->end_controls_section();

		// description style
		$this->start_controls_section(
			'banner_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-1 .banner_desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_desc_typography',
				'selector' => '{{WRAPPER}} .banner-1 .banner_desc',
				
			)
		);

		$this->end_controls_section();

		// app button
		$this->start_controls_section(
			'app_btn_style',
			array(
				'label' => __( 'App Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'app_btn_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'app_btn_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'app_btn_typography',
				'selector' => '{{WRAPPER}} .btn.btn-brand-1',
				
			)
		);


	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<section class="section">
			  <div class="banner-1">
			<div class="row align-items-center">
				<h1 class="banner_title mb-20 text-anim"><?php echo $settings['banner_title']; ?></h1>
				<div class="row">
				  <div class="col-lg-9 wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
					<div class="banner_desc mb-30"><?php echo $settings['banner_desc']; ?></div>
				  </div>
				</div>
				<div class="box-button mt-30 wow animate__animated animate__fadeInUp" data-wow-delay=".4s"><a class="btn btn-brand-1 hover-up" href="<?php echo esc_html( $settings['app_btn_link'] ); ?>"><?php echo esc_html( $settings['app_btn'] ); ?></a><a class="btn btn-default font-sm-bold hover-up" href="<?php echo esc_html( $settings['more_btn_link'] ); ?>"><?php echo esc_html( $settings['more_btn'] ); ?>
					<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
					</svg></a>
				</div>
				</div>
			</div>
		  </section>

		<?php
	}
}
