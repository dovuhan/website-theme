<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Slider Four
 *
 * @since 1.0.0
 */

class Slider_Four extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-slider-four';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Slider Four', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-slider d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'slider', 'four', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'slider_four_section',
			array(
				'label' => __( 'Slider Four', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'slider_four_img',
			array(
				'label'   => esc_html__( 'Upload Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$repeater->add_control(
			'slider_four_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$repeater->add_control(
			'slider_four_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '', 'iori' ),
			)
		);

		$repeater->add_control(
			'slider_four_btn_text',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$repeater->add_control(
			'slider_four_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		// slider four box
		$repeater->add_control(
			'slider_four_card_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .card-offer-style-3 .card-head' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'slider_four_item_list',
			array(
				'label'   => __( 'Slider Four Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'slider_four_img'           => '',
						'slider_four_title'         => '',
						'slider_four_desc'          => '',
						'slider_four_btn_text'      => '',
						'slider_four_btn_link'      => '',
						'slider_four_card_bg_color' => '',

					),
					array(
						'slider_four_img'           => '',
						'slider_four_title'         => '',
						'slider_four_desc'          => '',
						'slider_four_btn_text'      => '',
						'slider_four_btn_link'      => '',
						'slider_four_card_bg_color' => '',
					),
					array(
						'slider_four_img'           => '',
						'slider_four_title'         => '',
						'slider_four_desc'          => '',
						'slider_four_btn_text'      => '',
						'slider_four_btn_link'      => '',
						'slider_four_card_bg_color' => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// start style here

		// title
		$this->start_controls_section(
			'slider_four_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'slider_four_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-offer-style-3 .slider_four_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'slider_four_title_typography',
				'selector' => '{{WRAPPER}} .card-offer-style-3 .slider_four_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'slider_four_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'slider_four_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .slider_four_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'slider_four_desc_typography',
				'selector' => '{{WRAPPER}} .card-info .slider_four_desc',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$slider_four_item_lists = $settings['slider_four_item_list'];

		?>

		<div class="box-swiper swiper-style-2">
			<div class="swiper-container swiper-group-4">
				<div class="swiper-wrapper">

					<?php
					foreach ( $slider_four_item_lists as $slider_four_item_list ) { 
						?>
						<div class="swiper-slide">
							<div class="card-offer-style-3">
								<div class="card-head elementor-repeater-item-<?php echo esc_attr( $slider_four_item_list['_id'] ); ?>">
									<div class="card-image">
										<img src="<?php echo $slider_four_item_list['slider_four_img']['url']; ?>" alt="iori">
									</div>
									<div class="carrd-title">
										<h4 class="slider_four_title"><?php echo esc_html( $slider_four_item_list['slider_four_title'] ); ?></h4>
									</div>
								</div>
								<div class="card-info">
									<div class="slider_four_desc mb-15"><?php echo ( $slider_four_item_list['slider_four_desc'] ); ?></div>
									<div class="box-button-offer">
										<a href="<?php echo esc_html( $slider_four_item_list['slider_four_btn_link'] ); ?>" class="btn btn-default font-sm-bold pl-0 hover-up"><?php echo esc_html( $slider_four_item_list['slider_four_btn_text'] ); ?>
											<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
											</svg>
										</a>
									</div>
								</div>
							</div>
						</div>
					<?php } ?>
				</div>
			</div>
			<div class="box-button-slider-bottom">
				<div class="swiper-button-prev swiper-button-prev-group-4">
					<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
					</svg>
				</div>
				<div class="swiper-button-next swiper-button-next-group-4">
					<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
					</svg>
				</div>
			</div>
		</div>


		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				jQuery(".swiper-group-4").each(function() {
					var swiper_4_items = new Swiper(this, {
						spaceBetween: 30,
						slidesPerView: 4,
						slidesPerGroup: 1,
						loop: true,
						navigation: {
							nextEl: ".swiper-button-next-group-4",
							prevEl: ".swiper-button-prev-group-4"
						},
						pagination: {
							el: ".swiper-pagination-group-4",
							clickable: true
						},
						autoplay: {
							delay: 10000
						},
						breakpoints: {
							1399: {
								slidesPerView: 4
							},
							1100: {
								slidesPerView: 3
							},
							780: {
								slidesPerView: 2
							},
							500: {
								slidesPerView: 1
							},
							400: {
								slidesPerView: 1
							},
							350: {
								slidesPerView: 1
							},
							150: {
								slidesPerView: 1
							}
						}
					});
				});
			</script>
		<?php } ?>

		<?php
	}
}
