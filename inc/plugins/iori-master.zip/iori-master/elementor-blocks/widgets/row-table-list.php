<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class Price_Table extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-price-table';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Row Table List', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'price', 'money', 'table', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

	protected function _register_controls() {
		$this->start_controls_section(
			'table_section',
			array(
				'label' => 'Price Table',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'table_name',
			array(
				'label'   => 'Table Name',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'table_name_list',
			array(
				'label'   => 'Table Heading',
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'table_name' => 'Name',
					),
					array(
						'table_name' => 'Status',
					),
					array(
						'table_name' => 'Items',
					),
					array(
						'table_name' => 'Per Value',
					),
				),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'data',
			array(
				'label'   => 'Data',
				'type'    => Controls_Manager::TEXT,
				'default' => 'Data',
			)
		);

		$repeater->add_control(
			'free',
			array(
				'label'   => 'Free',
				'type'    => Controls_Manager::TEXT,
				'default' => 'Free',
			)
		);

		$repeater->add_control(
			'standard',
			array(
				'label'   => 'Standard',
				'type'    => Controls_Manager::TEXT,
				'default' => 'Standard',
			)
		);

		$repeater->add_control(
			'business',
			array(
				'label'   => 'Business',
				'type'    => Controls_Manager::TEXT,
				'default' => 'Business',
			)
		);

		$repeater->add_control(
			'enterprise',
			array(
				'label'   => 'Enterprise',
				'type'    => Controls_Manager::TEXT,
				'default' => 'Enterprise',
			)
		);

		$this->add_control(
			'table_data',
			array(
				'label'       => 'Table Data',
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'data'       => 'Requests Quota',
						'free'       => '50k Requests/Day',
						'standard'   => '100k Requests/Day',
						'business'   => '100k Requests/Day',
						'enterprise' => '100k Requests/Day',
					),
					array(
						'data'       => 'Account Access',
						'free'       => '35',
						'standard'   => '85',
						'business'   => '100k Requests/Day',
						'enterprise' => '100k Requests/Day',
					),
					array(
						'data'       => 'Service Analytics',
						'free'       => '<svg class="w-6 h-6 icon-18 icon-disable" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>',
						'standard'   => '<svg class="w-6 h-6 icon-18 icon-disable" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>',
						'business'   => '100k Requests/Day',
						'enterprise' => '100k Requests/Day',
					),
					array(
						'data'       => 'Archive Nodes',
						'free'       => '<svg class="w-6 h-6 icon-18 icon-disable" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>',
						'standard'   => '<svg class="w-6 h-6 icon-18 icon-enable" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"></path></svg>',
						'business'   => '100k Requests/Day',
						'enterprise' => '100k Requests/Day',
					),
				),
				'title_field' => '{{{ data }}}',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$table_name_lists = $settings['table_name_list'];
		?>
		<div class="table-responsive table-responsive-sm table-responsive-md">
			<table class="table table-compare">
				<thead>
					<tr>
						<?php foreach ( $table_name_lists as $index => $table_name_list ) : ?>
							<th class="<?php echo ( $index === 0 ) ? 'width-28 color-success' : ''; ?>"><?php echo $table_name_list['table_name']; ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $settings['table_data'] as $item ) : ?>
						<tr>
							<td><?php echo $item['data']; ?></td>
							<td><?php echo $item['free']; ?></td>
							<td><?php echo $item['standard']; ?></td>
							<td><?php echo $item['business']; ?></td>
							<td><?php echo $item['enterprise']; ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
