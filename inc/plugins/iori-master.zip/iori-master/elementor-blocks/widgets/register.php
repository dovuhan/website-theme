<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Team
 *
 * @since 1.0.0
 */

class Register extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-register';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Register', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-person d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'register', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'team_section',
			array(
				'label' => __( 'Register Page', 'iori' ),
			)
		);

		$this->add_control(
			'anchor_description',
			array(
				'raw'             => __( '<b>Note - Please check without loggedin stage.</b>', 'iori' ),
				'type'            => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-descriptor',
			)
		);

		$repeater = new Repeater();
		
		// code here
		$repeater->add_control(
			'steps',
			array(
				'label'       => esc_html__( 'Steps', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Register',
			)
		);

		$repeater->add_control(
			'steps_desc',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);



		$this->add_control(
			'steps_list',
			array(
				'label'   => __( 'Steps', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'steps'      => 'Register',
						'steps_desc' => 'All you need is your name, email and a strong password, Or use your social media accounts.',
					),
					array(
						'steps'      => 'Activate',
						'steps_desc' => 'Use the code sent to your email to activate your account.',
					),
					array(
						'steps'      => 'Open a trading account',
						'steps_desc' => 'Create a real or demo trading account on our platform. No credit card required.',
					),
					array(
						'steps'      => 'Connect with investors',
						'steps_desc' => 'With a real-time analysis system you will become a professional investor.',
					),
					array(
						'steps'      => 'Almost done',
						'steps_desc' => 'Start your amazing journey on our platform.',
					),
				
				),
			)
		);


		$this->add_control(
			'login_page_link',
			array(
				'label'       => esc_html__( 'Login Page Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '/login',
			)
		);


		$this->end_controls_section();


		$this->start_controls_section(
			'login_section',
			array(
				'label' => __( 'If LoggedIn Active', 'iori' ),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => __( 'Login: Section Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Welcome back',
			)
		);

		$this->add_control(
			'desc',
			array(
				'label'       => __( 'Login: Description', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Fill your email address and password to sign in',
			)
		);

		$this->add_control(
			'img',
			array(
				'label'       => __( 'Login: Section Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'login_msg',
			array(
				'label'       => __( 'Login: Login Message', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Thanks For Login',
			)
		);


		$this->end_controls_section();

		// start style here

		// title
		$this->start_controls_section(
			'team_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'team_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-login h2' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'team_title_typography',
				'selector' => '{{WRAPPER}} .box-banner-login h2',
				
			)
		);


		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'team_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'team_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-login p' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'team_desc_typography',
				'selector' => '{{WRAPPER}} .box-banner-login p',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();


		if ( is_user_logged_in() ) { ?>
			<section class="section box-page-register position-relative float-start">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-xxl-5 col-xl-12 col-lg-12">
							<div class="box-banner-login">
								<h2 class="title color-brand-1 mb-15 mt-0 wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html__( $settings['title'], 'iori' ); ?></h2>
								<p class="font-md color-grey-500 wow animate__animated animate__fadeIn" data-wow-delay=".2s"><?php echo esc_html__( $settings['desc'], 'iori' ); ?></p>
								<div class="line-login mt-25 mb-50"></div>
								<div class="row wow animate__animated animate__fadeIn" data-wow-delay=".4s">
									<h4><?php echo $settings['login_msg']; ?></h4>
									<div class="col-lg-5">
										<div class="form-group mb-25">
											<a class="logged-btn btn btn-brand-lg btn-full font-md-bold" href="<?php echo esc_url( site_url( 'wp-admin' ) ); ?>"><?php echo esc_html__( 'Go To Dashboard', 'iori' ); ?></a>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xxl-7 col-xl-5 col-lg-6 pr-0">
							<div class="d-none d-xxl-block pl-70">
								<div><img class="w-100 d-block" src="<?php echo $settings['img']['url']; ?>" alt="iori"></div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<?php
		} else {
			?>

			<section class="section box-page-register">
				<div class="container">
					<div class="row">
						<div class="col-lg-5">
							<div class="box-steps-small">
								<?php 
								$i = 1;
								foreach ( $settings['steps_list'] as $key => $step ) {
									?>
								<div class="item-number hover-up active wow animate__animated animate__fadeInLeft" data-wow-delay=".0<?php echo $i; ?>s">
									<div class="num-ele"><?php echo $i; ?></div>
									<div class="info-num">
										<h5 class="color-brand-1 mb-15 mt-0"><?php echo $step['steps']; ?></h5>
										<p class="font-md color-grey-500"><?php echo $step['steps_desc']; ?></p>
									</div>
								</div>
									<?php
									$i++;
								} 
								?>
								
							</div>
						</div>
						<div class="col-lg-7">
							<div class="box-register">
							<form action="<?php echo esc_url( site_url( 'wp-login.php?action=register', 'login_post' ) ); ?>" method="post">
								<h2 class="color-brand-1 mb-15 wow animate__animated animate__fadeIn" data-wow-delay=".0s">Create an account</h2>
								<p class="font-md color-grey-500 wow animate__animated animate__fadeIn" data-wow-delay=".0s">Create an account today and start using our platform</p>
								<div class="line-register mt-25 mb-50"></div>
								<div class="row wow animate__animated animate__fadeIn" data-wow-delay=".0s">
								
									<div class="col-lg-6 col-sm-6">
										<div class="form-group mb-25">
											<input class="form-control icon-name" name="first_name" type="text" placeholder="Your name">
										</div>
									</div>
									<div class="col-lg-6 col-sm-6">
										<div class="form-group mb-25">
											<input class="form-control icon-phone" name="user_phone" type="text" placeholder="Phone">
										</div>
									</div>
									<div class="col-lg-6 col-sm-6">
										<div class="form-group mb-25">
											<input class="form-control icon-email" name="user_email" type="text" placeholder="Email">
										</div>
									</div>
									<div class="col-lg-6 col-sm-6">
										<div class="form-group mb-25">
											<input class="form-control icon-user"  name="user_login" type="text" placeholder="Username">
										</div>
									</div>
									<?php
									/**
									 * Fires following the 'Email' field in the user registration form.
									 *
									 * @since 2.1.0
									 */
									do_action( 'register_form' );
									?>
									<input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect_to ); ?>" />
									
									<div class="col-lg-12 mt-15">
										<div class="form-group mb-25">
											<label class="cb-container">
												<input type="checkbox" checked="checked"><span class="text-small">I have read and agree to the Terms & Conditions and the Privacy Policy of this website.</span><span class="checkmark"></span>
											</label>
										</div>
										<div class="form-group mb-25">
											<label class="cb-container">
												<input type="checkbox"><span class="text-small">I want to receive design inspiration and product updates. (No spam. You can opt-out anytime.)</span><span class="checkmark"></span>
											</label>
										</div>
									</div>
								</div>
								<div class="row align-items-center mt-30 wow animate__animated animate__fadeIn" data-wow-delay=".0s">
									<div class="col-xl-5 col-lg-5 col-md-5 col-sm-6 col-6">
										<div class="form-group">
											<button class="btn btn-brand-lg btn-full font-md-bold" type="submit"><?php esc_html_e( 'Sign up now', 'iori' ); ?></button>
										</div>
									</div>
									<div class="col-xl-7 col-lg-7 col-md-7 col-sm-6 col-6"><span class="d-inline-block align-middle font-sm color-grey-500">Already have an account?</span><a class="d-inline-block align-middle color-success ml-3" href="<?php echo $settings['login_page_link']; ?>"> <?php esc_html_e( 'Sign In', 'iori' ); ?></a></div>
								</div>
							</form>
							</div>
						</div>
					</div>
				</div>
			</section>

			<?php
		}
	}
}
