<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor account box
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Account_Box_Two extends Widget_Base {


	public function get_name() {
		return 'iori-account-box-two';
	}

	public function get_title() {
		return esc_html__( 'Account Box Two', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'account', 'box', 'two', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'account_box_two_section',
			array(
				'label' => esc_html__( 'Account Box Two', 'iori' ),
			)
		);

		$this->add_control(
			'account_box_two_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'account_box_two_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'account_box_two_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'account_box_two_self_img',
			array(
				'label'   => esc_html__( 'Personal Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'account_box_two_self_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'account_box_two_self_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'account_box_two_self_img2',
			array(
				'label'   => esc_html__( 'Personal Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'account_box_two_self_title2',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'account_box_two_self_desc2',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'account_box_two_main_img',
			array(
				'label'   => esc_html__( 'Upload Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'account_box_two_counter_number',
			array(
				'label'   => __( 'Number', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '',
			)
		);

		$this->add_control(
			'account_box_two_counter_quantity',
			array(
				'label'   => __( 'Quantity', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'account_box_two_counter_subject',
			array(
				'label'       => __( 'Subject', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->end_controls_section();
		// Content options End

		// subtitle style
		$this->start_controls_section(
			'account_box_two_subtitle_style',
			array(
				'label' => __( 'Sub Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'account_box_two_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-create-account .title-line' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'account_box_two_subtitle_typography',
				'selector' => '{{WRAPPER}} .box-create-account .title-line',
				
			)
		);

		$this->end_controls_section();

		// title style
		$this->start_controls_section(
			'account_box_two_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'account_box_two_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-create-account .title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'account_box_two_title_typography',
				'selector' => '{{WRAPPER}} .box-create-account .title',
				
			)
		);

		$this->end_controls_section();

		// description style
		$this->start_controls_section(
			'account_box_two_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'account_box_two_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-create-account .desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'account_box_two_desc_typography',
				'selector' => '{{WRAPPER}} .box-create-account .desc',
				
			)
		);

		$this->end_controls_section();

		// number
		$this->start_controls_section(
			'account_box_two_number_style',
			array(
				'label' => __( 'Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'account_box_two_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .cardNumber .count' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'account_box_two_number_typography',
				'selector' => '{{WRAPPER}} .cardNumber .count',
				
			)
		);

		$this->end_controls_section();


		// quantity
		$this->start_controls_section(
			'account_box_two_quantity_style',
			array(
				'label' => __( 'Quantity', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'account_box_two_quantity_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .cardNumber .quantity' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'account_box_two_quantity_typography',
				'selector' => '{{WRAPPER}} .cardNumber .quantity',
				
			)
		);

		$this->end_controls_section();

		// subject
		$this->start_controls_section(
			'account_box_two_subject_style',
			array(
				'label' => __( 'Subject', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'account_box_two_subject_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .cardNumber .subject' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'account_box_two_subject_typography',
				'selector' => '{{WRAPPER}} .cardNumber .subject',
				
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<section class="section mt-80">
			<div class="container">
				<div class="box-create-account bg-4">
					<div class="row align-items-center">
						<div class="col-lg-6"><span class="title-line line-48 wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html( $settings['account_box_two_subtitle'] ); ?></span>
							<h2 class="title mb-20 mt-10 wow animate__animated animate__fadeIn" data-wow-delay=".2s"><?php echo esc_html( $settings['account_box_two_title'] ); ?></h2>
							<div class="desc mb-50 wow animate__animated animate__fadeIn" data-wow-delay=".4s"><?php echo $settings['account_box_two_desc']; ?></div>
							<div class="row">
								<div class="col-lg-6 col-sm-6 mb-30 wow animate__animated animate__fadeIn" data-wow-delay=".0s">
									<div class="box-image-bg-60">
										<img class="d-block" src="<?php echo $settings['account_box_two_self_img']['url']; ?>" alt="iori">
									</div>
									<h6 class="color-brand-1 mb-15"><?php echo esc_html( $settings['account_box_two_self_title'] ); ?></h6>
									<div class="font-xs color-grey-500"><?php echo $settings['account_box_two_self_desc']; ?></div>
								</div>
								<div class="col-lg-6 col-sm-6 wow animate__animated animate__fadeIn" data-wow-delay=".2s">
									<div class="box-image-bg-60">
										<img class="d-block" src="<?php echo $settings['account_box_two_self_img2']['url']; ?>" alt="iori">
									</div>
									<h6 class="color-brand-1 mb-15"><?php echo esc_html( $settings['account_box_two_self_title2'] ); ?></h6>
									<div class="font-xs color-grey-500"><?php echo $settings['account_box_two_self_desc2']; ?></div>
								</div>
							</div>
						</div>
						<div class="col-lg-6 position-relative mb-30 box-right">
							<div class="box-image-account">
								<img class="d-block" src="<?php echo $settings['account_box_two_main_img']['url']; ?>" alt="iori">
							</div>
							<div class="cardNumber bg-2">
								<div class="card-head"><span class="count"><?php echo esc_html( $settings['account_box_two_counter_number'] ); ?></span>
									<span class="quantity"><?php echo esc_html( $settings['account_box_two_counter_quantity'] ); ?></span>
								</div>
								<div class="card-description subject"><?php echo esc_html( $settings['account_box_two_counter_subject'] ); ?></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				/*---- CounterUp ----*/
				if (jQuery(".count").length) {
					jQuery(".count").counterUp({
						delay: 10,
						time: 600
					});
				}
			</script>
		<?php } ?>

		<?php
	}
}
