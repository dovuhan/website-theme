<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Exit if accessed directly

/**
 * App Testimonial
 *
 * Elementor app Testimonial Two
 *
 * @since 1.0.0
 */
class Testimonial_Two extends Widget_Base {


	public function get_name() {
		return 'iori-testimonial-two';
	}

	public function get_title() {
		return __( 'Testimonial Two', 'iori' );
	}

	public function get_icon() {
		return 'eicon-testimonial d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'testimonial', 'reviews', 'iori' );
	}

	/**
	 * Register image carousel widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'testimonial_two_section',
			array(
				'label' => __( 'Testimonial Two', 'iori' ),
			)
		);

		$this->add_control(
			'testimonial_two_author_img',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_two_author_img_link',
			array(
				'label'       => esc_html__( 'Image Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_two_author_title',
			array(
				'label'       => __( 'Author Name', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_two_author_title_link',
			array(
				'label'       => esc_html__( 'Author Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_two_author_department',
			array(
				'label'       => __( 'Department', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_two_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_two_rating_star',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_two_rating',
			array(
				'label'   => 'Rating',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 1,
				'max'     => 5,
				'step'    => 1,
			)
		);

		$this->end_controls_section();

		// =========== testimonial style start ===========

		// testimonial box style
		$this->start_controls_section(
			'testimonial_two_box_style',
			array(
				'label' => __( 'Box Style', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_two_box_border_width',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'range'      => array(
					'px' => array(
						'max' => 20,
					),
					'em' => array(
						'max' => 2,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .card-testimonial-list' => 'border-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'testimonial_two_box_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-testimonial-list' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'testimonial_two_box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .card-testimonial-list' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'testimonial_two_box_shadow',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .card-testimonial-list',
			)
		);

		$this->add_control(
			'testimonial_two_box_bg',
			array(
				'label'     => esc_html__( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-testimonial-list' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		// author name
		$this->start_controls_section(
			'testimonial_two_author_title_style',
			array(
				'label' => __( 'Author Name', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_two_author_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-author .author-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_two_author_title_typography',
				
				'selector' => '{{WRAPPER}} .box-author .author-name',
			)
		);

		$this->end_controls_section();

		// department
		$this->start_controls_section(
			'testimonial_two_author_department_style',
			array(
				'label' => __( 'Department', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_two_author_department_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-author .department' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_two_author_department_typography',
				
				'selector' => '{{WRAPPER}} .box-author .department',
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'testimonial_two_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_two_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-testimonial-list .desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_two_desc_typography',
				
				'selector' => '{{WRAPPER}} .card-testimonial-list .desc',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render image carousel widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="card-testimonial-list">
			<div class="d-flex align-items-center">
				<div class="box-author mb-10">
					<a href="<?php echo esc_url( $settings['testimonial_two_author_img_link'] ); ?>">
						<img src="<?php echo $settings['testimonial_two_author_img']['url']; ?>" alt="iori">
					</a>
					<div class="author-info">
						<a href="<?php echo esc_url( $settings['testimonial_two_author_title_link'] ); ?>">
							<span class="author-name"><?php echo esc_html( $settings['testimonial_two_author_title'] ); ?></span>
						</a>
						<span class="department"><?php echo esc_html( $settings['testimonial_two_author_department'] ); ?></span>
					</div>
				</div>
				<div class="rating text-end">
					<?php
					$author_rating = intval( $settings['testimonial_two_rating'] );

					for ( $i = 1; $i <= $author_rating; $i++ ) {
						echo '<img src="' . $settings['testimonial_two_rating_star']['url'] . '">';
					}
					?>
				</div>
			</div>
			<div class="desc"><?php echo $settings['testimonial_two_desc']; ?></div>
		</div>

		<?php
	}
}
