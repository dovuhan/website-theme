<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Banner_Two extends Widget_Base {


	public function get_name() {
		return 'iori-banner-two';
	}

	public function get_title() {
		return esc_html__( 'Banner Two', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-two', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_two_section',
			array(
				'label' => __( 'Banner Two', 'iori' ),
			)
		);

		$this->add_control(
			'banner_two_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_two_desc',
			array(
				'label'       => __( 'Desc', 'iori' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_two_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_two_app_img',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_two_app_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);


		$this->add_control(
			'banner_two_app_img2',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_two_app_img2_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_two_btn',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_two_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_two_bg_img',
			array(
				'label'       => __( 'Background Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_two_bg_img2',
			array(
				'label'       => __( 'Shape Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->end_controls_section();

		// content style

		// title
		$this->start_controls_section(
			'banner_two_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_two_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .color-brand-1' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_two_title_typography',
				'selector' => '{{WRAPPER}} .color-brand-1',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_two_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_two_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-1 .banner_two_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_two_desc_typography',
				'selector' => '{{WRAPPER}} .banner-1 .banner_two_desc',
				
			)
		);

		$this->end_controls_section();

		// subtitle
		$this->start_controls_section(
			'banner_two_subtitle_style',
			array(
				'label' => __( 'Subtitle', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_two_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-1 .subtitle' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_two_subtitle_typography',
				'selector' => '{{WRAPPER}} .banner-1 .subtitle',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$banner_two_app_img  = $settings['banner_two_app_img']['url'];
		$banner_two_app_img2 = $settings['banner_two_app_img2']['url'];
		$banner_two_bg_img   = $settings['banner_two_bg_img']['url'];
		$banner_two_bg_img2  = $settings['banner_two_bg_img2']['url'];

		?>
		<section class="section banner-2" style="background-image:url(<?php echo ( $banner_two_bg_img2 ); ?>)">
			<div class="banner-1">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-lg-7">
							<h1 class="color-brand-1 mb-20 text-anim"><?php echo esc_html( $settings['banner_two_title'] ); ?></h1>
							<div class="row">
								<div class="col-lg-9 wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
									<p class="banner_two_desc"><?php echo esc_html( $settings['banner_two_desc'] ); ?></p>
								</div>
							</div>
							<div class="mt-30 wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
								<h5 class="subtitle"><?php echo esc_html( $settings['banner_two_subtitle'] ); ?></h5>
							</div>
							<div class="box-button mt-20 wow animate__animated animate__fadeInUp" data-wow-delay=".4s"><a class="btn-app mb-15 hover-up" href="<?php echo esc_url( $settings['banner_two_app_img_link'] ); ?>"><img src="<?php echo esc_url( $banner_two_app_img ); ?>" alt="iori"></a><a class="btn-app mb-15 hover-up" href="<?php echo esc_url( $settings['banner_two_app_img2_link'] ); ?>"><img src="<?php echo esc_url( $banner_two_app_img2 ); ?>" alt="iori"></a>
								<a class="btn btn-default mb-15 pl-10 font-sm-bold hover-up" href="<?php echo esc_url( $settings['banner_two_btn_link'] ); ?>"><?php echo esc_html( $settings['banner_two_btn'] ); ?>

									<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
									</svg>

								</a>
							</div>
						</div>
						<div class="col-lg-5 d-none d-lg-block wow animate__animated animate__fadeIn"><img src="<?php echo esc_url( $banner_two_bg_img ); ?>" alt="iori"></div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
