<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class Blog_Two extends Widget_Base {


	public function get_name() {
		return 'iori-blog-two';
	}

	public function get_title() {
		return esc_html__( 'Blog Two', 'iori' );
	}

	public function get_icon() {
		return 'eicon-post-content d-icon';    // eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'blog', 'post', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/
	// public function get_script_depends() {		//load the dependent scripts defined in the iori-elements.php
	// return [ 'section-header' ];
	// }

	protected function register_controls() {
		// main blog post terms
		$blog_two_terms     = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => false,
			)
		);
		$blog_two_cat_names = array();
		foreach ( $blog_two_terms as $t ) :
			$blog_two_cat_names[ $t->term_id ] = $t->name;
		endforeach;

		// start of a control box
		$this->start_controls_section(
			'blog_post_content',
			array(
				'label' => esc_html__( 'Blog Post', 'iori' ),
			)
		);

		$this->add_control(
			'blog_style',
			array(
				'label'   => __( 'Blog Style', 'iori' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'style1' => 'Style 1',
					'style2' => 'Style 2',
				),
				'default' => 'style1',
			)
		);

		$this->add_control(
			'show_post_by',
			array(
				'label'   => __( 'By Category', 'iori' ),
				'type'    => Controls_Manager::SWITCHER,
			)
		);

		$this->add_control(
			'cat_name',
			array(
				'label'     => __( 'From Category', 'iori' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'uncategorized',
				'condition' => array(
					'show_post_by' => 'yes',
				),
				'options'   => $blog_two_cat_names,
			)
		);

		$this->add_control(
			'show_col',
			array(
				'label'   => __( 'Grid Number', 'iori' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'col-xl-3' => '4 Columns',
					'col-xl-4' => '3 Columns',
					'col-xl-6' => '2 Columns',

				),
				'default' => 'col-xl-3',
			)
		);

		$this->add_control(
			'show_post',
			array(
				'label'   => __( 'Number Of Post Show', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
			)
		);

		$this->add_control(
			'offset_post',
			array(
				'label'       => __( 'Offset Post', 'iori' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => 'Offset 2 means omit first 2 post',
			)
		);


		$this->add_control(
			'show_view_more',
			array(
				'label'   => __( 'View More', 'iori' ),
				'type'    => Controls_Manager::SWITCHER,
			)
		);

		$this->add_control(
			'view_more_txt',
			array(
				'label'     => __( 'View More Text', 'iori' ),
				'type'      => Controls_Manager::TEXT,
				'condition' => array(
					'show_view_more' => 'yes',
				),
				'default'   => 'View more in this category',
			)
		);

		$this->add_control(
			'view_more_link',
			array(
				'label'     => __( 'View More Link', 'iori' ),
				'condition' => array(
					'show_view_more' => 'yes',
				),
				'type'      => Controls_Manager::TEXT,
				'default'   => '#',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'blog_two_title_style',
			array(
				'label' => esc_html__( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'blog_two_title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#404040',
				'selectors' => array(
					'{{WRAPPER}} .card-blog-grid-2 .blog_two_title, {{WRAPPER}} .color-brand-1' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'blog_two_title_typography',
				'selector' => '{{WRAPPER}} .card-blog-grid-2 .blog_two_title, {{WRAPPER}} .color-brand-1'
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'blog_two_desc_style',
			array(
				'label' => esc_html__( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'word_show_post',
			array(
				'label'   => __( 'Word Show', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 145,
			)
		);

		$this->add_control(
			'blog_two_desc_color',
			array(
				'label'     => esc_html__( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .card-blog-grid-2 .blog_two_desc, {{WRAPPER}} .card-info p' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'blog_two_desc_typography',
				'selector' => '{{WRAPPER}} .card-blog-grid-2 .blog_two_desc, {{WRAPPER}} .card-info p'
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		// to show on the fontend
		$settings = $this->get_settings_for_display();

		$column_no = $settings['show_col'] ? 'col-lg-6 col-md-6 ' . $settings['show_col'] : 'col-xl-3 col-lg-6 col-md-6';

		?>

		<section class="section">
			<div class="container">
				<div class="row">
				
					<?php
					if ( $settings['show_post_by'] == 'yes' ) {
						$blog_two = array(
							'cat'                 => $settings['cat_name'],
							'post_type'           => 'post',
							'post_status'         => 'publish',
							'posts_per_page'      => $settings['show_post'],
							'offset'              => $settings['offset_post'],
							'ignore_sticky_posts' => 1,
						);
					} else {
						$blog_two = array(
							'post_type'           => 'post',
							'post_status'         => 'publish',
							'posts_per_page'      => $settings['show_post'],
							'offset'              => $settings['offset_post'],
							'ignore_sticky_posts' => 1,
						);
					}

					

					$blog_two_query = new \WP_Query( $blog_two );
					$i              = 1;
					if ( $blog_two_query->have_posts() ) :
						while ( $blog_two_query->have_posts() ) :
							$blog_two_query->the_post();

							$cat_names = get_the_category();
							$cat_name  = $cat_names[0]->cat_name;

							if ( $settings['blog_style'] === 'style2' ) {
								?>
							<div class="<?php echo esc_attr( $column_no ); ?> mb-30 item-article <?php echo strtolower( str_replace( ' ', '-', $cat_name ) ); ?> wow animate__animated animate__fadeIn" data-wow-delay=".0<?php echo $i; ?>s">
								<div class="card-blog-grid card-blog-grid-3 hover-up">
								<div class="card-image img-reveal">
								<a href="<?php the_permalink(); ?>">
									<?php if ( has_post_thumbnail() ) { ?>
										<?php the_post_thumbnail(); ?>
									<?php } ?>
								</a>
									<label class="lbl-border"><?php echo $cat_name; ?></label>
								</div>
								<div class="card-info"><a href="<?php the_permalink(); ?>">
									<h4 class="color-brand-1"><?php the_title(); ?></h4></a>
									<div class="mb-25 mt-10"><span class="font-xs color-grey-500"><?php echo get_the_date(); ?></span><span class="font-xs color-grey-500 icon-read"><?php echo iori_reading_time(); ?></span></div>
									<p class="font-sm color-grey-500 mt-20"><?php echo $this->the_excerpt_max_charlength( $settings['word_show_post'] ); ?></p>
								</div>
								</div>
							</div>
							<?php } else { ?>
								<div class="<?php echo esc_attr( $column_no ); ?> <?php echo strtolower( str_replace( ' ', '-', $cat_name ) ); ?> wow animate__animated animate__fadeIn" data-wow-delay=".0s">
								<div class="card-blog-grid card-blog-grid-2 hover-up">
									<div class="card-image img-reveal">
										<a href="<?php the_permalink(); ?>">
											<?php if ( has_post_thumbnail() ) { ?>
												<?php the_post_thumbnail(); ?>
											<?php } ?>
										</a>
									</div>
									<div class="card-info"><a href="<?php the_permalink(); ?>">
											<h6 class="blog_two_title"><?php the_title(); ?></h6>
										</a>
										<p class="blog_two_desc mt-20"><?php echo $this->the_excerpt_max_charlength( $settings['word_show_post'] ); ?></p>
										<div class="mt-20 d-flex align-items-center border-top pt-20">
											<span class="btn btn-border-brand-1 mr-15"><?php echo $cat_name; ?></span>
											<span class="date-post font-xs color-grey-300 mr-15">
												<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
												</svg><?php echo get_the_date(); ?>
											</span>
											<span class="time-read font-xs color-grey-300">
												<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
												</svg><?php echo iori_reading_time(); ?>
											</span>
										</div>
									</div>
								</div>
							</div>
							
								<?php 
								$i++;
							} 
							?>

						<?php endwhile; ?>
						<?php
					endif;
					wp_reset_postdata();
					?>

				</div>
				<?php if ( $settings['show_view_more'] ) { ?>
				<div class="mt-0 mb-30 text-center"><a class="btn btn-white-circle font-sm-bold border-brand text-none" href="<?php echo $settings['view_more_link']; ?>"><?php echo $settings['view_more_txt']; ?></a></div>
				<?php } ?>
			</div>
		</section>

			<?php
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				?>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" integrity="sha512-16esztaSRplJROstbIIdwX3N97V1+pZvV33ABoG1H2OyTttBxEGkTsoIVsiP1iaTtM8b3+hu2kB6pQ4Clr5yug==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
			<script>
				//Image amination 1
				const imgOptions2 = {
					root: null,
					rootMargin: "0px",
					threshold: 0.9
				};

				let ImgRevealCallback2 = (entries, self) => {
					entries.forEach((entry) => {
						let container = entry.target;
						let img = entry.target.querySelector("img");
						const easeInOut = "power3.out";
						const revealAnim = gsap.timeline({
							ease: easeInOut
						});

						if (entry.isIntersecting) {
							revealAnim.set(container, {
								visibility: "visible"
							});
							revealAnim.fromTo(
								container, {
									clipPath: "polygon(0 0, 0 0, 0 100%, 0% 100%)",
									webkitClipPath: "polygon(0 0, 0 0, 0 100%, 0% 100%)"
								}, {
									clipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
									webkitClipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
									duration: 1,
									ease: easeInOut
								}
							);
							revealAnim.from(img, 4, {
								scale: 1.4,
								ease: easeInOut,
								delay: -1
							});
							self.unobserve(entry.target);
						}
					});
				};

				let ImRevealObserver2 = new IntersectionObserver(ImgRevealCallback2, imgOptions2);

				document.querySelectorAll(".img-reveal").forEach((reveal) => {
					ImRevealObserver2.observe(reveal);
				});
			</script>
			<style>
				.img-reveal {
					visibility: visible;
				}
			</style>
				<?php
			}
	}

	public function the_excerpt_max_charlength( $charlength ) {
		$excerpt = get_the_excerpt();
		$charlength++;

		if ( mb_strlen( $excerpt ) > $charlength ) {
			$subex   = mb_substr( $excerpt, 0, $charlength - 5 );
			$exwords = explode( ' ', $subex );
			$excut   = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
			if ( $excut < 0 ) {
				echo mb_substr( $subex, 0, $excut );
			} else {
				echo $subex;
			}
			echo '';
		} else {
			echo $excerpt;
		}
	}
}
