<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner Six
 *
 * Elementor widget for banner six
 *
 * @since 1.0.0
 */
class Banner_Six extends Widget_Base {


	public function get_name() {
		return 'iori-banner-six';
	}

	public function get_title() {
		return esc_html__( 'Banner Six', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-six', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_six_section',
			array(
				'label' => __( 'Banner Six', 'iori' ),
			)
		);

		$this->add_control(
			'banner_six_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_six_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_six_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'mailchimp_text',
			array(
				'label'       => __( 'Mailchimp Shortcode', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
				'label_block' => true,
				'description' => __(
					'Note: (Please replace this code in mailchimp form) <br/> &lt;input name="EMAIL" type="text" placeholder="Enter you mail.."&gt;
				&lt;button class="btn btn-submit-newsletter" type="submit"&gt;
					&lt;svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"&gt;
						&lt;path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"&gt;&lt;/path&gt;
					&lt;/svg&gt;
				&lt;/button&gt;'
				),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'banner_six_author_thumb',
			array(
				'label'   => esc_html__( 'Upload Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'banner_six_item_list',
			array(
				'label'   => __( 'Brand Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'banner_six_author_thumb' => '',
					),
					array(
						'banner_six_author_thumb' => '',
					),
					array(
						'banner_six_author_thumb' => '',
					),
				),
			)
		);

		$this->add_control(
			'banner_six_item_author_number',
			array(
				'label'       => __( 'Author Number', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_six_user_text',
			array(
				'label'       => __( 'User Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_six_user_platform',
			array(
				'label'       => __( 'User Platform', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_six_user_platform_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		// scroll images content
		$this->add_control(
			'banner_six_scroll_img1',
			array(
				'label'       => __( 'Scroll Image One', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_six_scroll_img2',
			array(
				'label'       => __( 'Scroll Image Two', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_six_scroll_img3',
			array(
				'label'       => __( 'Scroll Image Three', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_six_scroll_img4',
			array(
				'label'       => __( 'Scroll Image Four', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'separator'   => 'before',
			)
		);

		$this->add_control(
			'banner_six_scroll_img5',
			array(
				'label'       => __( 'Scroll Image Five', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_six_scroll_img6',
			array(
				'label'       => __( 'Scroll Image Six', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->end_controls_section();

		// content style

		// subtitle
		$this->start_controls_section(
			'banner_six_subtitle_style',
			array(
				'label' => __( 'Subtitle', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_six_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-left-home7 .banner_six_subtitle' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_six_subtitle_typography',
				'selector' => '{{WRAPPER}} .box-banner-left-home7 .banner_six_subtitle',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'banner_six_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_six_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-left-home7 .banner_six_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_six_title_typography',
				'selector' => '{{WRAPPER}} .box-banner-left-home7 .banner_six_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_six_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_six_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-left-home7 .banner_six_desc' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_six_desc_typography',
				'selector' => '{{WRAPPER}} .box-banner-left-home7 .banner_six_desc',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$banner_six_item_lists = $settings['banner_six_item_list'];

		?>

		<section class="section banner-7">
			<div class="container">
				<div class="box-radius-32 ml-minus-85 mr-minus-85">
					<div class="row align-items-center h-100">
						<div class="col-xl-6">
							<div class="box-banner-left-home7">
								<span class="title-line banner_six_subtitle line-48 wow animate__animated animate__fadeInUp" data-wow-delay=".s"><?php echo esc_html( $settings['banner_six_subtitle'] ); ?></span>
								<h1 class="banner_six_title mb-20 mt-5 wow animate__animated animate__fadeInUp" data-wow-delay=".1s"><?php echo esc_html( $settings['banner_six_title'] ); ?></h1>
								<div class="row">
									<div class="col-lg-10">
										<div class="banner_six_desc mb-25 wow animate__animated animate__fadeInUp" data-wow-delay=".2s"><?php echo $settings['banner_six_desc']; ?></div>
									</div>
								</div>
								<div class="box-join-now">
									<div class="box-form-join wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
										<?php echo do_shortcode( $settings['mailchimp_text'] ); ?>
									</div>
								</div>
								<div class="box-joined wow animate__animated animate__fadeInUp" data-wow-delay=".4s">
									<div class="box-authors">

										<?php
										foreach ( $banner_six_item_lists as $banner_six_item_list ) { 
											?>

											<span class="item-author">
												<img src="<?php echo $banner_six_item_list['banner_six_author_thumb']['url']; ?>" alt="iori">
											</span>

											<?php
										} 
										?>

										<span class="item-author">
											<span class="text-num-author font-md-bold color-brand-1"><?php echo esc_html( $settings['banner_six_item_author_number'] ); ?></span>
										</span>
									</div>
									<span class="join-thousands font-sm color-grey-400 d-inline-block"><?php echo esc_html( $settings['banner_six_user_text'] ); ?>
										<a class="font-sm-bold color-brand-1" href="<?php echo esc_html( $settings['banner_six_user_platform_link'] ); ?>"><?php echo esc_html( $settings['banner_six_user_platform'] ); ?></a>
									</span>
								</div>
							</div>
						</div>
						<div class="col-xl-6 d-none d-xl-block h-100">
							<div class="box-banner-7">

								<div class="banner-7-img-1 scroll-1 wow animate__animated animate__fadeIn" data-wow-delay=".0s">
									<img src="<?php echo $settings['banner_six_scroll_img1']['url']; ?>" alt="iori">
									<img src="<?php echo $settings['banner_six_scroll_img2']['url']; ?>" alt="iori">
									<img src="<?php echo $settings['banner_six_scroll_img3']['url']; ?>" alt="iori">
								</div>

								<div class="banner-7-img-2 scroll-2 wow animate__animated animate__fadeIn" data-wow-delay=".4s">
									<img src="<?php echo $settings['banner_six_scroll_img4']['url']; ?>" alt="iori">
									<img src="<?php echo $settings['banner_six_scroll_img5']['url']; ?>" alt="iori">
									<img src="<?php echo $settings['banner_six_scroll_img6']['url']; ?>" alt="iori">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
