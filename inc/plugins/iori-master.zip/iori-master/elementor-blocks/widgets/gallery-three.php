<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Gallery Three
 *
 * Elementor widget for gallery
 *
 * @since 1.0.0
 */
class Gallery_Three extends Widget_Base {


	public function get_name() {
		return 'iori-gallery-three';
	}

	public function get_title() {
		return esc_html__( 'Gallery Three', 'iori' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'gallery', 'image', 'picture', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'gallery_three_section',
			array(
				'label' => esc_html__( 'Gallery Three', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_three_main_img',
			array(
				'label'   => esc_html__( 'Main Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'gallery_three_left_img',
			array(
				'label'   => esc_html__( 'Image Left', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'gallery_three_count_number',
			array(
				'label'       => __( 'Number', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_three_count_subject',
			array(
				'label'       => __( 'Subject', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->end_controls_section();

		// start style here

		// number
		$this->start_controls_section(
			'gallery_three_number_style',
			array(
				'label' => __( 'Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_three_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-business .count_number' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_three_number_typography',
				'selector' => '{{WRAPPER}} .box-number-business .count_number',
				
			)
		);

		$this->end_controls_section();

		// subject
		$this->start_controls_section(
			'gallery_three_subject_style',
			array(
				'label' => __( 'Subject', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_three_subject_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-business .subject' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_three_subject_typography',
				'selector' => '{{WRAPPER}} .box-number-business .subject',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="box-circle-image">
			<img class="d-block m-auto" src="<?php echo $settings['gallery_three_main_img']['url']; ?>" alt="iori">
			<div class="shape-1 box-image-4">
				<img src="<?php echo $settings['gallery_three_left_img']['url']; ?>" alt="iori">
			</div>
			<div class="box-number-business shape-3">
				<div class="cardNumber bg-white">
					<h3 class="count_number"><?php echo esc_html( $settings['gallery_three_count_number'] ); ?></h3>
					<p class="subject"><?php echo esc_html( $settings['gallery_three_count_subject'] ); ?></p>
				</div>
			</div>
		</div>

		<?php
	}
}
