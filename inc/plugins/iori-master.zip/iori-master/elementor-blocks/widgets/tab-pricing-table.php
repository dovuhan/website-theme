<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for price two
 *
 * @since 1.0.0
 */

class Price_Two extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-price-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Pricing table: Tab', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'price', 'money', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'price_two_section',
			array(
				'label' => __( 'Tabs', 'iori' ),
			)
		);

		$this->add_control(
			'price_table_style',
			array(
				'label'       => 'Style',
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'style1' => 'Default',
					'style2' => 'Style 2',
				),
			)
		);

		$this->add_control(
			'price_table_col',
			array(
				'label'       => 'Columns',
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'col-xl-3' => '4 Table',
					'col-xl-4' => '3 Table',
					'col-xl-6' => '2 Table',
				),
				'default'     => 'col-xl-3',
			)
		);

		$this->add_control(
			'price_two_monthly_tab',
			array(
				'label'       => 'Tab One',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Monthly',
			)
		);

		$this->add_control(
			'price_two_yearly_tab',
			array(
				'label'       => 'Tab Two',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Yearly',
			)
		);

		$this->end_controls_section();

		// price cards
		$this->start_controls_section(
			'price_two_cards_section',
			array(
				'label' => 'Cards',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'price_two_card_type',
			array(
				'label'   => 'Card Type',
				'type'    => Controls_Manager::SELECT,
				'default' => 'monthly',
				'options' => array(
					'monthly' => 'First Tab',
					'yearly'  => 'Second Tab',
				),
			)
		);

		$repeater->add_control(
			'price_two_image',
			array(
				'label'       => 'Image',
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'price_two_title',
			array(
				'label'       => 'Title',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'price_two_subtitle',
			array(
				'label'       => 'Sub Title',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'price_two_price',
			array(
				'label'       => 'Price',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'price_two_duration',
			array(
				'label'       => 'Duration',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'price_two_bill',
			array(
				'label'       => 'Bill',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'price_two_btn',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'price_two_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'price_two_lists',
			array(
				'label'       => __( 'Description (use "br" tag for new line)', 'iori' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
			)
		);
		$repeater->add_control(
			'price_two_popular',
			array(
				'label'       => __( 'Popular Label', 'iori' ),
				'type'        => Controls_Manager::SWITCHER,
				'label_block' => false,
			)
		);
		$repeater->add_control(
			'price_two_populartext',
			array(
				'label'       => __( 'Popular Label Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => false,
				'condition'   => array(
					'price_two_popular' => 'yes',
				),
			)
		);

		$this->add_control(
			'price_two_card_list',
			array(
				'label'   => __( 'Card Items', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'price_two_card_type' => 'monthly',
						'price_two_image'     => '',
						'price_two_title'     => 'Trial Plan',
						'price_two_subtitle'  => 'Protect for testing',
						'price_two_price'     => 'FREE-',
						'price_two_duration'  => '30 days trial',
						'price_two_bill'      => 'No Credit card required',
						'price_two_btn'       => 'Try For Free',
						'price_two_btn_link'  => '#',
						'price_two_lists'     => 'Max number of results per month <br />
Various innovative test <br />
Insightful analytics',
					),
					array(
						'price_two_card_type' => 'monthly',
						'price_two_image'     => '',
						'price_two_title'     => 'Standard',
						'price_two_subtitle'  => 'Advanced project',
						'price_two_price'     => '$29',
						'price_two_duration'  => '- user / month',
						'price_two_bill'      => 'Billed annually',
						'price_two_btn'       => 'Get Started',
						'price_two_btn_link'  => '#',
						'price_two_lists'     => 'Max number of results per month <br />
Various innovative test <br />
Insightful analytics <br />
Global Certificates',
					),
					array(
						'price_two_card_type' => 'monthly',
						'price_two_image'     => '',
						'price_two_title'     => 'Business',
						'price_two_subtitle'  => 'Advanced project',
						'price_two_price'     => '$99',
						'price_two_duration'  => '- user / month',
						'price_two_bill'      => 'Billed annually',
						'price_two_btn'       => 'Get Started',
						'price_two_btn_link'  => '#',
						'price_two_lists'     => 'Max number of results per month <br />
Various innovative test <br />
Insightful analytics <br />
Global Certificates <br />
Project dashboard, Gantt chart
						',
					),
					array(
						'price_two_card_type' => 'monthly',
						'price_two_image'     => '',
						'price_two_title'     => 'Enterprise',
						'price_two_subtitle'  => 'Protect for testing',
						'price_two_price'     => '$299',
						'price_two_duration'  => '- user / month',
						'price_two_bill'      => 'Billed annually',
						'price_two_btn'       => 'Get Started',
						'price_two_btn_link'  => '#',
						'price_two_lists'     => 'Max number of results per month <br />
Various innovative test <br />
Insightful analytics <br />
Global Certificates <br />
Project dashboard, Gantt chart <br />
Dedicated account manager
						',
					),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display();

		$price_two_card_lists = $settings['price_two_card_list'];

		?>

		<section class="section">
				<div class="row align-items-center">
					<div class="col-lg-12 text-center">

						<ul class="tabs-plan change-price-plan" role="tablist">
							<li class="wow animate__animated animate__fadeIn" data-wow-delay=".0s"><a class="active" href="#" data-type="<?php echo strtolower( str_replace( ' ', '_', $settings['price_two_monthly_tab'] ) ); ?>"><?php echo esc_html( $settings['price_two_monthly_tab'] ); ?></a></li>
							<li class="wow animate__animated animate__fadeIn" data-wow-delay=".1s"><a href="#" data-type="<?php echo esc_html( $settings['price_two_yearly_tab'] ); ?>"><?php echo esc_html( $settings['price_two_yearly_tab'] ); ?></a></li>
						</ul>

					</div>
				</div>
				<div class="row mt-50">
					<?php 
					$i = 1;
					foreach ( $price_two_card_lists as $price_two_card_list ) : 
						?>
						<div class="<?php echo esc_attr( $settings['price_table_col'] ); ?> col-lg-6 col-md-6 wow animate__animated animate__fadeIn item-<?php echo esc_html( $price_two_card_list['price_two_card_type'] ); ?>" data-wow-delay="0.<?php echo $i; ?>s">
							<div class="
							<?php 
							if ( $settings['price_table_style'] == 'style2' ) {
								echo 'card-plan';
							} else {
								echo 'card-plan-default'; } 
							?>
							 card-plan-style-2 hover-up">
								<div class="card-plan
								<?php 
								if ( $settings['price_table_style'] == 'style2' ) {
									echo 'style-plan2'; } 
								?>
								">
									<?php if ( $price_two_card_list['price_two_popular'] ) { ?>
									<label class="popular"><?php echo esc_html( $price_two_card_list['price_two_populartext'] ); ?></label>
									<?php } ?>
									<div class="card-image-plan">
										<div class="icon-plan"><img src="<?php echo esc_url( $price_two_card_list['price_two_image']['url'] ); ?>" alt="iori"></div>
										<div class="info-plan">
											<h4 class="title my-0"><?php echo esc_html( $price_two_card_list['price_two_title'] ); ?></h4>
											<div class="subtitle"><?php echo esc_html( $price_two_card_list['price_two_subtitle'] ); ?></div>
										</div>
									</div>
									<?php if ( $settings['price_table_style'] == 'style2' ) { ?>
									<div class="box-day-trial box-trial-two">
										<div class="trial-col-1">
										<span class="font-lg-bold color-brand-1 text-price-<?php echo strtolower( str_replace( ' ', '_', $price_two_card_list['price_two_title'] ) ); ?>"><?php echo esc_html( $price_two_card_list['price_two_price'] ); ?></span>
										<span class="duration text-type-<?php echo strtolower( str_replace( ' ', '_', $price_two_card_list['price_two_title'] ) ); ?>"><?php echo esc_html( $price_two_card_list['price_two_duration'] ); ?></span>
										<br />
										<span class="bill"><?php echo esc_html( $price_two_card_list['price_two_bill'] ); ?></span>
										</div>
										<div class="trial-col-2">
										<a class="btn btn-brand-1-full hover-up" href="<?php echo esc_url( $price_two_card_list['price_two_btn_link'] ); ?>"><?php echo esc_html( $price_two_card_list['price_two_btn'] ); ?>
											<svg class="w-6 h-6 icon-16 ml-10" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
											</svg>
										</a>
										</div>
									</div>
									<?php } else { ?>
									<div class="box-day-trial">
										<span class="font-lg-bold color-brand-1 text-price-<?php echo strtolower( str_replace( ' ', '_', $price_two_card_list['price_two_title'] ) ); ?>"><?php echo esc_html( $price_two_card_list['price_two_price'] ); ?></span>
										<span class="duration text-type-<?php echo strtolower( str_replace( ' ', '_', $price_two_card_list['price_two_title'] ) ); ?>"><?php echo esc_html( $price_two_card_list['price_two_duration'] ); ?></span>
										<br />
										<span class="bill"><?php echo esc_html( $price_two_card_list['price_two_bill'] ); ?></span>
									</div>
									<div class="mt-20">
										<a class="btn btn-brand-1-full hover-up" href="<?php echo esc_url( $price_two_card_list['price_two_btn_link'] ); ?>"><?php echo esc_html( $price_two_card_list['price_two_btn'] ); ?>
											<svg class="w-6 h-6 icon-16 ml-10" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
											</svg>
										</a>
									</div>
									<?php } ?>
								</div>
								<div class="mt-30 mb-30 wow animate__animated animate__fadeIn" data-wow-delay=".1s">
									<ul class="list-ticks list-ticks-2">
									<?php 
									$content_lists = $price_two_card_list['price_two_lists'];
									$content_lists = explode( '<br />', $content_lists );
									foreach ( $content_lists as $key => $list ) {
										?>
										<li>
											<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
											</svg>
											<?php echo esc_html( $list ); ?>
										</li>
										<?php } ?>
									</ul>
								</div>
							</div>
						</div>
		

						<?php 
						$i++;
endforeach; 
					?>
				</div>
		</section>
				
		<script>
			(function($) {
				"use strict";
				$(document).ready(function() {
					$('.item-<?php echo strtolower( $settings['price_two_monthly_tab'] ); ?>').show();
					$('.item-<?php echo strtolower( $settings['price_two_yearly_tab'] ); ?>').hide();

					$(".change-price-plan li a").on("click", function(e) {
						e.preventDefault();
						$(".change-price-plan li a").removeClass("active");
						$(this).addClass("active");
						var type = $(this).attr("data-type");
						
						if (type === "<?php echo strtolower( $settings['price_two_monthly_tab'] ); ?>" ) {
							$('.item-<?php echo strtolower( $settings['price_two_monthly_tab'] ); ?>').show();
							$('.item-<?php echo strtolower( $settings['price_two_yearly_tab'] ); ?>').hide();
							<?php foreach ( $price_two_card_lists as $price_two_card_list ) : ?>
								<?php if ( strtolower( $settings['price_two_monthly_tab'] ) === $price_two_card_list['price_two_card_type'] ) { ?>
									$(".text-price-<?php echo strtolower( str_replace( ' ', '_', $price_two_card_list['price_two_title'] ) ); ?>").html("<?php echo esc_js( $price_two_card_list['price_two_price'] ); ?>");
									$(".text-type-<?php echo strtolower( str_replace( ' ', '_', $price_two_card_list['price_two_title'] ) ); ?>").html("<?php echo esc_js( $price_two_card_list['price_two_duration'] ); ?>");
								<?php } ?>
							<?php endforeach; ?>
						} else {
							$('.item-<?php echo strtolower( $settings['price_two_monthly_tab'] ); ?>').hide();
							$('.item-<?php echo strtolower( $settings['price_two_yearly_tab'] ); ?>').show();
							<?php foreach ( $price_two_card_lists as $price_two_card_list ) : ?>
								<?php if ( strtolower( $settings['price_two_monthly_tab'] ) !== $price_two_card_list['price_two_card_type'] ) { ?>
									$(".text-price-<?php echo strtolower( str_replace( ' ', '_', $price_two_card_list['price_two_title'] ) ); ?>").html("<?php echo esc_js( $price_two_card_list['price_two_price'] ); ?>");
									$(".text-type-<?php echo strtolower( str_replace( ' ', '_', $price_two_card_list['price_two_title'] ) ); ?>").html("<?php echo esc_js( $price_two_card_list['price_two_duration'] ); ?>");
								<?php } ?>
							<?php endforeach; ?>
						}
					});
				});
			})(jQuery);
		</script>
		<?php
	}
}
