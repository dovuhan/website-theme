<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class List_Table extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-list-table';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Build Table', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'list', 'money', 'table', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

	protected function _register_controls() {
		$this->start_controls_section(
			'table_section',
			array(
				'label' => 'Add Table',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);


		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			array(
				'label'   => 'Title',
				'type'    => Controls_Manager::TEXT,
				'default' => 'Auto Focus Technology',
			)
		);

		$repeater->add_control(
			'data',
			array(
				'label'   => 'Content',
				'type'    => Controls_Manager::TEXT,
				'default' => 'Phase Detection',
			)
		);

		$this->add_control(
			'table_data',
			array(
				'label'       => 'Table Data',
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'title' => 'Model Name',
						'data'  => 'Z fc DX-format Mirrorless',
					),
					array(
						'title' => 'Model',
						'data'  => 'Nikon',
					),
					array(
						'title' => 'Auto Focus Technology',
						'data'  => 'Phase Detection',
					),
					array(
						'title' => 'Product information',
						'data'  => '1.50:1, 16:9',
					),
					array(
						'title' => 'Display Resolution Maximum',
						'data'  => 'Approx. 1040 k-dot',
					),
					array(
						'title' => 'Photo Sensor Size',
						'data'  => 'APS-C',
					),
				),
				'title_field' => '{{{ title }}}',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$table_name_lists = $settings['table_name_list'];
		?>
		<div class="table-responsive table-responsive-sm table-responsive-md">
			<table class="table table-product-info">
				<tbody>
					<?php foreach ( $settings['table_data'] as $item ) : ?>
						<tr> 
							<th><?php echo $item['title']; ?></th>
							<td><?php echo $item['data']; ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
