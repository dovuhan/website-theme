<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner_Nine
 *
 * Elementor widget for banner_nine
 *
 * @since 1.0.0
 */
class Banner_Nine extends Widget_Base {


	public function get_name() {
		return 'iori-banner-nine';
	}

	public function get_title() {
		return esc_html__( 'Banner Nine', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-nine', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_nine_section',
			array(
				'label' => __( 'Banner Nine', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'banner_nine_bg_img',
			array(
				'label'       => __( 'Background Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'banner_nine_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'banner_nine_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'banner_nine_app_img',
			array(
				'label'       => __( 'App Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'banner_nine_app_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$repeater->add_control(
			'banner_nine_app_img2',
			array(
				'label'       => __( 'Google Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'banner_nine_app_img2_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_nine_item_list',
			array(
				'label'   => __( 'Banner Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'banner_nine_bg_img'        => '',
						'banner_nine_title'         => '',
						'banner_nine_desc'          => '',
						'banner_nine_app_img'       => '',
						'banner_nine_app_img_link'  => '',
						'banner_nine_app_img2'      => '',
						'banner_nine_app_img2_link' => '',
					),
					array(
						'banner_nine_bg_img'        => '',
						'banner_nine_title'         => '',
						'banner_nine_desc'          => '',
						'banner_nine_app_img'       => '',
						'banner_nine_app_img_link'  => '',
						'banner_nine_app_img2'      => '',
						'banner_nine_app_img2_link' => '',
					),
					array(
						'banner_nine_bg_img'        => '',
						'banner_nine_title'         => '',
						'banner_nine_desc'          => '',
						'banner_nine_app_img'       => '',
						'banner_nine_app_img_link'  => '',
						'banner_nine_app_img2'      => '',
						'banner_nine_app_img2_link' => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// content style start
		// title
		$this->start_controls_section(
			'banner_nine_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_nine_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-info-banner11 .banner_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_nine_title_typography',
				'selector' => '{{WRAPPER}} .box-info-banner11 .banner_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_nine_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_nine_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-info-banner11 .banner_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_nine_desc_typography',
				'selector' => '{{WRAPPER}} .box-info-banner11 .banner_desc',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['banner_nine_item_list'] ) ) {
			return;
		}
		$banner_nine_item_lists = $settings['banner_nine_item_list'];

		?>
		<section class="section banner-11">
			<div class="box-banner-home11">
				<div class="box-swiper">
					<div class="swiper-container swiper-group-1">
						<div class="swiper-wrapper">

							<?php
							foreach ( $banner_nine_item_lists as $banner_nine_item_list ) { 
								?>

								<div class="swiper-slide">
									<div class="banner-slide-11" style="background-image: url('<?php echo esc_url( $banner_nine_item_list['banner_nine_bg_img']['url'] ); ?>');">
										<div class="banner-abs">
											<div class="container">
												<div class="row">
													<div class="col-xl-5 col-lg-6 col-md-8 col-sm-10 col-12">
														<div class="box-info-banner11">
															<h2 class="banner_title mb-30 wow animate__animated animate__fadeInUp"><?php echo esc_html( $banner_nine_item_list['banner_nine_title'] ); ?></h2>
															<div class="banner_desc wow animate__animated animate__fadeIn" data-wow-delay=".2s"><?php echo $banner_nine_item_list['banner_nine_desc']; ?></div>
															<div class="mt-30 d-flex wow animate__animated animate__fadeIn" data-wow-delay=".4s">
																<a href="<?php echo esc_url( $banner_nine_item_list['banner_nine_app_img_link'] ); ?>"><img class="mr-10" src="<?php echo esc_url( $banner_nine_item_list['banner_nine_app_img']['url'] ); ?>" alt="iori"></a>
																<a href="<?php echo esc_url( $banner_nine_item_list['banner_nine_app_img2_link'] ); ?>"><img src="<?php echo esc_url( $banner_nine_item_list['banner_nine_app_img2']['url'] ); ?>" alt="iori"></a>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

							<?php } ?>

						</div>
					</div>
				</div>
				<div class="swiper-pagination swiper-pagination-group-11"></div>
			</div>
		</section>

		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				jQuery(".swiper-group-1").each(function() {
					var swiper_1_items = new Swiper(this, {
						slidesPerView: 1,
						loop: true,
						navigation: {
							nextEl: ".swiper-button-next-group-1",
							prevEl: ".swiper-button-prev-group-1"
						},
						pagination: {
							el: ".swiper-pagination",
							clickable: true
						},
						autoplay: {
							delay: 10000
						}
					});
				});
			</script>

		<?php } ?>

		<?php
	}
}
