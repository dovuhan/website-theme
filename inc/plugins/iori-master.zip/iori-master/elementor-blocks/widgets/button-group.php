<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Button_Group
 *
 * @since 1.0.0
 */

class Button_Group extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-button-group';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Button Group', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'button', 'group', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'button_group_section',
			array(
				'label' => __( 'Button Group', 'iori' ),
			)
		);

		$this->add_control(
			'button_group_app_btn_title',
			array(
				'label'       => __( 'App Button Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'button_group_app_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'button_group_learn_btn_title',
			array(
				'label'       => __( 'Learn More Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'button_group_learn_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->end_controls_section();

		// start style here

		// app button
		$this->start_controls_section(
			'button_group_app_btn_style',
			array(
				'label' => __( 'App Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'button_group_app_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-button .btn.btn-brand-1' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_control(
			'button_group_app_bg_color',
			array(
				'label'     => __( 'Background Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .box-button .btn.btn-brand-1' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_group_app_typography',
				'selector' => '{{WRAPPER}} .box-button .btn.btn-brand-1',
				
			)
		);

		$this->end_controls_section();

		// learn more button
		$this->start_controls_section(
			'button_group_more_btn_style',
			array(
				'label' => __( 'Learn More Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'button_group_more_btn_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-button .laern_more_btn' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_group_more_btn_typography',
				'selector' => '{{WRAPPER}} .box-button .laern_more_btn',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="box-button text-center wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
			<a class="btn btn-brand-1 hover-up" href="<?php echo esc_html( $settings['button_group_app_btn_link'] ); ?>"><?php echo esc_html( $settings['button_group_app_btn_title'] ); ?>
			</a>
			<a class="btn btn-default laern_more_btn hover-up" href="<?php echo esc_html( $settings['button_group_learn_btn_link'] ); ?>"><?php echo esc_html( $settings['button_group_learn_btn_title'] ); ?>
				<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
				</svg>
			</a>
		</div>

		<?php
	}
}
