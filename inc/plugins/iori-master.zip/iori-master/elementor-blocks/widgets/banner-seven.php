<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner_Seven
 *
 * Elementor widget for banner_seven
 *
 * @since 1.0.0
 */
class Banner_Seven extends Widget_Base {


	public function get_name() {
		return 'iori-banner-seven';
	}

	public function get_title() {
		return esc_html__( 'Banner Seven', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-seven', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_seven_section',
			array(
				'label' => __( 'Banner Seven', 'iori' ),
			)
		);

		$this->add_control(
			'banner_seven_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_seven_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_seven_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_seven_app_img',
			array(
				'label'       => __( 'App Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_seven_app_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_seven_app_img2',
			array(
				'label'       => __( 'Google Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_seven_app_img2_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'banner_seven_author_image',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'banner_seven_author_name',
			array(
				'label'       => 'Author Name',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'banner_seven_author_name_link',
			array(
				'label'       => 'Link',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'banner_seven_author_designation',
			array(
				'label'       => 'Author Designation',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'banner_seven_first_social',
			array(
				'label'       => esc_html__( 'First Social', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'separator'   => 'before',
			)
		);

		$repeater->add_control(
			'banner_seven_first_social_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'banner_seven_second_social',
			array(
				'label'       => esc_html__( 'Second Social', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'separator'   => 'before',
			)
		);

		$repeater->add_control(
			'banner_seven_second_social_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'banner_seven_third_social',
			array(
				'label'       => esc_html__( 'Third Social', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'separator'   => 'before',
			)
		);

		$repeater->add_control(
			'banner_seven_third_social_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'banner_seven_img_bg_color',
			array(
				'label'     => __( 'Image Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .card-member-2' => 'background-color: {{VALUE}};',
				),
			)
		);

		$repeater->add_control(
			'banner_seven_card_info_bg_color',
			array(
				'label'     => __( 'Info Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .card-member-2 .card-info' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'banner_seven_list',
			array(
				'label'   => __( 'Banner Team Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'banner_seven_author_image'       => '',
						'banner_seven_author_name'        => '',
						'banner_seven_author_name_link'   => '',
						'banner_seven_author_designation' => '',
						'banner_seven_first_social'       => '',
						'banner_seven_first_social_link'  => '',
						'banner_seven_second_social'      => '',
						'banner_seven_second_social_link' => '',
						'banner_seven_third_social'       => '',
						'banner_seven_third_social_link'  => '',
						'banner_seven_img_bg_color'       => '',
						'banner_seven_card_info_bg_color' => '',
					),
					array(
						'banner_seven_author_image'       => '',
						'banner_seven_author_name'        => '',
						'banner_seven_author_name_link'   => '',
						'banner_seven_author_designation' => '',
						'banner_seven_first_social'       => '',
						'banner_seven_first_social_link'  => '',
						'banner_seven_second_social'      => '',
						'banner_seven_second_social_link' => '',
						'banner_seven_third_social'       => '',
						'banner_seven_third_social_link'  => '',
						'banner_seven_img_bg_color'       => '',
						'banner_seven_card_info_bg_color' => '',
					),
					array(
						'banner_seven_author_image'       => '',
						'banner_seven_author_name'        => '',
						'banner_seven_author_name_link'   => '',
						'banner_seven_author_designation' => '',
						'banner_seven_first_social'       => '',
						'banner_seven_first_social_link'  => '',
						'banner_seven_second_social'      => '',
						'banner_seven_second_social_link' => '',
						'banner_seven_third_social'       => '',
						'banner_seven_third_social_link'  => '',
						'banner_seven_img_bg_color'       => '',
						'banner_seven_card_info_bg_color' => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// content style start

		// subtitle
		$this->start_controls_section(
			'banner_seven_subtitle_style',
			array(
				'label' => __( 'Sub Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_seven_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-home8 .banner7_subtitle' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_seven_subtitle_typography',
				'selector' => '{{WRAPPER}} .box-banner-home8 .banner7_subtitle',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'banner_seven_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_seven_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-home8 .banner7_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_seven_title_typography',
				'selector' => '{{WRAPPER}} .box-banner-home8 .banner7_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_seven_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_seven_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-home8 .banner7_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_seven_desc_typography',
				'selector' => '{{WRAPPER}} .box-banner-home8 .banner7_desc',
				
			)
		);

		$this->end_controls_section();

		// slider item styles
		$this->start_controls_section(
			'banner_seven_slide_style',
			array(
				'label' => __( 'Slide Item', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_seven_slide_title_heading',
			array(
				'label'     => __( 'Title', 'iori' ),
				'type'      => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'banner_seven_slide_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-member-2 .slide_item_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_seven_slide_title_typography',
				'selector' => '{{WRAPPER}} .card-member-2 .slide_item_title',
				
			)
		);

		// designation
		$this->add_control(
			'banner_seven_slide_designation_heading',
			array(
				'label'     => __( 'Designation', 'iori' ),
				'type'      => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'banner_seven_slide_designation_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-member-2 .slide_item_designation' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_seven_slide_designation_typography',
				'selector' => '{{WRAPPER}} .card-member-2 .slide_item_designation',
				
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['banner_seven_list'] ) ) {
			return;
		}
		$banner_seven_lists = $settings['banner_seven_list'];

		$banner_seven_app_img  = $settings['banner_seven_app_img']['url'];
		$banner_seven_app_img2 = $settings['banner_seven_app_img2']['url'];

		?>

		<section class="section banner-8 overflow-hidden">
			<div class="asset-1 shape-1"></div>
			<div class="asset-2 shape-2"></div>
			<div class="asset-3 shape-3"></div>
			<div class="asset-4 shape-1"></div>
			<div class="asset-5 shape-2"></div>
			<div class="box-banner-home8">
				<div class="container">
					<div class="row">
						<div class="col-xl-8 col-lg-10 m-auto">
							<div class="text-center">
								<span class="banner7_subtitle wow animate__animated animate__fadeInUp" data-wow-delay=".s">
									<?php echo esc_html( $settings['banner_seven_subtitle'] ); ?>
								</span>
								<h1 class="banner7_title mb-25 mt-10 wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
									<?php echo esc_html( $settings['banner_seven_title'] ); ?>
								</h1>
								<div class="banner7_desc mb-25 wow animate__animated animate__fadeInUp" data-wow-delay=".4s">
									<?php echo $settings['banner_seven_desc']; ?>
								</div>
								<div class="text-center wow animate__animated animate__fadeInUp" data-wow-delay=".6s">
									<a href="<?php echo esc_url( $settings['banner_seven_app_img_link'] ); ?>"><img class="mr-10" src="<?php echo esc_url( $banner_seven_app_img ); ?>" alt="iori"></a>
									<a href="<?php echo esc_url( $settings['banner_seven_app_img2_link'] ); ?>"><img src="<?php echo esc_url( $banner_seven_app_img2 ); ?>" alt="iori"></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="mt-80 wow animate__animated animate__fadeIn">
					<div class="box-swiper">
						<div class="swiper-container swiper-group-7-center">
							<div class="swiper-wrapper">

								<?php
								foreach ( $banner_seven_lists as $banner_seven_list ) { 
									?>

									<div class="swiper-slide elementor-repeater-item-<?php echo esc_attr( $banner_seven_list['_id'] ); ?>">
										<div class="card-member-2 mb-30">
											<div class="card-image">
												<img src="<?php echo esc_url( $banner_seven_list['banner_seven_author_image']['url'] ); ?>" alt="iori">
											</div>
											<div class="card-info"><a class="slide_item_title" href="<?php echo esc_url( $banner_seven_list['banner_seven_author_name_link'] ); ?>"><?php echo esc_html( $banner_seven_list['banner_seven_author_name'] ); ?></a>
												<div class="d-flex justify-content-between align-items-center">
													<p class="slide_item_designation"><?php echo esc_html( $banner_seven_list['banner_seven_author_designation'] ); ?></p>

													<div class="list-socials mt-0">
														<a href="<?php echo esc_url( $banner_seven_list['banner_seven_first_social_link'] ); ?>" class="icon-socials"><img src="<?php echo esc_url( $banner_seven_list['banner_seven_first_social']['url'] ); ?>"></a>
														<a href="<?php echo esc_url( $banner_seven_list['banner_seven_second_social_link'] ); ?>" class="icon-socials"><img src="<?php echo esc_url( $banner_seven_list['banner_seven_second_social']['url'] ); ?>"></a>
														<a href="<?php echo esc_url( $banner_seven_list['banner_seven_third_social_link'] ); ?>" class="icon-socials"><img src="<?php echo esc_url( $banner_seven_list['banner_seven_third_social']['url'] ); ?>"></a>
													</div>

												</div>
											</div>
										</div>
									</div>

								<?php } ?>

							</div>
							<div class="box-button-slider-bottom">
								<div class="swiper-button-prev-group-4">
									<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
									</svg>
								</div>
								<div class="swiper-button-next-group-4">
									<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
									</svg>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				jQuery(".swiper-group-7-center").each(function() {
					var swiper_7_items = new Swiper(this, {
						spaceBetween: 30,
						slidesPerView: 6,
						slidesPerGroup: 1,
						centeredSlides: true,
						loop: true,
						navigation: {
							nextEl: ".swiper-button-next-group-4",
							prevEl: ".swiper-button-prev-group-4"
						},
						pagination: {
							el: ".swiper-pagination-group-4",
							clickable: true
						},
						autoplay: {
							delay: 10000
						},
						breakpoints: {
							1399: {
								slidesPerView: 6
							},
							1100: {
								slidesPerView: 4
							},
							850: {
								slidesPerView: 3
							},
							600: {
								slidesPerView: 2
							},
							150: {
								slidesPerView: 1
							}
						}
					});
				});
			</script>

		<?php } ?>

		<?php
	}
}
