<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Accordion Two
 *
 * @since 1.0.0
 */

class Accordion_Two extends Widget_Base {


	public function get_name() {
		return 'accordion-two';
	}

	public function get_title() {
		return 'Accordion Two Columns';
	}

	public function get_icon() {
		return 'eicon-accordion d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'accordion', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/
	// public function get_script_depends() {
	// return [ 'section-header' ];
	// }

	protected function register_controls() {

		// ========= Start Content Section=========

		$this->start_controls_section(
			'accordion_two_section',
			array(
				'label' => esc_html__( 'Accordion', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'accordion_two_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'accordion_two_content',
			array(
				'label'       => __( 'Content', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
			)
		);

		$this->add_control(
			'accordion_two_items',
			array(
				'label'   => __( 'Accordion Items', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'accordion_two_title'   => 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
						'accordion_two_content' => 'Obcaecati quibusdam sint quam nihil veniam reiciendis assumenda? Laboriosam impedit in vero omnis illum. Placeat vero recusandae dolor perferendis atque nihil ab.',
					),
					array(
						'accordion_two_title'   => 'Lorem ipsum dolor sit amet',
						'accordion_two_content' => 'Consectetur adipisicing elit. Vitae dolores sint non minima, quas nobis! Corrupti quo libero natus maxime quibusdam autem reprehenderit aliquam ullam debitis dolorem, vitae praesentium non!',
					),
					array(
						'accordion_two_title'   => 'Lorem ipsum dolor sit amet consectetur, adipisicing elit.',
						'accordion_two_content' => ' Neque doloremque quo voluptas sapiente tenetur dolores, dicta perferendis? Quos id eveniet necessitatibus quas aliquam at praesentium fugiat quaerat dolorem, excepturi natus!',
					),
				),
			)
		);

		$this->end_controls_section();

		// ===========Start Style Section==========



		// title
		$this->start_controls_section(
			'accordion_two_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'accordion_two_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .accordion .accordion-button' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_control(
			'accordion_two_title_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .accordion-button:not(.collapsed)' => 'background-color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'accordion_two_title_typography',
				'selector' => '{{WRAPPER}} .accordion .accordion-button',
				
			)
		);

		$this->end_controls_section();

		// content
		$this->start_controls_section(
			'accordion_two_content_style',
			array(
				'label' => __( 'Content', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'accordion_two_content_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .accordion .accordion-body' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_control(
			'accordion_two_content_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .accordion .accordion-collapse' => 'background-color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'accordion_two_content_typography',
				'selector' => '{{WRAPPER}} .accordion .accordion-body',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings   = $this->get_settings_for_display();
		$columns_no = 'col-lg-6';

		?>

		<div class="accordion accordionStyle2" id="accordionFAQ">
			<div class="row">
				<?php foreach ( $settings['accordion_two_items'] as $index => $item ) : ?>
					<div class="<?php echo esc_attr( $columns_no ); ?> wow animate__animated animate__fadeInUp" data-wow-delay=".0s">

						<div class="accordion-item">
							<h5 class="accordion-header" id="heading<?php echo $index + 1; ?>">
								<button class="accordion-button text-heading-5 <?php echo ( $index === 0 ) ? '' : 'collapsed'; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $index + 1; ?>" aria-expanded="<?php echo ( $index === 0 ) ? 'true' : 'false'; ?>" aria-controls="collapse<?php echo $index + 1; ?>"><?php echo $item['accordion_two_title']; ?></button>
							</h5>
							<div class="accordion-collapse collapse" id="collapse<?php echo $index + 1; ?>" aria-labelledby="heading<?php echo $index + 1; ?>" data-bs-parent="#accordionFAQ">
								<div class="accordion-body"><?php echo $item['accordion_two_content']; ?></div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<?php

	}
}
