<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Exit if accessed directly

/**
 * App Testimonial
 *
 * Elementor app Testimonial
 *
 * @since 1.0.0
 */
class Testimonial extends Widget_Base {


	public function get_name() {
		return 'iori-testimonial';
	}

	public function get_title() {
		return __( 'Testimonial', 'Iori' );
	}

	public function get_icon() {
		return 'eicon-testimonial d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'testimonial', 'carousel', 'slider', 'iori' );
	}

	/**
	 * Register image carousel widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'testimonial_section',
			array(
				'label' => __( 'Testimonial Section', 'iori' ),
			)
		);

		$this->add_control(
			'testimonial_top_title',
			array(
				'label'       => __( 'Top Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_top_btn',
			array(
				'label'       => __( 'Button Top', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'View All',
			)
		);

		$this->add_control(
			'testimonial_top_btn_link',
			array(
				'label'       => __( 'Button Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'testimonial_top_desc',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'testimonial_author_img',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_author_img_link',
			array(
				'label'       => esc_html__( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_author_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_author_title_link',
			array(
				'label'       => esc_html__( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_author_department',
			array(
				'label'       => __( 'Department', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_date',
			array(
				'label'       => __( 'Date', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_rating_star',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_rating',
			array(
				'label'   => 'Rating',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 1,
				'max'     => 5,
				'step'    => 1,
			)
		);

		$this->add_control(
			'testimonial_list',
			array(
				'label'   => __( 'Testimonial', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'testimonial_author_img'        => '',
						'testimonial_author_img_link'   => '',
						'testimonial_author_title'      => '',
						'testimonial_author_title_link' => '',
						'testimonial_author_department' => '',
						'testimonial_desc'              => '',
						'testimonial_date'              => '',
						'testimonial_rating_star'       => '',
						'testimonial_rating'            => '',
					),
					array(
						'testimonial_author_img'        => '',
						'testimonial_author_img_link'   => '',
						'testimonial_author_title'      => '',
						'testimonial_author_title_link' => '',
						'testimonial_author_department' => '',
						'testimonial_desc'              => '',
						'testimonial_date'              => '',
						'testimonial_rating_star'       => '',
						'testimonial_rating'            => '',
					),
					array(
						'testimonial_author_img'        => '',
						'testimonial_author_img_link'   => '',
						'testimonial_author_title'      => '',
						'testimonial_author_title_link' => '',
						'testimonial_author_department' => '',
						'testimonial_desc'              => '',
						'testimonial_date'              => '',
						'testimonial_rating_star'       => '',
						'testimonial_rating'            => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// =========== testimonial style start ===========

		$this->start_controls_section(
			'testimonial_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .testimonial_top_content .title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_title_typography',
				
				'selector' => '{{WRAPPER}} .testimonial_top_content .title',
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'testimonial_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .testimonial_top_content .desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_desc_typography',
				
				'selector' => '{{WRAPPER}} .testimonial_top_content .desc',
			)
		);

		$this->end_controls_section();

		// author name
		$this->start_controls_section(
			'testimonial_author_title_style',
			array(
				'label' => __( 'Author Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_author_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-author .author-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_author_title_typography',
				
				'selector' => '{{WRAPPER}} .box-author .author-name',
			)
		);

		$this->end_controls_section();

		// author department
		$this->start_controls_section(
			'testimonial_author_department_style',
			array(
				'label' => __( 'Department', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_author_department_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-author .department' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_author_department_typography',
				
				'selector' => '{{WRAPPER}} .box-author .department',
			)
		);

		$this->end_controls_section();

		// author description
		$this->start_controls_section(
			'testimonial_author_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_author_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-testimonial-grid .desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_author_desc_typography',
				
				'selector' => '{{WRAPPER}} .card-testimonial-grid .desc',
			)
		);

		$this->end_controls_section();

		// author date
		$this->start_controls_section(
			'testimonial_author_date_style',
			array(
				'label' => __( 'Date', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_author_date_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-bottom-info .date-post' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_author_date_typography',
				
				'selector' => '{{WRAPPER}} .card-bottom-info .date-post',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render image carousel widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( empty( $settings['testimonial_list'] ) ) {
			return;
		}
		$testimonial_lists = $settings['testimonial_list'];

		?>
		<section class="section bg-plant">
			<div class="row align-items-end">
				<div class="col-lg-8 col-md-8 testimonial_top_content">
					<h2 class="title mb-20 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['testimonial_top_title'] ); ?></h2>
					<div class="desc wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo $settings['testimonial_top_desc']; ?></div>
				</div>
				<div class="col-lg-4 col-md-4 text-md-end text-start">
					<a href="<?php echo esc_html( $settings['testimonial_top_btn_link'] ); ?>" class="btn btn-default font-sm-bold pl-0 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['testimonial_top_btn'] ); ?>
						<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
						</svg>
					</a>
				</div>
			</div>

			<div class="mt-50 wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
				<div class="box-swiper">
					<div class="swiper-container swiper-group-3">
						<div class="swiper-wrapper">
							<?php
							foreach ( $testimonial_lists as $testimonial_list ) { 
								?>
								<div class="swiper-slide">
									<div class="card-testimonial-grid">
										<div class="box-author mb-10">
											<a href="<?php echo esc_url( $testimonial_list['testimonial_author_img_link'] ); ?>"><img src="<?php echo $testimonial_list['testimonial_author_img']['url']; ?>" alt="iori">
											</a>
											<div class="author-info">
												<a href="<?php echo esc_url( $testimonial_list['testimonial_author_title_link'] ); ?>">
													<span class="author-name"><?php echo esc_html( $testimonial_list['testimonial_author_title'] ); ?></span>
												</a>
												<span class="department"><?php echo esc_html( $testimonial_list['testimonial_author_department'] ); ?></span>
											</div>
										</div>
										<div class="desc"><?php echo $testimonial_list['testimonial_desc']; ?></div>
										<div class="card-bottom-info">
											<span class="date-post"><?php echo $testimonial_list['testimonial_date']; ?></span>
											<div class="rating text-end">
												<?php
												$author_rating = intval( $testimonial_list['testimonial_rating'] );

												for ( $i = 1; $i <= $author_rating; $i++ ) {
													echo '<img src="' . $testimonial_list['testimonial_rating_star']['url'] . '">';
												}
												?>
											</div>
										</div>
									</div>
								</div>
								<?php
							}
							?>
						</div>
						<div class="swiper-pagination swiper-pagination-2 swiper-pagination-group-3"></div>
					</div>
				</div>
			</div>
		</section>

		<script>
			jQuery(document).ready(function($) {
				$(".swiper-group-3").each(function() {
					var swiper_3_items = new Swiper(this, {
						spaceBetween: 30,
						slidesPerView: 3,
						slidesPerGroup: 1,
						loop: true,
						navigation: {
							nextEl: ".swiper-button-next-group-3",
							prevEl: ".swiper-button-prev-group-3"
						},
						pagination: {
							el: ".swiper-pagination-group-3",
							clickable: true
						},
						autoplay: {
							delay: 10000
						},
						breakpoints: {
							1199: {
								slidesPerView: 3
							},
							800: {
								slidesPerView: 2
							},
							600: {
								slidesPerView: 1
							},
							400: {
								slidesPerView: 1
							},
							250: {
								slidesPerView: 1
							}
						}
					});
				});

			});
		</script>

		<?php

	}
}
