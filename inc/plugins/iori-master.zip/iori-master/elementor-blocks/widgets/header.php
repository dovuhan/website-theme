<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Exit if accessed directly

/**
 * Elementor Style for header.
 *
 * @since 1.0.0
 */
class Header extends Widget_Base {

	public function get_name() {
		return 'iori_page_header';
	}

	public function get_title() {
		return 'Header'; // title to show on iori
	}

	public function get_icon() {
		return 'eicon-heading d-icon'; // eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return array( 'iori-master-elements' ); // category of the widget
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 *
	 * @return array widget keywords
	 */
	public function get_keywords() {
		return array(
			'header',
			'nav',
			'onepage nav',
			'iori',
		);
	}

	/**
	 * A list of scripts that the widgets is depended in.
	 *
	 * @since 1.3.0
	 **/
	protected function register_controls() {
		// start of a control box
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Settings', 'iori' ), // section name for controler view
			)
		);

		$this->add_control(
			'anchor_description',
			array(
				'raw'             => __( '<b>Note - This is fixed header but, in elementor editing panel, its static for better customization. To see actual view please check live site.</b>', 'iori' ),
				'type'            => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-descriptor',
			)
		);

		$this->add_control(
			'banner_bg_img',
			array(
				'label'       => esc_html__( 'Upload Logo', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'default'     => array( 'url' => get_template_directory_uri() . '/assets/images/logo-white.png' ),
				'label_block' => true,
			)
		);

		$this->add_control(
			'logo_text',
			array(
				'label'       => esc_html__( 'Logo Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_menu',
			array(
				'label' => esc_html__( 'Nav Settings', 'iori' ),
			)
		);


		$menus = $this->get_available_menus();

		if ( ! empty( $menus ) ) {
			$this->add_control(
				'menu',
				array(
					'label'        => __( 'Menu', 'iori' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => $menus,
					'default'      => array_keys( $menus )[0],
					'save_default' => true,
					'separator'    => 'after',
				)
			);

			$this->add_control(
				'megamenu',
				array(
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf( __( '<strong>You have to setup megamenu from menus section.</strong><br>Go to the <a href="%s" target="_blank">Menus screen</a> to create megamenu.', 'iori' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator'       => 'after',
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				)
			);
		} else {
			$this->add_control(
				'menu',
				array(
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf( __( '<strong>There are no menus in your site.</strong><br>Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'iori' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator'       => 'after',
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				)
			);
		}

		$this->end_controls_section();
		// End  of a control box

		$this->start_controls_section(
			'section_social_or_button',
			array(
				'label' => esc_html__( 'Extra', 'iori' ), // section name for controler view
			)
		);

		$this->add_control(
			'search',
			array(
				'label'       => __( 'Search', 'iori' ),
				'type'        => Controls_Manager::SWITCHER,
			)
		);

		$this->add_control(
			'iori_getstarted_enable',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::SWITCHER,
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'       => esc_html__( 'Button Name', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'condition'   => array( 'iori_getstarted_enable' => 'yes' ),
				'default'     => 'Get Started',
			)
		);

		$this->add_control(
			'button_url',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::URL,
				'condition'   => array( 'iori_getstarted_enable' => 'yes' ),
				'placeholder' => __( 'https://your-link.com or #menuname for smooth scroll', 'iori' ),
			)
		);

		$this->end_controls_section();
		// End  of a control box

		/*
		===========================================
		=            style comment block            =
		===========================================*/

		$this->start_controls_section(
			'section_nav_style',
			array(
				'label' => __( 'Header Settings', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'header_bg_color',
			array(
				'label'     => __( 'Background Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .header.sticky-bar' => 'background-color: {{VALUE}};' ),
			)
		);
		

		$logo_spacing = 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: {{SIZE}}{{UNIT}};';

		$this->add_responsive_control(
			'logo_spacing',
			array(
				'label'     => __( 'Logo Spacing', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 300,
					),
				),
				'selectors' => array( '{{WRAPPER}} .iori-logo-img' => $logo_spacing ),
			)
		);

		$logo_size = 'width: {{SIZE}}{{UNIT}}; height: auto;';

		$this->add_responsive_control(
			'logo_size',
			array(
				'label'     => __( 'Logo Size', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 300,
					),
				),
				'selectors' => array( '{{WRAPPER}} .iori-logo-img, {{WRAPPER}} .iori-logo-img img' => $logo_size ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			array(
				'label' => __( 'Menu List', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'item_color',
			array(
				'label'     => __( 'Text Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .items.parent a:not(.sub-sub-menu a)' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => 'title_typography',
				'fields_options' => array( 'font_family' => array( 'default' => 'Roboto' ) ),
				'selector'       => '{{WRAPPER}} .items.parent a:not(.sub-sub-menu a)',
			)
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_extr_style',
			array(
				'label' => __( 'Extra', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'button_bg_color',
			array(
				'label'     => __( 'Button Background Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .btn-brand-1' => 'background-color: {{VALUE}};' ),
			)
		);

		$this->add_responsive_control(
			'button_txt_color',
			array(
				'label'     => __( 'Button Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .btn-brand-1' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_responsive_control(
			'button_src_color',
			array(
				'label'     => __( 'Search Icon Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .icon-list.search-post svg' => 'color: {{VALUE}};' ),
			)
		);

		$this->end_controls_section();


	}

	// end of control box

	private function get_available_menus() {
		$menus = wp_get_nav_menus();

		$options = array();

		foreach ( $menus as $menu ) {
			$options[ $menu->slug ] = $menu->name;
		}

		return $options;
	}

	protected function render() {
		// to show on the fontend
		$settings      = $this->get_settings_for_display();
		$banner_bg_img = $settings['banner_bg_img']['url'];
		$walker        = ( class_exists( 'Iori_Mega_Menu_Walker' ) ) ? new \Iori_Mega_Menu_Walker() : '';

		?>

		<header class="header sticky-bar border-0">
			<div class="container">
				<div class="main-header">
					<div class="header-left">
						<div class="header-logo">
						<?php
						if ( ! empty( $banner_bg_img ) ) { 
							?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="iori-logo-img navbar-brand">
							<img class="lazyestload" src="<?php echo esc_url( $banner_bg_img ); ?>" width="130" height="30"
							alt="<?php echo esc_attr( $settings['logo_text'] ); ?>">
							</a>
							<?php
						} else {
							?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>"
							class="iori-logo-img navbar-brand"><?php echo esc_html( $settings['logo_text'] ); ?></a>
						<?php } ?>
						</div>
						<div class="header-nav">

							<nav class="nav-main-menu d-none d-xl-block">
								<?php
								wp_nav_menu(
									array(
										'menu'           => $settings['menu'],
										'menu_class'     => 'main-menu',
										'walker'         => $walker,
										'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
									)
								);

								?>
							</nav>
							<div class="burger-icon burger-icon-white"><span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>
						</div>
						<div class="header-right">

							<?php

							$iori_searchbar_enable = $settings['search'];
							if ( $iori_searchbar_enable ) {
								?>
								<div class="d-inline-block box-search-top">
									<div class="form-search-top">
										<form action="<?php echo esc_url( home_url( '/' ) ); ?>">
											<input class="input-search" name="s" type="text" placeholder="Search...">
											<button class="btn btn-search">
												<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
												</svg>
											</button>
										</form>
									</div>
									<span class="font-lg icon-list search-post">
										<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
										</svg>
									</span>
								</div>

							<?php } ?>

							<?php

							$iori_getstarted_enable = $settings['iori_getstarted_enable'];
							$button_url             = $settings['button_url'];
							$button_text            = $settings['button_text'];
							
							if ( $iori_getstarted_enable ) {
								?>
								<div class="d-none d-sm-inline-block">
									<a class="btn btn-brand-1 hover-up" href="<?php echo esc_url( $button_url['url'] ); ?>">
										<?php echo esc_html( $button_text ); ?>
									</a>
								</div>
							<?php } ?>

						</div>
					</div>
				</div>
			</div>
		</header>


		<div class="mobile-header-active mobile-header-wrapper-style perfect-scrollbar">
			<div class="mobile-header-wrapper-inner">
				<div class="mobile-header-content-area">
					<div class="mobile-logo">
						<?php
						if ( ! empty( $banner_bg_img ) ) { 
							?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="iori-logo-img navbar-brand">
							<img class="lazyestload" src="<?php echo esc_url( $banner_bg_img ); ?>" width="130" height="30"
							alt="<?php echo esc_attr( $settings['logo_text'] ); ?>">
							</a>
							<?php
						} else {
							?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>"
							class="iori-logo-img navbar-brand"><?php echo esc_html( $settings['logo_text'] ); ?></a>
						<?php } ?>
					</div>
					<div class="burger-icon"><span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>
					<div class="perfect-scroll">
						<div class="mobile-menu-wrap mobile-header-border">
							<ul class="nav nav-tabs nav-tabs-mobile mt-25" role="tablist">
								<li>
									<a class="active" href="#tab-menu" data-bs-toggle="tab" role="tab" aria-controls="tab-menu" aria-selected="true">
										<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
										</svg><?php esc_html_e( 'Menu', 'iori' ); ?>
									</a>
								</li>
								<li>
									<a href="#tab-account" data-bs-toggle="tab" role="tab" aria-controls="tab-account" aria-selected="false">
										<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
										</svg><?php esc_html_e( 'Account', 'iori' ); ?>
									</a>
								</li>
								<li>
									<a href="#tab-notification" data-bs-toggle="tab" role="tab" aria-controls="tab-notification" aria-selected="false">
										<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
										</svg><?php esc_html_e( 'Notification', 'iori' ); ?>
									</a>
								</li>
							</ul>

							<div class="tab-content">
								<div class="tab-pane fade active show" id="tab-menu" role="tabpanel" aria-labelledby="tab-menu">
									<nav class="mt-15">
										<?php
										wp_nav_menu(
											array(
												'menu'   => $settings['menu'],
												'menu_class' => 'main-menu mobile-menu',
												'walker' => $walker,
												'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
												'depth'  => 2,
											)
										);
										?>
									</nav>
								</div>

								<div class="tab-pane fade" id="tab-account" role="tabpanel" aria-labelledby="tab-account">
									<nav class="mt-15">
										<ul class="mobile-menu font-heading">

											<?php
											$account_list_area = iori_theme_option( 'account_list_area' );

											foreach ( $account_list_area as $item ) { 
												?>

												<li><a href="<?php echo esc_url( $item['link'] ); ?>"><?php echo esc_html( $item['name'] ); ?></a></li>

											<?php } ?>

										</ul>
									</nav>
								</div>
								<div class="tab-pane fade" id="tab-notification" role="tabpanel" aria-labelledby="tab-notification">
									<p class="font-sm-bold color-brand-1 mt-30"><?php esc_html_e( 'Recent Posts', 'iori' ); ?></p>

									<div class="notifications-item">
										<?php
										$args = array(
											'post_type'   => 'post',
											'post_status' => 'publish',
											'posts_per_page' => 5,
											'orderby'     => 'date',
											'order'       => 'DESC',
										);

										$recent_posts = new \WP_Query( $args );

										if ( $recent_posts->have_posts() ) :
											while ( $recent_posts->have_posts() ) :
												$recent_posts->the_post();

												$author_id     = get_the_author_meta( 'ID' );
												$author_avatar = get_avatar( $author_id, 32 );
												?>
												<div class="item-notify">
													<div class="item-image">
														<?php echo wpautop( $author_avatar ); ?>
													</div>
													<div class="item-info">
														<p class="color-grey-500 font-xs"><strong class="font-xs-bold"><?php the_author(); ?></strong> <?php esc_html_e( 'Publised a post', 'iori' ); ?> “<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>”</p>
													</div>
													<div class="item-time"><span class="color-grey-500 font-xs"><?php echo human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) . ' ago'; ?></span></div>
												</div>
												<?php
											endwhile;
											wp_reset_postdata();
										else :
											echo '<p>No recent posts found.</p>';
										endif;
										?>
									</div>

								</div>
							</div>
						</div>
						<div class="site-copyright color-grey-400 mt-0">
							<div class="box-download-app">
								<p class="font-xs color-grey-400 mb-25"><?php echo esc_html( iori_theme_option( 'mobile_bottom_text' ) ); ?></p>
								<div class="mb-25">
									<?php
									$appstore_image                 = iori_theme_option( 'mobile_bottom_appstore_thumb' );
									$google_play_image              = iori_theme_option( 'mobile_bottom_google_play_thumb' );
									$payment_image                  = iori_theme_option( 'mobile_bottom_payment_thumb' );
									$mobile_bottom_appstore_link    = iori_theme_option( 'mobile_bottom_appstore_link' );
									$mobile_bottom_google_play_link = iori_theme_option( 'mobile_bottom_google_play_link' );
									?>
									<a href="<?php echo esc_url( $mobile_bottom_appstore_link ); ?>" class="mr-10">
										<img src="<?php echo esc_url( $appstore_image ); ?>" alt="iori">
									</a>
									<a href="<?php echo esc_url( $mobile_bottom_google_play_link ); ?>">
										<img src="<?php echo esc_url( $google_play_image ); ?>" alt="iori">
									</a>
								</div>
								<p class="font-sm color-grey-400 mt-20 mb-10"><?php echo esc_html( iori_theme_option( 'mobile_bottom_payment_text' ) ); ?></p>
								<img src="<?php echo esc_url( $payment_image ); ?>" alt="iori">
							</div>
							<div class="mb-0">
								<?php if ( ! empty( $copyrights ) ) { ?>
									<span class="color-grey-300 font-md"><?php echo wp_kses_post( $copyrights ); ?></span>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php
	}
}
