<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Exit if accessed directly

/**
 * App Testimonial
 *
 * Elementor app Testimonial Five
 *
 * @since 1.0.0
 */
class Testimonial_Five extends Widget_Base {


	public function get_name() {
		return 'iori-testimonial-five';
	}

	public function get_title() {
		return __( 'Testimonial Five', 'Iori' );
	}

	public function get_icon() {
		return 'eicon-testimonial d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'testimonial', 'reviews', 'iori' );
	}

	/**
	 * Register image carousel widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'testimonial_five_section',
			array(
				'label' => __( 'Testimonial Five', 'iori' ),
			)
		);

		$this->add_control(
			'testimonial_five_author_img',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_five_author_img_link',
			array(
				'label'       => esc_html__( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_five_author_title',
			array(
				'label'       => __( 'Author Name', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_five_author_title_link',
			array(
				'label'       => esc_html__( 'Author Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_five_author_department',
			array(
				'label'       => __( 'Department', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_five_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_five_date',
			array(
				'label'       => __( 'Date', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_five_rating_star',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_five_rating',
			array(
				'label'   => 'Rating',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 1,
				'max'     => 5,
				'step'    => 1,
			)
		);

		$this->end_controls_section();

		// =========== testimonial style start ===========

		// testimonial box
		$this->start_controls_section(
			'testimonial_five_box_style',
			array(
				'label' => __( 'Testimonial Box', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'testimonial_five_box_styles' );

		$this->start_controls_tab(
			'testimonial_five_box_normal',
			array(
				'label' => __( 'Normal', 'iori' ),
			)
		);

		$this->add_control(
			'testimonial_five_box_padding_normal',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'testimonial_five_box_bg_color_normal',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'testimonial_five_box_border_width_normal',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'testimonial_five_box_border_color_normal',
			array(
				'label'     => __( 'Border Color', 'iori' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'testimonial_five_box_border_radius_normal',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'box_shadow_normal',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid',
			)
		);

		$this->end_controls_tab();

		// hover start
		$this->start_controls_tab(
			'testimonial_five_box_hover',
			array(
				'label' => __( 'Hover', 'iori' ),
			)
		);

		$this->add_control(
			'testimonial_five_box_padding_hover',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'testimonial_five_box_bg_color_hover',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'testimonial_five_box_border_width_hover',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid:hover' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'testimonial_five_box_border_color_hover',
			array(
				'label'     => __( 'Border Color', 'iori' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'testimonial_five_box_border_radius_hover',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'box_shadow_hover',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .box-testimonial-2 .card-testimonial-grid:hover',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		// author name
		$this->start_controls_section(
			'testimonial_five_author_title_style',
			array(
				'label' => __( 'Author Name', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_five_author_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-author .author-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_five_author_title_typography',
				
				'selector' => '{{WRAPPER}} .box-author .author-name',
			)
		);

		$this->end_controls_section();

		// department
		$this->start_controls_section(
			'testimonial_five_author_department_style',
			array(
				'label' => __( 'Department', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_five_author_department_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-author .department' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_five_author_department_typography',
				
				'selector' => '{{WRAPPER}} .box-author .department',
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'testimonial_five_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_five_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .testimonial_five_desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_five_desc_typography',
				
				'selector' => '{{WRAPPER}} .testimonial_five_desc',
			)
		);

		$this->end_controls_section();

		// date
		$this->start_controls_section(
			'testimonial_five_date_style',
			array(
				'label' => __( 'Date', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_five_date_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-bottom-info .date-post' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_five_date_typography',
				
				'selector' => '{{WRAPPER}} .card-bottom-info .date-post',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render image carousel widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="box-testimonial-2">
			<div class="wow animate__animated animate__fadeIn" data-wow-delay=".s">
				<div class="card-testimonial-grid">
					<div class="box-author mb-10">
						<a href="<?php echo esc_url( $settings['testimonial_five_author_img_link'] ); ?>">
							<img src="<?php echo $settings['testimonial_five_author_img']['url']; ?>" alt="iori">
						</a>
						<div class="author-info">
							<a href="<?php echo esc_url( $settings['testimonial_five_author_title_link'] ); ?>"><span class="author-name"><?php echo esc_html( $settings['testimonial_five_author_title'] ); ?></span></a>
							<span class="department"><?php echo esc_html( $settings['testimonial_five_author_department'] ); ?></span>
						</div>
					</div>
					<div class="testimonial_five_desc"><?php echo $settings['testimonial_five_desc']; ?></div>
					<div class="card-bottom-info">
						<span class="date-post"><?php echo $settings['testimonial_five_date']; ?></span>
						<div class="rating text-end">
							<?php
							$author_rating = intval( $settings['testimonial_five_rating'] );

							for ( $i = 1; $i <= $author_rating; $i++ ) {
								echo '<img src="' . $settings['testimonial_five_rating_star']['url'] . '">';
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php
	}
}
