<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner Twelve
 *
 * Elementor widget for banner twelve
 *
 * @since 1.0.0
 */
class Banner_Twelve extends Widget_Base {


	public function get_name() {
		return 'iori-banner-twelve';
	}

	public function get_title() {
		return esc_html__( 'Banner Twelve', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-twelve', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_twelve_section',
			array(
				'label' => __( 'Banner Twelve', 'iori' ),
			)
		);

		$this->add_control(
			'banner_twelve_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_twelve_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_twelve_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_twelve_btn_top_text',
			array(
				'label'       => __( 'Button Top Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_twelve_app_img',
			array(
				'label'       => __( 'App Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_twelve_app_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);


		$this->add_control(
			'banner_twelve_app_img2',
			array(
				'label'       => __( 'App Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_twelve_app_img2_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_twelve_btn',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_twelve_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_twelve_form_title',
			array(
				'label'       => __( 'Form Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
				'separator'   => 'before',
			)
		);

		$this->end_controls_section();

		// content style

		// content box style
		$this->start_controls_section(
			'banner_twelve_box_style',
			array(
				'label' => __( 'Banner Box Style', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'banner_twelve_box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-radius-32-style-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'banner_twelve_box_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-radius-32-style-2' => 'background-color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .box-radius-32-style-2',
			)
		);

		$this->add_responsive_control(
			'banner_twelve_box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-radius-32-style-2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// subtitle
		$this->start_controls_section(
			'banner_twelve_subtitle_style',
			array(
				'label' => __( 'Subtitle', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_twelve_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-radius-32-style-2 .subtitle' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_twelve_subtitle_typography',
				'selector' => '{{WRAPPER}} .box-radius-32-style-2 .subtitle',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'banner_twelve_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_twelve_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-radius-32-style-2 .title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_twelve_title_typography',
				'selector' => '{{WRAPPER}} .box-radius-32-style-2 .title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_twelve_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_twelve_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-radius-32-style-2 .desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_twelve_desc_typography',
				'selector' => '{{WRAPPER}} .box-radius-32-style-2 .desc',
				
			)
		);

		$this->end_controls_section();

		// form title
		$this->start_controls_section(
			'banner_twelve_form_title_style',
			array(
				'label' => __( 'Form Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_twelve_form_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-signup .form-title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_twelve_form_title_typography',
				'selector' => '{{WRAPPER}} .box-signup .form-title',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$banner_twelve_app_img  = $settings['banner_twelve_app_img']['url'];
		$banner_twelve_app_img2 = $settings['banner_twelve_app_img2']['url'];
		?>

		<section class="section">
			<div class="container">
				<div class="box-radius-32-style-2">
					<div class="row align-items-center">
						<div class="col-lg-7">
							<span class="title-line subtitle line-48 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['banner_twelve_subtitle'] ); ?>
							</span>
							<h1 class="title mb-20 mt-1 wow animate__animated animate__fadeInUp" data-wow-delay=".2s"><?php echo esc_html( $settings['banner_twelve_title'] ); ?></h1>
							<div class="row">
								<div class="col-lg-9 wow animate__animated animate__fadeInUp" data-wow-delay=".4s">
									<div class="desc"><?php echo $settings['banner_twelve_desc']; ?></div>
								</div>
							</div>
							<div class="mt-30 wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
								<h5 class="color-brand-1"><?php echo esc_html( $settings['banner_twelve_btn_top_text'] ); ?></h5>
							</div>

							<div class="box-button mt-20 wow animate__animated animate__fadeInUp" data-wow-delay=".4s"><a class="btn-app mb-15 hover-up" href="<?php echo esc_url( $settings['banner_twelve_app_img_link'] ); ?>"><img src="<?php echo esc_url( $banner_twelve_app_img ); ?>" alt="iori"></a><a class="btn-app mb-15 hover-up" href="<?php echo esc_url( $settings['banner_twelve_app_img2_link'] ); ?>"><img src="<?php echo esc_url( $banner_twelve_app_img2 ); ?>" alt="iori"></a>
								<a class="btn btn-default mb-15 pl-10 font-sm-bold hover-up" href="<?php echo esc_url( $settings['banner_twelve_btn_link'] ); ?>"><?php echo esc_html( $settings['banner_twelve_btn'] ); ?>
									<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
									</svg>
								</a>
							</div>

						</div>
						<div class="col-lg-5 text-start position-relative wow animate__animated animate__fadeIn">
							<span class="arrow-down-banner shape-1"></span>
							<span class="arrow-right-banner shape-2"></span>
							<div class="box-signup">
								<h4 class="form-title mb-30"><?php echo esc_html( $settings['banner_twelve_form_title'] ); ?></h4>
								<form action="" method="POST">
									<?php echo do_shortcode( '[contact-form-7 id="1887" title="home-4-form"]' ); ?>
								</form>

							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
