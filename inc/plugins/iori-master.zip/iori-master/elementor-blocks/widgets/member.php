<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Member
 *
 * @since 1.0.0
 */

class Member extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-member';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Member', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-person d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'member', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'member_section',
			array(
				'label' => __( 'Member', 'iori' ),
			)
		);

		$this->add_control(
			'member_img',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'member_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'member_designation',
			array(
				'label'       => __( 'Designation', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'member_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'member_social_icons',
			array(
				'label'            => esc_html__( 'Select Icons', 'iori' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => array(
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				),
			)
		);

		$repeater->add_control(
			'member_social_icons_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'member_social_icon_list',
			array(
				'label'   => __( 'Icons List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'member_social_icons'      => '',
						'member_social_icons_link' => '',
					),
					array(
						'member_social_icons'      => '',
						'member_social_icons_link' => '',
					),
					array(
						'member_social_icons'      => '',
						'member_social_icons_link' => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// start style here

		// title
		$this->start_controls_section(
			'member_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'member_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'member_title_typography',
				'selector' => '{{WRAPPER}} .card-info .title',
				
			)
		);

		$this->end_controls_section();

		// designation
		$this->start_controls_section(
			'member_designation_style',
			array(
				'label' => __( 'Designation', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'member_designation_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .designation' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'member_designation_typography',
				'selector' => '{{WRAPPER}} .card-info .designation',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'member_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'member_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-bottom .desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'member_desc_typography',
				'selector' => '{{WRAPPER}} .card-bottom .desc',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$member_social_icon_lists = $settings['member_social_icon_list'];

		?>
		<div class="card-member">
			<div class="card-top">
				<div class="card-image">
					<img src="<?php echo esc_url( $settings['member_img']['url'] ); ?>" alt="iori">
				</div>
				<div class="card-info">
					<span class="title"><?php echo esc_html( $settings['member_title'] ); ?></span>
					<p class="designation"><?php echo esc_html( $settings['member_designation'] ); ?></p>
					<div class="list-socials">
						<?php
						foreach ( $member_social_icon_lists as $member_social_icon_list ) {

							$icon = $member_social_icon_list['member_social_icons'];
							if ( is_array( $icon['value'] ) ) {
								if ( isset( $member_social_icon_list['member_social_icons_link'] ) ) {
									echo '<a href="' . esc_url( $member_social_icon_list['member_social_icons_link'] ) . '" class="icon-socials"><img src="' . $icon['value']['url'] . '" /></a>';
								} else {
									// Handle case when "member_social_icons_link" is not defined
									echo '<a href="#" class="icon-socials"><img src="' . $icon['value']['url'] . '" /></a>';
								}
							} else {
								?>
								<a href="<?php echo isset( $member_social_icon_list['member_social_icons_link'] ) ? esc_url( $member_social_icon_list['member_social_icons_link'] ) : '#'; ?>" class="icon-socials <?php echo $icon['value']; ?>"></a>
								<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<div class="card-bottom">
				<div class="desc"><?php echo $settings['member_desc']; ?></div>
			</div>
		</div>

		<?php
	}
}
