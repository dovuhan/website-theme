<?php
namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class Product extends Widget_Base {

	public function get_name() {
		return 'iori_product';
	}

	public function get_title() {
		return 'Product'; // title to show on iori
	}

	public function get_icon() {
		return 'eicon-woocommerce d-icon';    // eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'feature', 'product', 'woo', 'iori' );
	}

	/**
	 * Register featured box.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// start of a control box
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Settings', 'iori' ),   // section name for controler view
			)
		);

		$this->add_control(
			'show',
			array(
				'label'       => __( 'Query', 'iori' ),
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					''         => __( 'Recent Product', 'iori' ),
					'onsale'   => __( 'Sale', 'iori' ),
					'featured' => __( 'Featured', 'iori' ),
					'category' => __( 'By Category', 'iori' ),
				),
			)
		);

		$args         = array(
			'order'      => 'ASC',
			'hide_empty' => 0,
		);
		$product_cats = get_terms( 'product_cat', $args );

		$product_cat = array();
		if ( $product_cats ) {
			foreach ( $product_cats as $cform ) {
				$product_cat[ $cform->slug ] = $cform->name;
			}
		} else {
			$product_cat[ __( 'No Category found', 'iori' ) ] = 0;
		}

		$this->add_control(
			'prod_cat',
			array(
				'label'       => __( 'Category', 'iori' ),
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => $product_cat,
				'condition'   => array(
					'show' => 'category',
				),
			)
		);

		$this->add_control(
			'number',
			array(
				'label'       => __( 'Number of products to show', 'iori' ),
				'type'        => Controls_Manager::NUMBER,
				'label_block' => true,
			)
		);

		$this->add_control(
			'product_row',
			array(
				'label'       => __( 'Number of products in a row', 'iori' ),
				'type'        => Controls_Manager::NUMBER,
				'label_block' => true,
				'default'     => '3',
			)
		);

		$this->add_control(
			'orderby',
			array(
				'label'       => __( 'Order By', 'iori' ),
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'date'   => __( 'Date', 'iori' ),
					'title'  => __( 'Title', 'iori' ),
					'price'  => __( 'Price', 'iori' ),
					'rand'   => __( 'Random', 'iori' ),
					'sales'  => __( 'Popularity', 'iori' ),
					'rating' => __( 'Top Rated', 'iori' ),
				),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'       => __( 'Order', 'iori' ),
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'asc'  => __( 'ASC', 'iori' ),
					'desc' => __( 'DESC', 'iori' ),
				),
			)
		);

		$this->add_control(
			'hide_free',
			array(
				'label'       => __( 'Hide free products', 'iori' ),
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'no'  => __( 'No', 'iori' ),
					'yes' => __( 'Yes', 'iori' ),
				),
			)
		);

		$this->add_control(
			'show_hidden',
			array(
				'label'       => __( 'Show Hidden products', 'iori' ),
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'no'  => __( 'No', 'iori' ),
					'yes' => __( 'Yes', 'iori' ),
				),
			)
		);

		$this->add_responsive_control(
			'column_space',
			array(
				'label'     => __( 'Column Gap', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .iori-woo-product .products-grid li' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .iori-woo-product .products-grid li' => 'margin-right: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
		// End  of a control box

		$this->start_controls_section(
			'section_style_layout',
			array(
				'label' => __( 'Layout', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'item_bg_color',
			array(
				'label'     => __( 'Background Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .product-item' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_title',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'text_color',
			array(
				'label'     => __( 'Text Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .product-details--1st h2' => 'color: {{VALUE}};',

				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				
				'selector' => '{{WRAPPER}} .product-details--1st h2',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_price',
			array(
				'label' => __( 'Price', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'price_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .product-details--1st .price, {{WRAPPER}} .product-details--2nd .price' => 'color: {{VALUE}};',

				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_typography',
				
				'selector' => '{{WRAPPER}} .product-details--1st .price, {{WRAPPER}} .product-details--2nd .price',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_button',
			array(
				'label' => __( 'Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'button_color',
			array(
				'label'     => __( 'Button Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn-submit' => 'background-color: {{VALUE}};border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_color_hover',
			array(
				'label'     => __( 'Button Hover Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn-submit:hover' => 'background-color: {{VALUE}};border-color: {{VALUE}};',

				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				
				'selector' => '{{WRAPPER}} .btn-submit',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return false;
		}

		// to show on the fontend
		$settings                    = $this->get_settings_for_display();
		$product_visibility_term_ids = wc_get_product_visibility_term_ids();
		$number                      = ( $settings['number'] ) ? $settings['number'] : 6;
		$order                       = ( $settings['order'] ) ? $settings['order'] : 'desc';
		$orderby                     = ( $settings['orderby'] ) ? $settings['orderby'] : 'date';
		$show                        = ( $settings['show'] ) ? $settings['show'] : '';

		$query_args = array(
			'posts_per_page' => $number,
			'post_status'    => 'publish',
			'post_type'      => 'product',
			'no_found_rows'  => 1,
			'order'          => $order,
			'product_cat'    => $settings['prod_cat'],
			'meta_query'     => array(),
			'tax_query'      => array(
				'relation' => 'AND',
			),
		); // WPCS: slow query ok.

		if ( empty( $settings['show_hidden'] == 'yes' ) ) {
			$query_args['tax_query'][] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'term_taxonomy_id',
				'terms'    => is_search() ? $product_visibility_term_ids['exclude-from-search'] : $product_visibility_term_ids['exclude-from-catalog'],
				'operator' => 'NOT IN',
			);
			$query_args['post_parent'] = 0;
		}

		if ( ! empty( $settings['hide_free'] == 'yes' ) ) {
			$query_args['meta_query'][] = array(
				'key'     => '_price',
				'value'   => 0,
				'compare' => '>',
				'type'    => 'DECIMAL',
			);
		}

		if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
			$query_args['tax_query'][] = array(
				array(
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => $product_visibility_term_ids['outofstock'],
					'operator' => 'NOT IN',
				),
			); // WPCS: slow query ok.
		}

		if ( ! empty( $show ) ) {
			switch ( $show ) {
				case 'featured':
					$query_args['tax_query'][] = array(
						'taxonomy' => 'product_visibility',
						'field'    => 'term_taxonomy_id',
						'terms'    => $product_visibility_term_ids['featured'],
					);
					break;
				case 'onsale':
					$product_ids_on_sale    = wc_get_product_ids_on_sale();
					$product_ids_on_sale[]  = 0;
					$query_args['post__in'] = $product_ids_on_sale;
					break;
			}
		}

		switch ( $orderby ) {
			case 'price':
				$query_args['meta_key'] = '_price'; // WPCS: slow query ok.
				$query_args['orderby']  = 'meta_value_num';
				break;
			case 'rand':
				$query_args['orderby'] = 'rand';
				break;
			case 'sales':
				$query_args['meta_key'] = 'total_sales'; // WPCS: slow query ok.
				$query_args['orderby']  = 'meta_value_num';
				break;
			case 'rating':
				$query_args['meta_key'] = '_wc_average_rating'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$query_args['orderby']  = 'meta_value_num';
				break;
			case 'title':
				$query_args['orderby'] = 'title';
				break;
			default:
				$query_args['orderby'] = 'date';
		}

		?>
		<div class="st-new-arrivals iori-woo-product">
			<div class="container">
				<div class="products-widget">
					<div class="products-widget-content products-grid">
						<ul class="list-unstyled products columns-<?php echo $settings['product_row']; ?>">
							<?php
							$the_query = new \WP_Query( $query_args );
							while ( $the_query->have_posts() ) {
								$the_query->the_post();
								/**
								* Hook: woocommerce_shop_loop.
								*/
								wc_get_template_part( 'content', 'product' );
							}
								wp_reset_postdata();
							?>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
		<?php
	}
}

