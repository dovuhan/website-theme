<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Brand
 *
 * @since 1.0.0
 */

class Brand extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-brand';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Brand', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-box d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'brand', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'brand_section',
			array(
				'label' => __( 'Brand', 'iori' ),
			)
		);

		$this->add_control(
			'brand_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'brand_img',
			array(
				'label'   => esc_html__( 'Upload Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'brand_item_list',
			array(
				'label'   => __( 'Brand Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'brand_img' => '',
					),
					array(
						'brand_img' => '',
					),
					array(
						'brand_img' => '',
					),
				),
			)
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => 'thumbnail',
				'separator' => 'none',
			)
		);

		$this->end_controls_section();

		// start style here

		// title
		$this->start_controls_section(
			'brand_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'brand_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .brand_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'brand_title_typography',
				'selector' => '{{WRAPPER}} .brand_title',
				
			)
		);

		$this->end_controls_section();

		// border width
		$this->start_controls_section(
			'brand_border_style',
			array(
				'label' => __( 'Brand Box', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'brand_border_width',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'range'      => array(
					'px' => array(
						'max' => 20,
					),
					'em' => array(
						'max' => 2,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .box-radius-logo' => 'border-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'brand_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-radius-logo' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'brand_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-radius-logo' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'brand_shadow',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .box-radius-logo',
			)
		);

		$this->add_control(
			'brand_border_bg',
			array(
				'label'     => esc_html__( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-radius-logo' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$brand_item_lists = $settings['brand_item_list'];

		?>

		<div class="section">
			<div class="box-radius-logo">
				<div class="text-center">
					<p class="brand_title wow animate__animated animate__fadeInUp"><?php echo esc_html( $settings['brand_title'] ); ?></p>
				</div>
				<div>
					<ul class="list-partners mb-0 wow animate__animated animate__fadeInUp">

						<?php
						foreach ( $brand_item_lists as $brand_item_list ) { 
							?>

							<li><img src="<?php echo $brand_item_list['brand_img']['url']; ?>" alt="iori"></li>

							<?php
						} 
						?>

					</ul>
				</div>
			</div>
		</div>

		<?php
	}
}
