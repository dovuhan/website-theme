<?php
namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Nav_Menu extends Widget_Base {

	protected $nav_menu_index = 1;

	public function get_name() {
		return 'iori-nav-menu';
	}

	public function get_title() {
		return __( 'Nav Menu', 'iori' );
	}

	public function get_icon() {
		return 'eicon-nav-menu d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	public function get_keywords() {
		return array( 'menu', 'nav', 'button', 'iori' );
	}

	public function get_script_depends() {
		return array( 'smartmenus' );
	}

	public function on_export( $element ) {
		unset( $element['settings']['menu'] );

		return $element;
	}

	protected function get_nav_menu_index() {
		return $this->nav_menu_index++;
	}

	private function get_available_menus() {
		$menus = wp_get_nav_menus();

		$options = array();

		foreach ( $menus as $menu ) {
			$options[ $menu->slug ] = $menu->name;
		}

		return $options;
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_layout',
			array(
				'label' => __( 'Layout', 'iori' ),
			)
		);

		$menus = $this->get_available_menus();

		if ( ! empty( $menus ) ) {
			$this->add_control(
				'menu',
				array(
					'label'        => __( 'Menu', 'iori' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => $menus,
					'default'      => array_keys( $menus )[0],
					'save_default' => true,
					'separator'    => 'after',
				)
			);
		} else {
			$this->add_control(
				'menu',
				array(
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf( __( '<strong>There are no menus in your site.</strong><br>Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'iori' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator'       => 'after',
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				)
			);
		}

		$this->add_control(
			'megamenu',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf( __( '<strong>You have to setup megamenu from menus section.</strong><br>Go to the <a href="%s" target="_blank">Menus screen</a> to create megamenu.', 'iori' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
				'separator'       => 'after',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'              => __( 'Layout', 'iori' ),
				'type'               => Controls_Manager::SELECT,
				'options'            => array(
					''         => __( 'Default', 'iori' ),
					'dropdown' => __( 'Dropdown Menu', 'iori' ),
				),
				'frontend_available' => true,
			)
		);

		$this->add_control(
			'drpdowntx',
			array(
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Dropdown Placeholder Text', 'iori' ),
				'default'   => 'English',
				'condition' => array(
					'layout' => 'dropdown',
				),
			)
		);

		$this->add_control(
			'popmenu',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( '<strong>Popup Menu will show in frontend</strong><br>For design please set default menu and styled it. After complete design, active popup menu.', 'iori' ),
				'separator'       => 'after',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'iori_main_menu_position',
			array(
				'label'   => esc_html__( 'Menu position', 'iori' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'd-lg-flex justify-content-start',
				'options' => array(
					'd-lg-flex justify-content-start'   => esc_html__( 'Left', 'iori' ),
					'd-lg-flex justify-content-end'     => esc_html__( 'Right', 'iori' ),
					'd-lg-flex justify-content-center'  => esc_html__( 'Center', 'iori' ),
					'd-lg-flex justify-content-between' => esc_html__( 'Justified', 'iori' ),
				),
			)
		);

		$this->add_responsive_control(
			'iori_main_menu_mob_position',
			array(
				'label'   => esc_html__( 'Mobile Menu Icon position', 'iori' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'd-lg-flex justify-content-start',
				'options' => array(
					'd-lg-flex justify-content-start'   => esc_html__( 'Left', 'iori' ),
					'd-lg-flex justify-content-end'     => esc_html__( 'Right', 'iori' ),
					'd-lg-flex justify-content-center'  => esc_html__( 'Center', 'iori' ),
					'd-lg-flex justify-content-between' => esc_html__( 'Justified', 'iori' ),
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_menu_menu',
			array(
				'label' => __( 'Normal Menu (Not Megamenu)', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'menu_typography',
				'selector' => '{{WRAPPER}} .iori-elementor-menu .parent-menu .iori-nav-link span',
			)
		);

		$this->start_controls_tabs( 'tabs_menu_item_style' );

		$this->start_controls_tab(
			'tab_menu_item_normal',
			array(
				'label' => __( 'Normal', 'iori' ),
			)
		);

		$this->add_control(
			'color_menu_item',
			array(
				'label'     => __( 'Text Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .parent-menu .iori-nav-link span:not(.menu-label)' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_menu_item_hover',
			array(
				'label' => __( 'Hover', 'iori' ),
			)
		);

		$this->add_control(
			'color_menu_item_hover',
			array(
				'label'     => __( 'Text Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .parent-menu .iori-nav-link span:hover,
					{{WRAPPER}} .iori-elementor-menu .parent-menu .iori-nav-link span.elementor-item-active,
					{{WRAPPER}} .iori-elementor-menu .parent-menu .iori-nav-link span.highlighted,
					{{WRAPPER}} .iori-elementor-menu .parent-menu .iori-nav-link span:focus' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_menu_item_active',
			array(
				'label' => __( 'Active', 'iori' ),
			)
		);

		$this->add_control(
			'color_menu_item_active',
			array(
				'label'     => __( 'Text Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .parent-menu .iori-nav-link span.elementor-item-active' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		/* This control is required to handle with complicated conditions */
		$this->add_control(
			'hr',
			array(
				'type'  => Controls_Manager::DIVIDER,
				'style' => 'thick',
			)
		);

		$this->add_responsive_control(
			'padding_horizontal_menu_item',
			array(
				'label'     => __( 'Horizontal Padding', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'max' => 50,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .level0:not(.sub-menu .iori-megamenu) > .iori-nav-link span:not(.menu-label)' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->add_responsive_control(
			'padding_vertical_menu_item',
			array(
				'label'     => __( 'Vertical Padding', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'max' => 50,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .level0:not(.sub-menu .iori-megamenu) > .iori-nav-link span:not(.menu-label)' => 'display: block; padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->add_responsive_control(
			'padding_badge_menu_item',
			array(
				'label'     => __( 'Menu Badge', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'max' => 50,
					),
				),
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}} .menu-label' => 'top: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// mobile  menu
		// ===================
		$this->start_controls_section(
			'section_style_mob_menu',
			array(
				'label' => __( 'Mobile Menu', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'tabs_menu_item_popup_style' );

		$this->start_controls_tab(
			'tab_menu_item_popup_normal',
			array(
				'label' => __( 'Normal', 'iori' ),
			)
		);

		$this->add_control(
			'popup_menu_icon',
			array(
				'label'     => __( 'Text Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .menubar-icon span:before' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'popup_menu_bg',
			array(
				'label'     => __( 'Background Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .menubar-icon span:before' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_menu_item_popup_hover',
			array(
				'label' => __( 'Hover', 'iori' ),
			)
		);

		$this->add_control(
			'popup_menu_icon_hover',
			array(
				'label'     => __( 'Hover Text Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .menubar-icon span:hover:before' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'popup_menu_bg_hover',
			array(
				'label'     => __( 'Hover Background Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .iori-elementor-menu .menubar-icon span:hover:before' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

	}

	protected function render() {
		$available_menus = $this->get_available_menus();

		if ( ! $available_menus ) {
			return;
		}

		$settings = $this->get_active_settings();
		$walker   = ( class_exists( 'Iori_Mega_Menu_Walker' ) ) ? new \Iori_Mega_Menu_Walker() : '';

		$args = array(
			'echo'           => false,
			'menu'           => $settings['menu'],
			'menu_class'     => 'parent-menu ' . $settings['iori_main_menu_position'],
			'menu_id'        => 'menu-' . $this->get_nav_menu_index() . '-' . $this->get_id(),
			'fallback_cb'    => '__return_empty_string',
			'walker'         => $walker,
			'theme_location' => 'menu-1',
			'depth'          => 2,
		);

		if ( 'vertical' === $settings['layout'] ) {
			$args['menu_class'] .= ' sm-vertical';
		}

		// Add custom filter to handle Nav Menu HTML output.

		add_filter( 'nav_menu_item_id', '__return_empty_string' );

		// General Menu.
		$menu_html = wp_nav_menu( $args );

		// Dropdown Menu.
		$args['menu_id']    = 'menu-' . $this->get_nav_menu_index() . '-' . $this->get_id();
		$dropdown_menu_html = wp_nav_menu( $args );

		// Remove all our custom filters.

		remove_filter( 'nav_menu_item_id', '__return_empty_string' );

		if ( empty( $menu_html ) ) {
			return;
		}
		$layout = $settings['layout'];
		

		$section_id = $this->get_id();
		?>
		
		<div class="header iori-elementor-menu">
			<?php if ( 'dropdown' === $layout ) { ?>
				<nav class="navigation-top-menu">
					<div class="d-none nav<?php echo $section_id; ?>">
						<?php echo $dropdown_menu_html; ?>
					</div>
				</nav>
				<div class="dropdown-select dropdown-select-<?php echo $section_id; ?>"></div>
				<script>
					jQuery(function() {
						jQuery("<select />").appendTo(".dropdown-select-<?php echo $section_id; ?>");
						jQuery("<option />", {
							"text"    : "<?php echo $settings['drpdowntx']; ?>"
						}).appendTo(".dropdown-select-<?php echo $section_id; ?> select");
						jQuery(".nav<?php echo $section_id; ?> a").each(function() {
							var el = jQuery(this);
							jQuery("<option />", {
								"value"   : el.attr("href"),
								"text"    : el.text()
							}).appendTo(".dropdown-select-<?php echo $section_id; ?> select");
						});
						jQuery(".dropdown-select-<?php echo $section_id; ?> select").change(function() {
							window.location = jQuery(this).find("option:selected").val();
						});    
					});
				</script>
			<?php } else { ?>
				<div class="top-menu">
					<nav class="navigation-top-menu">
					<?php echo $dropdown_menu_html; ?>
					</nav>
				</div>
			<?php } ?>
		</div>
		<?php
	}
}

