<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Testimonial
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Top_Content extends Widget_Base {


	public function get_name() {
		return 'iori-top-content';
	}

	public function get_title() {
		return esc_html__( 'Top Content', 'iori' );
	}

	public function get_icon() {
		return 'eicon-post-content d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'content', 'text', 'heading', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'top_content_section',
			array(
				'label' => esc_html__( 'Top Content', 'iori' ),
			)
		);

		$this->add_control(
			'top_content_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'top_content_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'top_content_btn',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'top_content_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->end_controls_section();
		// Content options End

		// =========== Start Style Section ==========

		// title
		$this->start_controls_section(
			'content_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .top_content_wrap .top_content_title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_title_typography',
				'selector' => '{{WRAPPER}} .top_content_wrap .top_content_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'content_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .top_content_wrap .top_content_desc' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_desc_typography',
				'selector' => '{{WRAPPER}} .top_content_wrap .top_content_desc',
				
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<section class="section">
			<div class="row align-items-end">
				<div class="col-lg-8 col-md-8 top_content_wrap">
					<h2 class="top_content_title mb-20 mt-0 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['top_content_title'] ); ?></h2>
					<div class="top_content_desc wow animate__animated animate__fadeInUp" data-wow-delay=".02s"><?php echo $settings['top_content_desc']; ?></div>
				</div>
				<div class="col-lg-4 col-md-4 text-md-end text-start">
					<a href="<?php echo esc_url( $settings['top_content_btn_link'] ); ?>" class="btn btn-default font-sm-bold pl-0 wow animate__animated animate__fadeInUp" data-wow-delay=".04s"><?php echo esc_html( $settings['top_content_btn'] ); ?>
						<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
						</svg>
					</a>
				</div>
			</div>
		</section>


		<?php
	}
}
