<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner_Ten
 *
 * Elementor widget for banner_ten
 *
 * @since 1.0.0
 */
class Banner_Ten extends Widget_Base {


	public function get_name() {
		return 'iori-banner-ten';
	}

	public function get_title() {
		return esc_html__( 'Banner Ten', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-ten', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_ten_section',
			array(
				'label' => __( 'Banner Ten', 'iori' ),
			)
		);

		$this->add_control(
			'banner_ten_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_ten_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_ten_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_ten_app_img',
			array(
				'label'       => __( 'App Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_ten_app_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);


		$this->add_control(
			'banner_ten_app_img2',
			array(
				'label'       => __( 'Google Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_ten_app_img2_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->end_controls_section();

		// content style start

		// subtitle
		$this->start_controls_section(
			'banner_ten_subtitle_style',
			array(
				'label' => __( 'Sub Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_ten_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-12 .banner10_subtitle' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_ten_subtitle_typography',
				'selector' => '{{WRAPPER}} .banner-12 .banner10_subtitle',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'banner_ten_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_ten_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-12 .banner10_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_ten_title_typography',
				'selector' => '{{WRAPPER}} .banner-12 .banner10_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_ten_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_ten_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-12 .banner10_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_ten_desc_typography',
				'selector' => '{{WRAPPER}} .banner-12 .banner10_desc',
				
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$banner_ten_app_img  = $settings['banner_ten_app_img']['url'];
		$banner_ten_app_img2 = $settings['banner_ten_app_img2']['url'];

		?>


		<section class="section banner-12">
			<div class="asset-1 shape-1"></div>
			<div class="asset-2 shape-2"></div>
			<div class="asset-3 shape-3"></div>
			<div class="asset-4 shape-1"></div>
			<div class="asset-5 shape-2"></div>
			<div class="container text-center">
				<div class="row mt-150">
					<div class="col-xl-8 col-lg-10 m-auto">
						<span class="banner10_subtitle wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html( $settings['banner_ten_subtitle'] ); ?></span>
						<h1 class="banner10_title mb-25 mt-10 wow animate__animated animate__fadeIn" data-wow-delay=".2s">
							<?php echo esc_html( $settings['banner_ten_title'] ); ?>
						</h1>
						<div class="banner10_desc mb-25 wow animate__animated animate__fadeIn" data-wow-delay=".4s"><?php echo $settings['banner_ten_desc']; ?></div>
						<div class="wow animate__animated animate__fadeIn" data-wow-delay=".6s">
							<a href="<?php echo esc_url( $settings['banner_ten_app_img_link'] ); ?>"><img class="mr-10" src="<?php echo esc_url( $banner_ten_app_img ); ?>" alt="iori"></a>
							<a href="<?php echo esc_url( $settings['banner_ten_app_img2_link'] ); ?>"><img src="<?php echo esc_url( $banner_ten_app_img2 ); ?>" alt="iori"></a>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
