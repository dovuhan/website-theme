<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Content Box Three
 *
 * Elementor widget for Content Box Three
 *
 * @since 1.0.0
 */
class Content_Box_Three extends Widget_Base {


	public function get_name() {
		return 'iori-content-box-three';
	}

	public function get_title() {
		return esc_html__( 'Content Box Three', 'iori' );
	}

	public function get_icon() {
		return 'eicon-info-box d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'content', 'box', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'content_box_three_section',
			array(
				'label' => esc_html__( 'Content Box Three', 'iori' ),
			)
		);

		$this->add_control(
			'content_box_three_img',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'content_box_three_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'content_box_three_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
				'label_block' => true,
			)
		);

		$this->add_control(
			'content_box_three_title_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'content_box_three_rating_star',
			array(
				'label'       => esc_html__( 'Rating Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'content_box_three_rating',
			array(
				'label'   => 'Rating',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 1,
				'max'     => 5,
				'step'    => 1,
			)
		);


		$this->end_controls_section();
		// Content options End

		// =========== Start Style Section ==========

		// title
		$this->start_controls_section(
			'content_box_three_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_box_three_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .author-info .author-name' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_box_three_typography',
				'selector' => '{{WRAPPER}} .author-info .author-name',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
		<div class="box-author wow animate__animated animate__fadeIn" data-wow-delay=".6s">
			<a href="<?php echo esc_url( $settings['content_box_three_img_link'] ); ?>"><img src="<?php echo esc_url( $settings['content_box_three_img']['url'] ); ?>" alt="iori"></a>
			<div class="author-info">
				<a href="<?php echo esc_url( $settings['content_box_three_title_link'] ); ?>">
					<span class="author-name"><?php echo esc_html( $settings['content_box_three_title'] ); ?></span>
				</a>
				<div class="rating d-inline-block">
					<?php
					$author_rating = intval( $settings['content_box_three_rating'] );

					for ( $i = 1; $i <= $author_rating; $i++ ) {
						echo '<img src="' . $settings['content_box_three_rating_star']['url'] . '">';
					}
					?>
				</div>
			</div>
		</div>

		<?php
	}
}
