<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Brand
 *
 * @since 1.0.0
 */

class Brand_Slider extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-brand-slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Brand Slider', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-slider d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'brand', 'slider', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'brand_section',
			array(
				'label' => __( 'Brand', 'iori' ),
			)
		);

		$this->add_control(
			'brand_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'brand_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'carousel',
			array(
				'label'      => esc_html__( 'Add Images', 'iori' ),
				'type'       => Controls_Manager::GALLERY,
				'default'    => array(),
				'show_label' => false,
				'dynamic'    => array(
					'active' => true,
				),
			)
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => 'thumbnail',
				'separator' => 'none',
			)
		);

		$this->end_controls_section();

		// start style here

		// slide box
		$this->start_controls_section(
			'brand_slide_box_style',
			array(
				'label' => __( 'Slide Box', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'brand_slide_box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-radius-bottom' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'brand_slide_box_bg_color',
			array(
				'label'     => __( 'Background Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-radius-bottom' => 'background-color: {{VALUE}};',
				),
				
			)
		);

		$this->add_control(
			'brand_slide_box_border_width',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'range'      => array(
					'px' => array(
						'max' => 20,
					),
					'em' => array(
						'max' => 2,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .box-radius-bottom' => 'border-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'brand_slide_box_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-radius-bottom' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'brand_slide_box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-radius-bottom' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'brand_slide_box_shadow',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .box-radius-bottom',
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'brand_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'brand_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .brand_content .brand_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'brand_title_typography',
				'selector' => '{{WRAPPER}} .brand_content .brand_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'brand_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'brand_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .brand_content .brand_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'brand_desc_typography',
				'selector' => '{{WRAPPER}} .brand_content .brand_desc',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
		<section class="section">
			<div class="box-radius-bottom">
				<div class="container">
					<div class="brand_content text-center">
						<h3 class="brand_title mb-15 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['brand_title'] ); ?></h3>
						<div class="brand_desc wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo ( $settings['brand_desc'] ); ?>
						</div>
					</div>
					<div class="mt-30 wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
						<div class="box-swiper">
							<div class="swiper-container swiper-group-8">
								<div class="swiper-wrapper">
									<?php
									foreach ( $settings['carousel'] as $index => $attachment ) {
										$image_url = Group_Control_Image_Size::get_attachment_image_src( $attachment['id'], 'thumbnail', $settings );

										if ( ! $image_url && isset( $attachment['url'] ) ) {
											$image_url = $attachment['url'];
										}
										?>
										<div class="swiper-slide">
											<img src="<?php echo $image_url; ?>" alt="iori">
										</div>
									<?php } ?>
								</div>
								<div class="swiper-pagination swiper-pagination-group-8"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>


		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				jQuery(".swiper-group-8").each(function() {
					var swiper_8_items = new Swiper(this, {
						spaceBetween: 30,
						slidesPerView: 8,
						slidesPerGroup: 3,
						loop: true,
						pagination: {
							el: ".swiper-pagination-group-8",
							clickable: true
						},
						autoplay: {
							delay: 10000
						},
						breakpoints: {
							1199: {
								slidesPerView: 8
							},
							800: {
								slidesPerView: 6
							},
							600: {
								slidesPerView: 5
							},
							400: {
								slidesPerView: 4
							},
							350: {
								slidesPerView: 2
							},
							150: {
								slidesPerView: 2
							}
						}
					});
				});
			</script>
		<?php } ?>

		<?php
	}
}
