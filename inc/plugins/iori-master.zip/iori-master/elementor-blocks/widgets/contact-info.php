<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Contact Info
 *
 * Elementor widget for contact info
 *
 * @since 1.0.0
 */
class Contact_Info extends Widget_Base {


	public function get_name() {
		return 'iori-contact-info';
	}

	public function get_title() {
		return esc_html__( 'Contact Info', 'iori' );
	}

	public function get_icon() {
		return 'eicon-info d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'content', 'contact', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'contact_info_section',
			array(
				'label' => esc_html__( 'Contact Info', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'contact_info_img',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'contact_info_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'contact_info_desc',
			array(
				'label'   => __( 'Description', 'iori' ),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => '',
			)
		);


		$this->add_control(
			'contact_info_list',
			array(
				'label'   => __( 'Content Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'contact_info_img'   => '',
						'contact_info_title' => '',
						'contact_info_desc'  => '',
					),
					array(
						'contact_info_img'   => '',
						'contact_info_title' => '',
						'contact_info_desc'  => '',
					),
					array(
						'contact_info_img'   => '',
						'contact_info_title' => '',
						'contact_info_desc'  => '',
					),
				),
			)
		);

		$this->end_controls_section();
		// Content options End

		// =========== Start Style Section ==========

		// title
		$this->start_controls_section(
			'contact_info_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'contact_info_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .title' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'contact_info_title_typography',
				'selector' => '{{WRAPPER}} .card-info .title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'contact_info_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'contact_info_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .desc' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'contact_info_desc_typography',
				'selector' => '{{WRAPPER}} .card-info .desc',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$contact_info_lists = $settings['contact_info_list'];

		?>
		<?php
		foreach ( $contact_info_lists as $contact_info_list ) { 
			?>

			<div class="card-content">
				<div class="wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
					<div class="card-offer card-we-do card-contact hover-up">
						<div class="card-image">
							<img src="<?php echo esc_url( $contact_info_list['contact_info_img']['url'] ); ?>" alt="iori">
						</div>
						<div class="card-info">
							<h6 class="title mb-10"><?php echo esc_html( $contact_info_list['contact_info_title'] ); ?></h6>
							<div class="desc mb-5"><?php echo $contact_info_list['contact_info_desc']; ?></div>
						</div>
					</div>
				</div>
			</div>

			<?php
		} 
		?>

		<?php
	}
}
