<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Team
 *
 * @since 1.0.0
 */

class Login extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-login';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Login', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-person d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'login', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'team_section',
			array(
				'label' => __( 'Login Page', 'iori' ),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => __( 'Section Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Welcome back',
			)
		);

		$this->add_control(
			'desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Fill your email address and password to sign in',
			)
		);

		$this->add_control(
			'img',
			array(
				'label'       => __( 'Section Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'login_msg',
			array(
				'label'       => __( 'Login Message', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Thanks For Login',
			)
		);

		$this->add_control(
			'reg_link',
			array(
				'label'       => __( 'Registration Page Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '/register',
			)
		);


		$this->end_controls_section();

		// start style here

		// title
		$this->start_controls_section(
			'team_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'team_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-login h2' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'team_title_typography',
				'selector' => '{{WRAPPER}} .box-banner-login h2',
				
			)
		);


		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'team_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'team_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-login p' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'team_desc_typography',
				'selector' => '{{WRAPPER}} .box-banner-login p',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();


		if ( is_user_logged_in() ) { ?>
		<section class="section banner-login position-relative float-start">
			<div class="box-banner-abs">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-xxl-5 col-xl-12 col-lg-12">
							<div class="box-banner-login">
								<h2 class="title color-brand-1 mb-15 wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html__( $settings['title'], 'iori' ); ?></h2>
								<p class="font-md color-grey-500 wow animate__animated animate__fadeIn" data-wow-delay=".2s"><?php echo esc_html__( $settings['desc'], 'iori' ); ?></p>
								<div class="line-login mt-25 mb-50"></div>
								<div class="row wow animate__animated animate__fadeIn" data-wow-delay=".4s">
									<h4><?php echo $settings['login_msg']; ?></h4>
									<div class="col-lg-5">
										<div class="form-group mb-25">
											<a class="logged-btn btn btn-brand-lg btn-full font-md-bold" href="<?php echo esc_url( site_url( 'wp-admin' ) ); ?>"><?php echo esc_html__( 'Go To Dashboard', 'iori' ); ?></a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="row m-0">
				<div class="col-xxl-5 col-xl-7 col-lg-6"></div>
				<div class="col-xxl-7 col-xl-5 col-lg-6 pr-0">
					<div class="d-none d-xxl-block pl-70">
						<div class="img-reveal"><img class="w-100 d-block" src="<?php echo $settings['img']['url']; ?>" alt="iori"></div>
					</div>
				</div>
			</div>
		</section>

			<?php
		} else {

			// Check if the user submitted the login form
			if ( isset( $_POST['submit'] ) ) {
				$username = $_POST['log'];
				$password = $_POST['pwd'];

				$credentials = array(
					'log'        => $username,
					'pwd'        => $password,
					'rememberme' => isset( $_POST['remember'] ),
				);

				$user = wp_signon( $credentials );
				if ( is_wp_error( $user ) ) {
					// Display error message
					echo '<div class="error">Invalid username or password.</div>';
				} else {
					// Redirect the user to the homepage or a custom page
					wp_redirect( home_url() );
					exit;
				}
			}
			?>

			<section class="section banner-login position-relative float-start">
				<div class="box-banner-abs">
					<div class="container">
						<div class="row align-items-center">
							<div class="col-xxl-5 col-xl-12 col-lg-12">
								<div class="box-banner-login">
									<h2 class="title color-brand-1 mb-15 wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html__( $settings['title'], 'iori' ); ?></h2>
									<p class="font-md color-grey-500 wow animate__animated animate__fadeIn" data-wow-delay=".2s"><?php echo esc_html__( $settings['desc'], 'iori' ); ?></p>
									<div class="line-login mt-25 mb-50"></div>
									<div class="row wow animate__animated animate__fadeIn" data-wow-delay=".4s">
										<div class="col-lg-12">
											<div class="form-group mb-25">
												<form method="post" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" method="post">
													<div class="row wow animate__ animate__fadeIn animated" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;">
														<div class="col-lg-12">
															<div class="form-group mb-25">
																<input class="form-control icon-user" type="text" name="log" placeholder="Username">
															</div>
														</div>

														<div class="col-lg-12">
															<div class="form-group mb-25">
																<input class="form-control icon-password" type="password" name="pwd" placeholder="Password">
															</div>
														</div>

														<div class="col-lg-6 col-6 mt-15">
															<div class="form-group mb-25">
																<label class="cb-container">
																	<input type="checkbox" name="rememberme" value="forever" checked="checked"><span class="text-small">Remember me</span><span class="checkmark"></span>
																</label>
															</div>
														</div>
														<div class="col-lg-6 col-6 mt-15">
															<div class="form-group mb-25 text-end">
																<a class="font-xs color-grey-500" href="<?php echo esc_url( wp_lostpassword_url() ); ?>" alt="<?php esc_attr_e( 'Lost Password', 'iori' ); ?>">
																	<?php esc_html_e( 'Lost Password', 'iori' ); ?>
																</a>
															</div>
														</div>
														<div class="form-group mb-25">
															<button class="btn btn-brand-lg btn-full font-md-bold" type="submit" name="submit"><?php esc_html_e( 'Sign in', 'iori' ); ?></button>
														</div>
													</div>
												</form>
											</div>
										</div>
										<div class="col-lg-12"><span class="color-grey-500 d-inline-block align-middle font-sm">
												<?php echo esc_html__( 'Don’t have an account?', 'iori' ); ?>
											</span><a class="d-inline-block align-middle color-success ml-3" href="<?php echo $settings['reg_link']; ?>"> <?php echo esc_html_e( 'Sign up now', 'iori' ); ?></a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row m-0">
					<div class="col-xxl-5 col-xl-7 col-lg-6"></div>
					<div class="col-xxl-7 col-xl-5 col-lg-6 pr-0">
						<div class="d-none d-xxl-block pl-70">
							<div class="img-reveal"><img class="w-100 d-block" src="<?php echo $settings['img']['url']; ?>" alt="iori"></div>
						</div>
					</div>
				</div>
			</section>

			<?php
		}
	}
}
