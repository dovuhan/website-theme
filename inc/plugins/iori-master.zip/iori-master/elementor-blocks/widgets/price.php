<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class Price extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-price';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Price', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'price', 'money', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'price_section',
			array(
				'label' => __( 'Price', 'iori' ),
			)
		);

		$this->add_control(
			'price_plan_thumb',
			array(
				'label'       => __( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'price_plan_title',
			array(
				'label'       => __( 'Plan Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'price_plan_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'price_plan_number',
			array(
				'label'       => __( 'Price Number', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'price_plan_duration',
			array(
				'label'       => __( 'Duration', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'price_plan_bill',
			array(
				'label'       => __( 'Price Bill', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);


		$repeater = new Repeater();

		$repeater->add_control(
			'price_plan_item_icon',
			array(
				'label'   => esc_html__( 'Price Icon', 'iori' ),
				'type'    => \Elementor\Controls_Manager::ICON,
				'include' => array(
					'fa fa-facebook',
					'fa fa-flickr',
					'fa fa-google-plus',
					'fa fa-instagram',
					'fa fa-linkedin',
					'fa fa-pinterest',
					'fa fa-reddit',
					'fa fa-twitch',
					'fa fa-twitter',
					'fa fa-vimeo',
					'fa fa-youtube',
				),
				'default' => 'fa fa-facebook',
			)
		);

		$repeater->add_control(
			'price_plan_item_list',
			array(
				'label'   => __( 'Price Items', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'price_plan_lists',
			array(
				'label'   => __( 'Add Price List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'price_plan_item_icon' => '',
						'price_plan_item_list' => '',
					),
					array(
						'price_plan_item_icon' => '',
						'price_plan_item_list' => '',
					),
					array(
						'price_plan_item_icon' => '',
						'price_plan_item_list' => '',
					),
				),
			)
		);

		$this->add_control(
			'price_plan_btn',
			array(
				'label'       => __( 'Button Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'price_plan_btn_link',
			array(
				'label'       => __( 'Button Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);


		$this->end_controls_section();

		// =========== Start Style Section ==========

		// title
		$this->start_controls_section(
			'price_plan_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'price_plan_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .info-plan h4' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_title_typography',
				'selector' => '{{WRAPPER}} .info-plan .font-md',
				
			)
		);

		$this->end_controls_section();

		// subtitle
		$this->start_controls_section(
			'price_plan_subtitle_style',
			array(
				'label' => __( 'Subtitle', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'price_plan_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .color-grey-400' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_subtitle_typography',
				'selector' => '{{WRAPPER}} .info-plan .subtitle',
				
			)
		);

		$this->end_controls_section();

		// price
		$this->start_controls_section(
			'price_plan_price_style',
			array(
				'label' => __( 'Price', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'price_plan_price_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-day-trial .price' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_price_typography',
				'selector' => '{{WRAPPER}} .box-day-trial .price',
				
			)
		);

		$this->end_controls_section();

		// duration
		$this->start_controls_section(
			'price_plan_duration_style',
			array(
				'label' => __( 'Duration', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'price_plan_duration_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-day-trial .duration' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_duration_typography',
				'selector' => '{{WRAPPER}} .box-day-trial .duration',
				
			)
		);

		$this->end_controls_section();

		// bill
		$this->start_controls_section(
			'price_plan_bill_style',
			array(
				'label' => __( 'Price Bill', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'price_plan_bill_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-day-trial .bill' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_bill_typography',
				'selector' => '{{WRAPPER}} .box-day-trial .bill',
				
			)
		);

		$this->end_controls_section();

		// icon
		$this->start_controls_section(
			'price_plan_icon_style',
			array(
				'label' => __( 'Icon', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'price_plan_icon_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-ticks li svg' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_icon_typography',
				'selector' => '{{WRAPPER}} .list-ticks li svg',
				
			)
		);

		$this->end_controls_section();

		// icon content
		$this->start_controls_section(
			'price_plan_icon_content_style',
			array(
				'label' => __( 'Icon Content', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'price_plan_icon_content_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-ticks li' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_icon_content_typography',
				'selector' => '{{WRAPPER}} .list-ticks li',
				
			)
		);

		$this->end_controls_section();

		// button
		$this->start_controls_section(
			'price_plan_btn_style',
			array(
				'label' => __( 'Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'price_plan_btn_styles' );

		$this->start_controls_tab(
			'price_plan_btn_normal',
			array(
				'label' => __( 'Normal', 'iori' ),
			)
		);

		$this->add_control(
			'price_plan_btn_normal_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1-full' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'price_plan_btn_bg_normal_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1-full' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_btn_normal_typography',
				'selector' => '{{WRAPPER}} .btn.btn-brand-1-full',
				
			)
		);

		$this->add_responsive_control(
			'price_plan_btn_normal_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .btn.btn-brand-1-full' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'price_plan_btn_hover',
			array(
				'label' => __( 'Hover', 'iori' ),
			)
		);

		$this->add_control(
			'price_plan_btn_hover_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1-full:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'price_plan_btn_bg_hover_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1-full:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_plan_btn_typography',
				'selector' => '{{WRAPPER}} .btn.btn-brand-1-full:hover',
				
			)
		);

		$this->add_responsive_control(
			'price_plan_btn_hover_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .btn.btn-brand-1-full:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display();

		$price_plan_lists = $settings['price_plan_lists'];

		?>
		<section class="section bg-plan">
			<div class="card-plan hover-up">
				<div class="card-image-plan">
					<div class="icon-plan"><img src="<?php echo $settings['price_plan_thumb']['url']; ?>" alt="iori"></div>
					<div class="info-plan">
						<h4 class="color-brand-1 my-0"><?php echo esc_html( $settings['price_plan_title'] ); ?></h4>
						<p class="subtitle color-grey-400 mb-0"><?php echo esc_html( $settings['price_plan_subtitle'] ); ?></p>
					</div>
				</div>
				<div class="box-day-trial">
					<span class="price color-brand-1"><?php echo esc_html( $settings['price_plan_number'] ); ?></span>
					<span class="duration"><?php echo esc_html( $settings['price_plan_duration'] ); ?></span><br>
					<span class="bill"><?php echo esc_html( $settings['price_plan_bill'] ); ?></span>
				</div>
				<div class="mt-30 mb-30">
					<ul class="list-ticks list-ticks-2">

						<?php
						foreach ( $price_plan_lists as $price_plan_list ) { 
							?>

							<li class="d-flex">
								<svg class="w-6 h-6 icon-16 <?php echo esc_attr( $price_plan_list['price_plan_item_icon'] ); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
								</svg>
								<?php echo $price_plan_list['price_plan_item_list']; ?>
							</li>

							<?php
						} 
						?>

					</ul>
				</div>
				<div class="mt-20">
					<a class="btn btn-brand-1-full hover-up" href="<?php echo esc_url( $settings['price_plan_btn_link'] ); ?>"><?php echo esc_html( $settings['price_plan_btn'] ); ?>
						<svg class="w-6 h-6 icon-16 ml-10" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
						</svg>
					</a>
				</div>
			</div>
		</section>

		<?php
	}
}
