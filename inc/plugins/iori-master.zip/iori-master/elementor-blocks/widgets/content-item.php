<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Content
 *
 * Elementor widget for Content
 *
 * @since 1.0.0
 */
class Content_Item extends Widget_Base {


	public function get_name() {
		return 'iori-content-item';
	}

	public function get_title() {
		return esc_html__( 'Content Item', 'iori' );
	}

	public function get_icon() {
		return 'eicon-post-content d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'content', 'item', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'content_item_section',
			array(
				'label' => esc_html__( 'Content Item', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'content_item_icon',
			array(
				'label'   => esc_html__( 'Content Icon', 'iori' ),
				'type'    => \Elementor\Controls_Manager::ICON,
				'include' => array(
					'fa fa-facebook',
					'fa fa-flickr',
					'fa fa-google-plus',
					'fa fa-instagram',
					'fa fa-linkedin',
					'fa fa-pinterest',
					'fa fa-reddit',
					'fa fa-twitch',
					'fa fa-twitter',
					'fa fa-vimeo',
					'fa fa-youtube',
				),
				'default' => 'fa fa-facebook',
			)
		);

		$repeater->add_control(
			'content_item_text',
			array(
				'label'   => __( 'Content Text', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'content_item_list',
			array(
				'label'   => __( 'Content Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'content_item_icon' => '',
						'content_item_text' => '',
					),
					array(
						'content_item_icon' => '',
						'content_item_text' => '',
					),
					array(
						'content_item_icon' => '',
						'content_item_text' => '',
					),
				),
			)
		);

		$this->end_controls_section();
		// Content options End

		// =========== Start Style Section ==========

		// icons
		$this->start_controls_section(
			'content_icon_style',
			array(
				'label' => __( 'Icon', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_icon_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-ticks li svg' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_icon_typography',
				'selector' => '{{WRAPPER}} .list-ticks li svg',
				
			)
		);

		$this->end_controls_section();


		// icons content
		$this->start_controls_section(
			'content_icon_text_style',
			array(
				'label' => __( 'Icon Text', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_icon_text_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-ticks li' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_icon_text_typography',
				'selector' => '{{WRAPPER}} .list-ticks li',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$content_item_lists = $settings['content_item_list'];

		?>

		<div class="project-revert">
			<div class="mt-20 wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
				<ul class="list-ticks mb-0">

					<?php
					foreach ( $content_item_lists as $content_item_list ) { 
						?>

						<li>
							<svg class="w-6 h-6 icon-16 <?php echo esc_attr( $content_item_list['content_item_icon'] ); ?>" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
								<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
							</svg>
							<?php echo $content_item_list['content_item_text']; ?>
						</li>

						<?php
					} 
					?>

				</ul>
			</div>
		</div>

		<?php
	}
}
