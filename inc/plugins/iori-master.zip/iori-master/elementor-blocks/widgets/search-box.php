<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Search Box
 *
 * Elementor widget for Search Box
 *
 * @since 1.0.0
 */
class Search_Box extends Widget_Base {


	public function get_name() {
		return 'iori-search-box';
	}

	public function get_title() {
		return esc_html__( 'Search Box', 'iori' );
	}

	public function get_icon() {
		return 'eicon-search d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'search', 'box', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'search_box_section',
			array(
				'label' => esc_html__( 'Search Box', 'iori' ),
			)
		);

		$this->add_control(
			'search_box_btn_text',
			array(
				'label'       => __( 'Button Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
				'label_block' => true,
			)
		);

		$this->end_controls_section();
		// Content options End

		// =========== Start Style Section ==========

		// search box style
		$this->start_controls_section(
			'search_box_style',
			array(
				'label' => __( 'Search Box Style', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'search_box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .inner-notify-me' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .inner-notify-me',
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'content_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .inner-notify-me .btn-brand-1' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_title_typography',
				'selector' => '{{WRAPPER}} .inner-notify-me .btn-brand-1',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
		<div class="box-notify-me">
			<div class="inner-notify-me">
				<input class="form-control" type="text" placeholder="Search the doc ..">
				<button class="btn btn-brand-1"><?php echo esc_html( $settings['search_box_btn_text'] ); ?>
					<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
					</svg>
				</button>
			</div>
		</div>

		<?php
	}
}
