<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Tabs Three
 *
 * @since 1.0.0
 */

class Tabs_Three extends Widget_Base {


	public function get_name() {
		return 'tabs-three';
	}

	public function get_title() {
		return 'Tabs Three';
	}

	public function get_icon() {
		return 'eicon-tabs d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'tabs', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/
	// public function get_script_depends() {
	// return [ 'section-header' ];
	// }

	protected function register_controls() {

		// ========= Start Content Section=========

		$this->start_controls_section(
			'tabs_three_section',
			array(
				'label' => 'Tabs Three',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'tabs_three_tab_title',
			array(
				'label'       => 'Tab Title',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'tabs_three_image',
			array(
				'label'       => 'Upload Image',
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'tabs_three_cat',
			array(
				'label'       => __( 'Category Text ', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'tabs_three_title',
			array(
				'label'       => 'Title',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'tabs_three_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'tabs_three_list_items',
			array(
				'label'       => __( 'List Items', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			)
		);

		$this->add_control(
			'tabs_three_lists',
			array(
				'label'   => __( 'Tabs Three Item', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'tabs_three_tab_title' => '',
						'tabs_three_image'     => '',
						'tabs_three_cat'       => '',
						'tabs_three_title'     => '',
						'tabs_three_desc'      => '',
					),
					array(
						'tabs_three_tab_title' => '',
						'tabs_three_image'     => '',
						'tabs_three_cat'       => '',
						'tabs_three_title'     => '',
						'tabs_three_desc'      => '',
					),
					array(
						'tabs_three_tab_title' => '',
						'tabs_three_image'     => '',
						'tabs_three_cat'       => '',
						'tabs_three_title'     => '',
						'tabs_three_desc'      => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// button text style
		$this->start_controls_section(
			'tabs_three_btn_text_style',
			array(
				'label' => __( 'Button Text', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_three_btn_text_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-buttons-circle li a' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_three_btn_text_typography',
				'selector' => '{{WRAPPER}} .list-buttons-circle li a',
				
			)
		);

		$this->end_controls_section();

		// category text style
		$this->start_controls_section(
			'tabs_three_cat_text_style',
			array(
				'label' => __( 'Category', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_three_cat_text_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-business-tab .btn.btn-tag' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_control(
			'tabs_three_cat_text_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-business-tab .btn.btn-tag' => 'background-color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_three_cat_text_typography',
				'selector' => '{{WRAPPER}} .box-business-tab .btn.btn-tag',
				
			)
		);

		$this->end_controls_section();

		// title style
		$this->start_controls_section(
			'tabs_three_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_three_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-business-tab .title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_three_title_typography',
				'selector' => '{{WRAPPER}} .box-business-tab .title',
				
			)
		);

		$this->end_controls_section();

		// description style
		$this->start_controls_section(
			'tabs_three_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_three_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-business-tab .desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_three_desc_typography',
				'selector' => '{{WRAPPER}} .box-business-tab .desc',
				
			)
		);

		$this->end_controls_section();

		// item list style
		$this->start_controls_section(
			'tabs_three_item_list_style',
			array(
				'label' => __( 'Item Lists', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_three_item_list_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-ticks li' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_three_item_list_typography',
				'selector' => '{{WRAPPER}} .list-ticks li',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$tab_titles = array_map(
			function ( $tabs_three_list ) {
				return $tabs_three_list['tabs_three_tab_title'];
			},
			$settings['tabs_three_lists']
		);

		$unique_tab_titles = array_unique( $tab_titles );

		?>
		<ul class="list-buttons list-buttons-circle nav nav-tabs" role="tablist">
			<?php foreach ( $settings['tabs_three_lists'] as $index => $tabs_three_list ) : ?>
				<li class="wow animate__animated animate__fadeIn" data-wow-delay=".<?php echo $index; ?>s">
					<a class="<?php echo ( $index === 0 ) ? 'active' : ''; ?>" href="#tab-<?php echo $index; ?>" data-bs-toggle="tab" role="tab" aria-controls="tab-<?php echo $index; ?>" aria-selected="<?php echo ( $index === 0 ) ? 'true' : 'false'; ?>">
						<?php echo $unique_tab_titles[ $index ]; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>

		<div class="tab-content wow animate__animated animate__fadeIn" data-wow-delay=".0s">
			<?php foreach ( $settings['tabs_three_lists'] as $index => $tabs_three_list ) : ?>
				<div class="tab-pane fade <?php echo ( $index === 0 ) ? 'active show' : ''; ?>" id="tab-<?php echo $index; ?>" role="tabpanel" aria-labelledby="tab-<?php echo $index; ?>">
					<div class="box-tab-32">
						<div class="row align-items-center">
							<div class="col-xl-6 col-lg-5">
								<img class="bd-rd16" src="<?php echo $tabs_three_list['tabs_three_image']['url']; ?>" alt="iori">
							</div>
							<div class="col-xl-6 col-lg-7">
								<div class="box-business-tab">
									<span class="btn btn-tag category"><?php echo esc_html( $tabs_three_list['tabs_three_cat'] ); ?></span>
									<h3 class="title mt-10 mb-15">
										<?php echo esc_html( $tabs_three_list['tabs_three_title'] ); ?>
									</h3>
									<div class="desc">
										<?php echo $tabs_three_list['tabs_three_desc']; ?>
									</div>
									<div class="mt-20">
										<ul class="list-ticks">
											<?php echo $tabs_three_list['tabs_three_list_items']; ?>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<?php

	}
}
