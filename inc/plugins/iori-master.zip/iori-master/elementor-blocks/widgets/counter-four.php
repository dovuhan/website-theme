<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for counter four
 *
 * @since 1.0.0
 */

class Counter_Four extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-counter-four';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Counter Four', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'counter', 'count', 'four', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'counter_four_section',
			array(
				'label' => __( 'Counter Four', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'counter_four_img',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'counter_four_number',
			array(
				'label'   => __( 'Number', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '',
			)
		);

		$repeater->add_control(
			'counter_four_quantity',
			array(
				'label'   => __( 'Quantity', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'counter_four_subject',
			array(
				'label'   => __( 'Subject', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'counter_four_list',
			array(
				'label'   => __( 'Counter List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'counter_four_img'      => '',
						'counter_four_number'   => '',
						'counter_four_quantity' => '',
						'counter_four_subject'  => '',
					),
					array(
						'counter_four_img'      => '',
						'counter_four_number'   => '',
						'counter_four_quantity' => '',
						'counter_four_subject'  => '',
					),
					array(
						'counter_four_img'      => '',
						'counter_four_number'   => '',
						'counter_four_quantity' => '',
						'counter_four_subject'  => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// content style start 

		// number
		$this->start_controls_section(
			'counter_four_number_style',
			array(
				'label' => __( 'Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_four_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .counter_number_content .count' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_four_number_typography',
				'selector' => '{{WRAPPER}} .counter_number_content .count',
				
			)
		);

		$this->end_controls_section();


		// quantity
		$this->start_controls_section(
			'counter_four_quantity_style',
			array(
				'label' => __( 'Quantity', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_four_quantity_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .counter_number_content .quantity' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_four_quantity_typography',
				'selector' => '{{WRAPPER}} .counter_number_content .quantity',
				
			)
		);

		$this->end_controls_section();

		// subject
		$this->start_controls_section(
			'counter_four_subject_style',
			array(
				'label' => __( 'Subject', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_four_subject_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subject' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_four_subject_typography',
				'selector' => '{{WRAPPER}} .subject',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$counter_four_lists = $settings['counter_four_list'];

		?>
		<div class="counter-four text-center">
			<div class="box-radius-border">
				<div class="box-list-numbers">
					<?php
					foreach ( $counter_four_lists as $counter_four_list ) { 
						?>
						<div class="item-list-number">
							<div class="box-image-bg">
								<img src="<?php echo esc_url( $counter_four_list['counter_four_img']['url'] ); ?>" alt="iori">
							</div>
							<h2 class="counter_number_content">
								<span class="count"><?php echo esc_html( $counter_four_list['counter_four_number'] ); ?></span>
								<span class="quantity"><?php echo esc_html( $counter_four_list['counter_four_quantity'] ); ?></span>
							</h2>
							<p class="subject"><?php echo esc_html( $counter_four_list['counter_four_subject'] ); ?></p>
						</div>
						<?php
					} 
					?>
				</div>
			</div>
		</div>

		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				/*---- CounterUp ----*/
				if (jQuery(".count").length) {
					jQuery(".count").counterUp({
						delay: 10,
						time: 600
					});
				}
			</script>
		<?php } ?>

		<?php
	}
}
