<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Team
 *
 * @since 1.0.0
 */

class Team extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-team';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-person d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'team', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'team_section',
			array(
				'label' => __( 'Team', 'iori' ),
			)
		);

		$this->add_control(
			'team_img',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'team_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'team_title_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'team_author_designation',
			array(
				'label'       => __( 'Designation', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'team_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'team_social_icons',
			array(
				'label'            => esc_html__( 'Select Icons', 'iori' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => array(
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				),
			)
		);

		$repeater->add_control(
			'team_social_icons_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'team_social_icon_list',
			array(
				'label'   => __( 'Icons List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'team_social_icons'      => '',
						'team_social_icons_link' => '',
					),
					array(
						'team_social_icons'      => '',
						'team_social_icons_link' => '',
					),
					array(
						'team_social_icons'      => '',
						'team_social_icons_link' => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// start style here

		// title
		$this->start_controls_section(
			'team_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'team_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team_content_box .team_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'team_title_typography',
				'selector' => '{{WRAPPER}} .team_content_box .team_title',
				
			)
		);

		$this->end_controls_section();

		// designation
		$this->start_controls_section(
			'team_designation_style',
			array(
				'label' => __( 'Designation', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'team_designation_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team_content_box .team_designation' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'team_designation_typography',
				'selector' => '{{WRAPPER}} .team_content_box .team_designation',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'team_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'team_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team_content_box .team_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'team_desc_typography',
				'selector' => '{{WRAPPER}} .team_content_box .team_desc',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$team_social_icon_lists = $settings['team_social_icon_list'];

		?>
		<section class="section">
			<div class="team_content_box wow animate__animated animate__fadeIn" data-wow-delay=".s">
				<div class="card-team mb-30">
					<div class="card-image">
						<img src="<?php echo esc_url( $settings['team_img']['url'] ); ?>" alt="iori">
					</div>
					<div class="card-info">
						<a class="team_title" href="<?php echo esc_url( $settings['team_title_link'] ); ?>"><?php echo esc_html( $settings['team_title'] ); ?></a>
						<div class="team_designation mb-10"><?php echo esc_html( $settings['team_author_designation'] ); ?></div>
						<div class="team_desc"><?php echo $settings['team_desc']; ?></div>
						<div class="list-socials">

							<?php
							foreach ( $team_social_icon_lists as $team_social_icon_list ) {
								
								$icon = $team_social_icon_list['team_social_icons'];
								if ( is_array( $icon['value'] ) ) {
									if ( isset( $team_social_icon_list['team_social_icons_link'] ) ) {
										echo '<a href="' . esc_url( $team_social_icon_list['team_social_icons_link'] ) . '" class="icon-socials"><img src="' . $icon['value']['url'] . '" /></a>';
									} else {
										// Handle case when "team_social_icons_link" is not defined
										echo '<a href="#" class="icon-socials"><img src="' . $icon['value']['url'] . '" /></a>';
									}
								} else {
									?>
									<a href="<?php echo isset( $team_social_icon_list['team_social_icons_link'] ) ? esc_url( $team_social_icon_list['team_social_icons_link'] ) : '#'; ?>" class="icon-socials <?php echo $icon['value']; ?>"></a>
									<?php
								}
							}
							?>

						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
