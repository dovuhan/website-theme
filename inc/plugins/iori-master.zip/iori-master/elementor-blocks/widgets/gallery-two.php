<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Gallery Two
 *
 * Elementor widget for gallery
 *
 * @since 1.0.0
 */
class Gallery_Two extends Widget_Base {


	public function get_name() {
		return 'iori-gallery-two';
	}

	public function get_title() {
		return esc_html__( 'Gallery Two', 'iori' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'gallery', 'image', 'picture', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'gallery_two_section',
			array(
				'label' => esc_html__( 'Gallery Two', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_two_main_img',
			array(
				'label'   => esc_html__( 'Main Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'gallery_two_left_img',
			array(
				'label'   => esc_html__( 'Image Left', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'gallery_two_count_number',
			array(
				'label'       => __( 'Number', 'iori' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_two_count_quantity',
			array(
				'label'       => __( 'Quantity', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_two_count_subject',
			array(
				'label'       => __( 'Subject', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->end_controls_section();

		// start style here

		// number
		$this->start_controls_section(
			'gallery_two_number_style',
			array(
				'label' => __( 'Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_two_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-business .count' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_two_number_typography',
				'selector' => '{{WRAPPER}} .box-number-business .count',
				
			)
		);

		$this->end_controls_section();

		// quantity
		$this->start_controls_section(
			'gallery_two_quantity_style',
			array(
				'label' => __( 'Quantity', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_two_quantity_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-business .quantity' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_two_quantity_typography',
				'selector' => '{{WRAPPER}} .box-number-business .quantity',
				
			)
		);

		$this->end_controls_section();

		// subject
		$this->start_controls_section(
			'gallery_two_subject_style',
			array(
				'label' => __( 'Subject', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_two_subject_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-business .subject' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_two_subject_typography',
				'selector' => '{{WRAPPER}} .box-number-business .subject',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="position-relative mb-30">
			<img src="<?php echo $settings['gallery_two_main_img']['url']; ?>" alt="iori">
			<div class="shape-1 box-image-4">
				<img src="<?php echo $settings['gallery_two_left_img']['url']; ?>" alt="iori">
			</div>
			<div class="box-number-business shape-3">
				<div class="cardNumber bg-white">
					<h3>
						<span class="count"><?php echo esc_html( $settings['gallery_two_count_number'] ); ?></span>
						<span class="quantity"><?php echo esc_html( $settings['gallery_two_count_quantity'] ); ?></span>
					</h3>
					<p class="subject"><?php echo esc_html( $settings['gallery_two_count_subject'] ); ?></p>
				</div>
			</div>
		</div>

		<?php
	}
}
