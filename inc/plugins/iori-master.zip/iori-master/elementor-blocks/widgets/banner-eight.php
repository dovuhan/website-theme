<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner Eight
 *
 * Elementor widget for banner eight
 *
 * @since 1.0.0
 */
class Banner_Eight extends Widget_Base {


	public function get_name() {
		return 'iori-banner-eight';
	}

	public function get_title() {
		return esc_html__( 'Banner Eight', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-eight', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_eight_section',
			array(
				'label' => __( 'Banner Eight', 'iori' ),
			)
		);

		$this->add_control(
			'banner_eight_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_eight_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_eight_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_eight_video_text',
			array(
				'label'       => __( 'Video Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => __( 'Play Video', 'iori' ),
				'default'     => __( 'Play Video', 'iori' ),
			)
		);

		$this->add_control(
			'banner_eight_video_link',
			array(
				'label'       => __( 'Video Link', 'iori' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => array(
					'active' => true,
				),
				'placeholder' => __( 'https://your-link.com', 'iori' ),
				'separator'   => 'after',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'banner_eight_author_thumb',
			array(
				'label'   => esc_html__( 'Upload Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'banner_eight_item_list',
			array(
				'label'   => __( 'Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'banner_eight_author_thumb' => '',
					),
					array(
						'banner_eight_author_thumb' => '',
					),
					array(
						'banner_eight_author_thumb' => '',
					),
				),
			)
		);

		$this->add_control(
			'banner_eight_item_author_number',
			array(
				'label'       => __( 'Author Number', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_eight_user_text',
			array(
				'label'       => __( 'User Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_eight_user_platform',
			array(
				'label'       => __( 'User Platform', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_eight_user_platform_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_eight_bottom_thumb',
			array(
				'label'   => esc_html__( 'Banner Botom Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		// banner tickets option
		$repeater->add_control(
			'banner_eight_ticket_box_thumb',
			array(
				'label'     => esc_html__( 'Upload Image', 'iori' ),
				'type'      => Controls_Manager::MEDIA,
				'separator' => 'before',
			)
		);

		$repeater->add_control(
			'banner_eight_ticket_box_text',
			array(
				'label'       => __( 'Box Item Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_eight_ticket_box_item_list',
			array(
				'label'   => __( 'Ticket Box Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'banner_eight_ticket_box_thumb' => '',
						'banner_eight_ticket_box_text'  => '',
					),
					array(
						'banner_eight_ticket_box_thumb' => '',
						'banner_eight_ticket_box_text'  => '',
					),
					array(
						'banner_eight_ticket_box_thumb' => '',
						'banner_eight_ticket_box_text'  => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// content style

		// subtitle
		$this->start_controls_section(
			'banner_eight_subtitle_style',
			array(
				'label' => __( 'Subtitle', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_eight_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-home9 .banner_eight_subtitle' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_eight_subtitle_typography',
				'selector' => '{{WRAPPER}} .box-banner-home9 .banner_eight_subtitle',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'banner_eight_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_eight_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-home9 .banner_eight_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_eight_title_typography',
				'selector' => '{{WRAPPER}} .box-banner-home9 .banner_eight_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_eight_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_eight_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-banner-home9 .banner_eight_desc' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_eight_desc_typography',
				'selector' => '{{WRAPPER}} .box-banner-home9 .banner_eight_desc',
				
			)
		);

		$this->end_controls_section();

		// box ticket
		$this->start_controls_section(
			'banner_eight_box_ticket_style',
			array(
				'label' => __( 'Box Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_eight_box_ticket_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-ticks .item-tick' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_eight_box_ticket_typography',
				'selector' => '{{WRAPPER}} .box-ticks .item-tick',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$banner_eight_item_lists            = $settings['banner_eight_item_list'];
		$banner_eight_ticket_box_item_lists = $settings['banner_eight_ticket_box_item_list'];

		?>

		<section class="section banner-9">
			<div class="box-banner-home9">
				<div class="container position-relative">
					<div class="row align-items-center">
						<div class="col-lg-7 mb-30">
							<span class="banner_eight_subtitle title-line line-48 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['banner_eight_subtitle'] ); ?></span>
							<h2 class="banner_eight_title mb-15 mt-0 wow animate__animated animate__fadeInUp" data-wow-delay=".2s"><?php echo wpautop( $settings['banner_eight_title'] ); ?></h2>
							<div class="banner_eight_desc mb-20 wow animate__animated animate__fadeInUp" data-wow-delay=".4s"><?php echo $settings['banner_eight_desc']; ?></div>
							<div class="mt-10 wow animate__animated animate__fadeInUp" data-wow-delay=".6s"><a class="btn btn-play btn-play-white font-sm-bold popup-youtube" href="<?php echo esc_url( $settings['banner_eight_video_link']['url'] ); ?>"><?php echo esc_html( $settings['banner_eight_video_text'] ); ?></a></div>
						</div>
						<div class="col-lg-5 mb-30 wow animate__animated animate__fadeInLeft" data-wow-delay=".0s">
							<div class="box-joined wow animate__animated animate__fadeInUp" data-wow-delay=".4s">
								<div class="box-authors">

									<?php
									foreach ( $banner_eight_item_lists as $banner_eight_item_list ) { 
										?>

										<span class="item-author">
											<img src="<?php echo $banner_eight_item_list['banner_eight_author_thumb']['url']; ?>" alt="iori">
										</span>

										<?php
									} 
									?>

									<span class="item-author">
										<span class="text-num-author font-md-bold color-brand-1"><?php echo esc_html( $settings['banner_eight_item_author_number'] ); ?></span>
									</span>
								</div>
								<span class="join-thousands font-sm color-grey-400 d-inline-block"><?php echo esc_html( $settings['banner_eight_user_text'] ); ?>
									<a class="font-sm-bold color-brand-1" href="<?php echo esc_html( $settings['banner_eight_user_platform_link'] ); ?>"><?php echo esc_html( $settings['banner_eight_user_platform'] ); ?></a>
								</span>
							</div>
						</div>
					</div>
					<div class="box-image-banner-9 wow animate__animated animate__fadeIn">
						<img src="<?php echo $settings['banner_eight_bottom_thumb']['url']; ?>" alt="iori">
					</div>
					<div class="box-ticks">
						<div class="row">
							<?php
							foreach ( $banner_eight_ticket_box_item_lists as $banner_eight_ticket_box_item_list ) { 
								?>
								<div class="col-lg-4 mb-20 wow animate__animated animate__fadeIn" data-wow-delay=".0s">
									<span class="item-tick" style="background-image: url('<?php echo esc_url( $banner_eight_ticket_box_item_list['banner_eight_ticket_box_thumb']['url'] ); ?>');"><?php echo esc_html( $banner_eight_ticket_box_item_list['banner_eight_ticket_box_text'] ); ?></span>
								</div>
								<?php
							} 
							?>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
