<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Card Four
 *
 * @since 1.0.0
 */

class Card_Four extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-card-four';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Card Four', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-menu-card d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'card-four', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'card_four_section',
			array(
				'label' => __( 'Card Four', 'iori' ),
			)
		);

		$this->add_control(
			'card_four_top_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'card_four_img',
			array(
				'label'   => esc_html__( 'Upload Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$repeater->add_control(
			'card_four_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$repeater->add_control(
			'card_four_title_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$repeater->add_control(
			'card_four_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'card_four_btn',
			array(
				'label'       => __( 'Button Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$repeater->add_control(
			'card_four_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'card_four_item_list',
			array(
				'label'   => __( 'Card Four List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'card_four_img'        => '',
						'card_four_title'      => '',
						'card_four_title_link' => '',
						'card_four_desc'       => '',
						'card_four_btn'        => '',
						'card_four_btn_link'   => '',
					),
					array(
						'card_four_img'        => '',
						'card_four_title'      => '',
						'card_four_title_link' => '',
						'card_four_desc'       => '',
						'card_four_btn'        => '',
						'card_four_btn_link'   => '',
					),
					array(
						'card_four_img'        => '',
						'card_four_title'      => '',
						'card_four_title_link' => '',
						'card_four_desc'       => '',
						'card_four_btn'        => '',
						'card_four_btn_link'   => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// start style here

		// top title
		$this->start_controls_section(
			'card_four_top_title_style',
			array(
				'label' => __( 'Top Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_four_top_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card_four .card_four_top_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'card_four_top_title_typography',
				'selector'  => '{{WRAPPER}} .card_four .card_four_top_title',
				'separator' => 'after',
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'card_four_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_four_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card_four .card_four_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_four_title_typography',
				'selector' => '{{WRAPPER}} .card_four .card_four_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'card_four_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_four_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card_four .card_four_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_four_desc_typography',
				'selector' => '{{WRAPPER}} .card_four .card_four_desc',
				
			)
		);

		$this->end_controls_section();


		// button
		$this->start_controls_section(
			'card_four_btn_style',
			array(
				'label' => __( 'Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_four_btn_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card_four .card_four_btn' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_four_btn_typography',
				'selector' => '{{WRAPPER}} .card_four .card_four_btn',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$card_four_item_lists = $settings['card_four_item_list'];

		?>

		<section class="section card_four">
			<div class="container">
				<div class="box-radius-16 bg-4">
					<div class="row justify-content-center">
						<div class="col-lg-10 text-center">
							<h2 class="card_four_top_title mb-20 wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html( $settings['card_four_top_title'] ); ?></h2>
						</div>
					</div>
					<div class="row mt-50">

						<?php
						foreach ( $card_four_item_lists as $card_four_item_list ) { 
							?>

							<div class="col-lg-6 col-md-12 wow animate__animated animate__fadeIn" data-wow-delay=".0s">
								<div class="card-offer card-we-do card-marketing hover-up">
									<div class="card-image">
										<span class="cover-image">
											<img src="<?php echo $card_four_item_list['card_four_img']['url']; ?>" alt="iori">
										</span>
									</div>
									<div class="card-info">
										<h4 class="card_four_title mt-0 mb-10"><a class="card_four_title" href="<?php echo esc_html( $card_four_item_list['card_four_title_link'] ); ?>"><?php echo esc_html( $card_four_item_list['card_four_title'] ); ?></a></h4>
										<div class="card_four_desc mb-5">
											<?php echo $card_four_item_list['card_four_desc']; ?>
										</div>
										<div class="box-button-offer">
											<a href="<?php echo esc_html( $card_four_item_list['card_four_btn_link'] ); ?>" class="card_four_btn btn btn-default pl-0">
												<?php echo esc_html( $card_four_item_list['card_four_btn'] ); ?>
												<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
												</svg>
											</a>
										</div>
									</div>
								</div>
							</div>


							<?php
						} 
						?>


					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
