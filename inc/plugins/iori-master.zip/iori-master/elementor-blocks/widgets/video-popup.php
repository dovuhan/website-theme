<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class Video_Popup extends Widget_Base {


	public function get_name() {
		return 'iori-video-popup';
	}

	public function get_title() {
		return 'Video Popup';
	}

	public function get_icon() {
		return 'eicon-video-playlist d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'video', 'popup', 'video-popup' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.0
	 **/
	protected function register_controls() {
		// ========= Start Content Section =========

		$this->start_controls_section(
			'video_popup_section',
			array(
				'label' => esc_html__( 'Video Popup', 'iori' ),
			)
		);

		$this->add_control(
			'show_icon',
			array(
				'label'       => __( 'Text/Icon', 'iori' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'Yes',
				'label_on'    => 'Text',
				'label_off'   => 'Icon',
				'label_block' => false,
			)
		);

		$this->add_control(
			'video_text',
			array(
				'label'       => __( 'Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => __( 'Play Video', 'iori' ),
				'default'     => __( 'Play Video', 'iori' ),
				'condition'   => array(
					'show_icon' => 'yes',
				),
			)
		);

		$this->add_control(
			'selected_icon',
			array(
				'label'            => __( 'Icon', 'iori' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'condition'        => array(
					'show_icon!' => 'yes',
				),
				'default'          => array(
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				),
			)
		);

		$this->add_control(
			'video_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => array(
					'active' => true,
				),
				'placeholder' => __( 'https://your-link.com', 'iori' ),
			)
		);

		$this->end_controls_section();

		// ===========Start Style Section==========

		$this->start_controls_section(
			'button_styles',
			array(
				'label' => esc_html__( 'Video Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'button_width',
			array(
				'label'     => __( 'Width', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'unit' => 'px',
				),
				'range'     => array(
					'%' => array(
						'min' => 10,
						'max' => 150,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .btn' => 'width: {{SIZE}}{{UNIT}}',
				),

			)
		);

		$this->add_control(
			'button_height',
			array(
				'label'     => __( 'Height', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'unit' => 'px',
				),
				'range'     => array(
					'%' => array(
						'min' => 10,
						'max' => 150,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .btn' => 'height: {{SIZE}}{{UNIT}}',
				),

			)
		);

		$this->add_control(
			'border_radius',
			array(
				'label'      => __( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .btn' => 'overflow: hidden;border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),

			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => 'title_typography',
				'default'        => array(
					'font_family' => 'Rajdhani',
				),
				'fields_options' => array(

					'font_family' => array(
						'default' => 'Rajdhani',
					),
				),
				'selector'       => '{{WRAPPER}} .btn',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the html.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="box-button-video wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
			<a class="btn btn-play font-sm-bold popup-youtube hover-up" href="<?php echo esc_url( $settings['video_link']['url'] ); ?>"><?php echo esc_html( $settings['video_text'] ); ?></a>
		</div>

		<?php

	}
}
