<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Gallery Five
 *
 * Elementor widget for gallery
 *
 * @since 1.0.0
 */
class Gallery_Five extends Widget_Base {


	public function get_name() {
		return 'iori-gallery-five';
	}

	public function get_title() {
		return esc_html__( 'Gallery Five', 'iori' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'gallery', 'image', 'picture', 'five', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'gallery_five_section',
			array(
				'label' => esc_html__( 'Gallery Five', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_five_img_one',
			array(
				'label'       => esc_html__( 'Image One', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'gallery_five_img_two',
			array(
				'label'       => esc_html__( 'Image Two', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'gallery_five_img_three',
			array(
				'label'       => esc_html__( 'Image Three', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'gallery_five_img_four',
			array(
				'label'       => esc_html__( 'Image Four', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'gallery_five_img_five',
			array(
				'label'       => esc_html__( 'Image Five', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'gallery_five_img_six',
			array(
				'label'       => esc_html__( 'Image Six', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$gallery_img_one   = $settings['gallery_five_img_one']['url'];
		$gallery_img_two   = $settings['gallery_five_img_two']['url'];
		$gallery_img_three = $settings['gallery_five_img_three']['url'];
		$gallery_img_four  = $settings['gallery_five_img_four']['url'];
		$gallery_img_five  = $settings['gallery_five_img_five']['url'];
		$gallery_img_six   = $settings['gallery_five_img_six']['url'];

		?>

		<div class="box-banner-team">
			<div class="arrow-down-banner shape-1"></div>
			<div class="arrow-right-banner shape-2"></div>
			<div class="banner-col-1">
				<div class="img-banner wow animate__animated animate__zoomIn" data-wow-delay=".0s"><img src="<?php echo esc_url( $gallery_img_one ); ?>" alt="iori"></div>
			</div>
			<div class="banner-col-2">
				<div class="img-banner wow animate__animated animate__zoomIn" data-wow-delay=".2s"><img src="<?php echo esc_url( $gallery_img_two ); ?>" alt="iori"></div>
				<div class="img-banner hasBorder wow animate__animated animate__zoomIn" data-wow-delay=".4s"><img src="<?php echo esc_url( $gallery_img_three ); ?>" alt="iori"></div>
			</div>
			<div class="banner-col-3">
				<div class="img-banner hasBorder2 wow animate__animated animate__zoomIn" data-wow-delay=".6s"><img src="<?php echo esc_url( $gallery_img_four ); ?>" alt="iori"></div>
				<div class="img-banner wow animate__animated animate__zoomIn" data-wow-delay=".8s"><img src="<?php echo esc_url( $gallery_img_five ); ?>" alt="iori"></div>
				<div class="img-banner wow animate__animated animate__zoomIn" data-wow-delay="1s"><img src="<?php echo esc_url( $gallery_img_six ); ?>" alt="iori"></div>
			</div>
		</div>


		<?php
	}
}
