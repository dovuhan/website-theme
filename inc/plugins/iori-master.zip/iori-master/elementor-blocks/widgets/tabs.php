<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor tabs
 *
 * Elementor widget for tabs
 *
 * @since 1.0.0
 */
class Tabs extends Widget_Base {


	public function get_name() {
		return 'iori-tabs';
	}

	public function get_title() {
		return esc_html__( 'Tabs', 'iori' );
	}

	public function get_icon() {
		return 'eicon-tabs d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'tabs', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'tabs_section',
			array(
				'label' => esc_html__( 'Tabs', 'iori' ),
			)
		);

		$this->add_control(
			'tabs_top_title',
			array(
				'label'       => 'Top Title',
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'tab_name',
			array(
				'label'       => 'Tab Name',
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Tab',
				'label_block' => true,
			)
		);

		$this->add_control(
			'iori_tabs',
			array(
				'label'       => 'Tabs',
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ tab_name }}}',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'iori_section_cards',
			array(
				'label' => 'Cards',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'card_type',
			array(
				'label'   => 'Card Type',
				'type'    => Controls_Manager::SELECT,
				'default' => 'personal',
				'options' => array(
					'personal'   => 'personal',
					'enterprise' => 'enterprise',
				),
			)
		);

		$repeater->add_control(
			'card_animation_delay',
			array(
				'label'   => 'Animation Delay (seconds)',
				'type'    => Controls_Manager::NUMBER,
				'default' => '0',
			)
		);

		$repeater->add_control(
			'card_image',
			array(
				'label'   => 'Card Image',
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$repeater->add_control(
			'card_title',
			array(
				'label'       => 'Card Title',
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Card Title',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'card_description',
			array(
				'label'       => __( 'Card Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'card_button_text',
			array(
				'label'       => 'Button Text',
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Learn More',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'card_button_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$repeater->add_control(
			'card_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .card-offer-style-2' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'iori_cards',
			array(
				'label'  => 'Cards',
				'type'   => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			)
		);

		$this->end_controls_section();

		// top title style
		$this->start_controls_section(
			'tabs_top_title_style',
			array(
				'label' => __( 'Top Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_top_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .tabs-section .top_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_top_title_typography',
				'selector' => '{{WRAPPER}} .tabs-section .top_title',
				
			)
		);

		$this->end_controls_section();

		// card title style
		$this->start_controls_section(
			'tabs_card_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_card_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_card_title_typography',
				'selector' => '{{WRAPPER}} .card-info .title',
				
			)
		);

		$this->end_controls_section();

		// card desc style
		$this->start_controls_section(
			'tabs_card_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_card_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_card_desc_typography',
				'selector' => '{{WRAPPER}} .card-info .desc',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();

		$tabs  = $settings['iori_tabs'];
		$cards = $settings['iori_cards'];
		?>

		<section class="section tabs-section">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-md-10 col-lg-8 text-center">
						<h2 class="top_title mb-20 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['tabs_top_title'] ); ?></h2>
					</div>
				</div>
				<div class="text-center mt-25 mb-65 wow animate__animated animate__fadeIn" data-wow-delay=".3s">
					<div class="box-social-media">
						<ul class="tabs-plan change-media" role="tablist">
							<?php foreach ( $tabs as $index => $tab ) : ?>
								<li><a class="<?php echo ( $index === 0 ) ? 'active' : ''; ?>" href="#" data-type="<?php echo $tab['tab_name']; ?>"><?php echo $tab['tab_name']; ?></a></li>
							<?php endforeach; ?>
						</ul>
					</div>
				</div>

				<div class="row mt-50">
					<?php foreach ( $cards as $card ) : ?>
						<div class="col-lg-4 col-md-6 social-media <?php echo $card['card_type']; ?> elementor-repeater-item-<?php echo esc_attr( $card['_id'] ); ?>">
							<div class="card-offer-style-2 wow animate__animated animate__fadeInUp" data-wow-delay="<?php echo $card['card_animation_delay']; ?>s">
								<div class="card-offer hover-up">
									<div class="card-image"><img src="<?php echo $card['card_image']['url']; ?>" alt="<?php echo $card['card_title']; ?>"></div>
									<div class="card-info">
										<h4 class="title mb-15 mt-0"><?php echo $card['card_title']; ?></h4>
										<p class="desc mb-15"><?php echo $card['card_description']; ?></p>
										<div class="box-button-offer">
											<a href="<?php echo esc_url( $card['card_button_link'] ); ?>" class="btn btn-default font-sm-bold pl-0 color-brand-1">
												<?php echo $card['card_button_text']; ?>
												<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
												</svg>
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

		<?php
	}
}
