<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Brand
 *
 * @since 1.0.0
 */

class Brand_Two extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-brand-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Brand Two', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-box d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'brand', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'brand_two_section',
			array(
				'label' => __( 'Brand Two', 'iori' ),
			)
		);

		$this->add_control(
			'brand_two_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'brand_two_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'brand_two_img',
			array(
				'label'   => esc_html__( 'Upload Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'brand_two_item_list',
			array(
				'label'   => __( 'Brand Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'brand_two_img' => '',
					),
					array(
						'brand_two_img' => '',
					),
					array(
						'brand_two_img' => '',
					),
				),
			)
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => 'thumbnail',
				'separator' => 'none',
			)
		);

		$this->end_controls_section();

		// start style here

		// title
		$this->start_controls_section(
			'brand_two_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'brand_two_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .brand_two_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'brand_two_title_typography',
				'selector' => '{{WRAPPER}} .brand_two_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'brand_two_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'brand_two_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .brand_two_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'brand_two_desc_typography',
				'selector' => '{{WRAPPER}} .brand_two_desc',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$brand_two_item_lists = $settings['brand_two_item_list'];

		?>


		<section>
			<div class="text-start">
				<h3 class="brand_two_title mb-20 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo wpautop( $settings['brand_two_title'] ); ?></h3>
				<div class="brand_two_desc wow animate__animated animate__fadeInUp" data-wow-delay=".2s"><?php echo $settings['brand_two_desc']; ?></div>
			</div>
			<div class="mt-50 wow animate__animated animate__fadeIn" data-wow-delay=".4s">
				<ul class="list-partners list-partners-left text-start mb-0">

					<?php
					foreach ( $brand_two_item_lists as $brand_two_item_list ) { 
						?>

						<li class="mb-0"><img src="<?php echo $brand_two_item_list['brand_two_img']['url']; ?>" alt="iori"></li>

						<?php
					} 
					?>

				</ul>
			</div>
		</section>

		<?php
	}
}
