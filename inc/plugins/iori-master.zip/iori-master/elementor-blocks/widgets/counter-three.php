<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for counter Three
 *
 * @since 1.0.0
 */

class Counter_three extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-counter-three';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Counter Three', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'counter', 'count', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'counter_three_section',
			array(
				'label' => __( 'Counter Three', 'iori' ),
			)
		);

		$this->add_control(
			'counter_three_number',
			array(
				'label'   => __( 'Number', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '',
			)
		);

		$this->add_control(
			'counter_three_quantity',
			array(
				'label'   => __( 'Quantity', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'counter_three_subject',
			array(
				'label'   => __( 'Subject', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->end_controls_section();

		// content style start

		// counter box
		$this->start_controls_section(
			'counter_three_box_style',
			array(
				'label' => __( 'Counter Box', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_three_box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-number-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'counter_three_box_align',
			array(
				'label'     => esc_html__( 'Alignment', 'iori' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left' => array(
						'title' => esc_html__( 'Left', 'iori' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'iori' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'iori' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .box-number-2' => 'text-align: {{VALUE}}',
					'{{WRAPPER}} .box-number-2' => 'margin: 0 auto; margin-{{VALUE}}: 0',
				),
			)
		);

		$this->add_control(
			'counter_three_box_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-2' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'counter_three_box_border_width',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-number-2' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'counter_three_box_border_color',
			array(
				'label'     => __( 'Border Color', 'iori' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-2' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'counter_three_box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-number-2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'box_shadow',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .box-number-2',
			)
		);

		$this->end_controls_section();

		// number
		$this->start_controls_section(
			'counter_three_number_style',
			array(
				'label' => __( 'Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_three_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .counter_three_content .number' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_three_number_typography',
				'selector' => '{{WRAPPER}} .counter_three_content .number',
				
			)
		);

		$this->end_controls_section();

		// quantity
		$this->start_controls_section(
			'counter_three_quantity_style',
			array(
				'label' => __( 'Quantity', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_three_quantity_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .counter_three_content .quantity' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_three_quantity_typography',
				'selector' => '{{WRAPPER}} .counter_three_content .quantity',
				
			)
		);

		$this->end_controls_section();

		// subject
		$this->start_controls_section(
			'counter_three_subject_style',
			array(
				'label' => __( 'Subject', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_three_subject_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .counter_three_content .subject' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_three_subject_typography',
				'selector' => '{{WRAPPER}} .counter_three_content .subject',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="counter_three_content box-chart-1 text-end">
			<div class="box-number-2">
				<h2 class="my-0">
					<span class="count number"><?php echo esc_html( $settings['counter_three_number'] ); ?></span>
					<span class="quantity"><?php echo esc_html( $settings['counter_three_quantity'] ); ?></span>
				</h2>
				<p class="subject mb-0 wow animate__animated animate__fadeInUp" data-wow-delay=".6s"><?php echo esc_html( $settings['counter_three_subject'] ); ?></p>
			</div>
		</div>

		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				/*---- CounterUp ----*/
				if (jQuery(".count").length) {
					jQuery(".count").counterUp({
						delay: 10,
						time: 600
					});
				}
			</script>
		<?php } ?>

		<?php
	}
}
