<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner
 *
 * Elementor widget for banner
 *
 * @since 1.0.0
 */
class Banner_Fourteen extends Widget_Base {


	public function get_name() {
		return 'iori-banner-fourteen';
	}

	public function get_title() {
		return esc_html__( 'Banner Fourteen', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-fourteen', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_fourteen_section',
			array(
				'label' => __( 'Banner Fourteen', 'iori' ),
			)
		);

		$this->add_control(
			'banner_fourteen_top_title',
			array(
				'label'       => __( 'Top Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_fourteen_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_fourteen_desc',
			array(
				'label'       => __( 'Desc', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_fourteen_app_title',
			array(
				'label'       => __( 'App Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_fourteen_app_img',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_fourteen_app_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);


		$this->add_control(
			'banner_fourteen_app_img2',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_fourteen_app_img2_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_fourteen_btn',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_fourteen_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_fourteen_bg_img',
			array(
				'label'       => __( 'Background Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->end_controls_section();

		// content style

		// top title
		$this->start_controls_section(
			'banner_fourteen_top_title_style',
			array(
				'label' => __( 'Top Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_fourteen_top_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .title-line' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_fourteen_top_title_typography',
				'selector' => '{{WRAPPER}} .title-line',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'banner_fourteen_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_fourteen_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-1 .title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_fourteen_title_typography',
				'selector' => '{{WRAPPER}} .banner-1 .title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'banner_fourteen_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_fourteen_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-1 .desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_fourteen_desc_typography',
				'selector' => '{{WRAPPER}} .banner-1 .desc',
				
			)
		);

		$this->end_controls_section();

		// apptitle
		$this->start_controls_section(
			'banner_fourteen_app_title_style',
			array(
				'label' => __( 'App title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_fourteen_app_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-1 .app_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_fourteen_app_title_typography',
				'selector' => '{{WRAPPER}} .banner-1 .app_title',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$banner_fourteen_app_img  = $settings['banner_fourteen_app_img']['url'];
		$banner_fourteen_app_img2 = $settings['banner_fourteen_app_img2']['url'];
		$banner_fourteen_bg_img   = $settings['banner_fourteen_bg_img']['url'];

		?>

		<section class="section banner-contact">
			<div class="container">
				<div class="banner-1">
					<div class="row align-items-center">
						<div class="col-lg-7"><span class="title-line line-48 wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html( $settings['banner_fourteen_top_title'] ); ?></span>
							<h1 class="title mb-20 mt-10 wow animate__animated animate__fadeIn" data-wow-delay=".2s"><?php echo wpautop( $settings['banner_fourteen_title'] ); ?></h1>
							<div class="row">
								<div class="col-lg-9">
									<div class="desc wow animate__animated animate__fadeIn" data-wow-delay=".4s"><?php echo $settings['banner_fourteen_desc']; ?></d>
								</div>
							</div>
							<div class="mt-30 wow animate__animated animate__fadeIn" data-wow-delay=".6s">
								<h5 class="app_title"><?php echo esc_html( $settings['banner_fourteen_app_title'] ); ?></h5>
							</div>
							<div class="box-button mt-20">
								<a href="<?php echo esc_url( $settings['banner_fourteen_app_img_link'] ); ?>" class="btn-app mb-15 hover-up">
									<img src="<?php echo esc_url( $banner_fourteen_app_img ); ?>" alt="iori">
								</a>
								<a href="<?php echo esc_url( $settings['banner_fourteen_app_img2_link'] ); ?>" class="btn-app mb-15 hover-up">
									<img src="<?php echo esc_url( $banner_fourteen_app_img2 ); ?>" alt="iori"></a>
								<a href="#" class="btn btn-default mb-15 pl-10 font-sm-bold hover-up"><?php echo esc_html( $settings['banner_fourteen_btn'] ); ?>
								  <svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
								  </svg>
								</a>
							</div>
						</div>
						<div class="col-lg-5 d-none d-lg-block">
							<div class="box-banner-contact">
								<img src="<?php echo esc_url( $banner_fourteen_bg_img ); ?>" alt="iori">
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
