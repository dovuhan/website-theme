<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Exit if accessed directly

/**
 * App Testimonial Four
 *
 * Elementor app Testimonial Four
 *
 * @since 1.0.0
 */
class Testimonial_Four extends Widget_Base {


	public function get_name() {
		return 'iori-testimonial-four';
	}

	public function get_title() {
		return __( 'Testimonial Four', 'Iori' );
	}

	public function get_icon() {
		return 'eicon-testimonial d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'testimonial', 'reviews', 'iori' );
	}

	/**
	 * Register image carousel widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'testimonial_four_section',
			array(
				'label' => __( 'Testimonial Four', 'iori' ),
			)
		);

		$this->add_control(
			'testimonial_four_img',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_four_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_four_author_name',
			array(
				'label'       => __( 'Author Name', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_four_author_designation',
			array(
				'label'       => __( 'Designation', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$this->end_controls_section();

		// testimonial four style

		// description
		$this->start_controls_section(
			'testimonial_four_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_four_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-item-comment .testimonial_desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_four_desc_typography',
				
				'selector' => '{{WRAPPER}} .box-item-comment .testimonial_desc',
			)
		);

		$this->end_controls_section();

		// name
		$this->start_controls_section(
			'testimonial_four_author_name_style',
			array(
				'label' => __( 'Author Name', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_four_author_name_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-item-comment .testimonial_author' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_four_author_name_typography',
				
				'selector' => '{{WRAPPER}} .box-item-comment .testimonial_author',
			)
		);

		$this->end_controls_section();

		// designation
		$this->start_controls_section(
			'testimonial_four_author_designation_style',
			array(
				'label' => __( 'Designation', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_four_author_designation_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-item-comment .designation' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_four_author_designation_typography',
				
				'selector' => '{{WRAPPER}} .box-item-comment .designation',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render image carousel widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
		<div class="box-item-comment wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
			<div class="image-comment">
				<img src="<?php echo esc_url( $settings['testimonial_four_img']['url'] ); ?>" alt="iori">
			</div>
			<div class="info-comment">
				<div class="testimonial_desc comment-quote mb-15"><?php echo $settings['testimonial_four_desc']; ?></div>
				<span class="testimonial_author"><?php echo esc_html( $settings['testimonial_four_author_name'] ); ?></span>
				<p class="designation"><?php echo esc_html( $settings['testimonial_four_author_designation'] ); ?></p>
			</div>
		</div>

		<?php

	}
}
