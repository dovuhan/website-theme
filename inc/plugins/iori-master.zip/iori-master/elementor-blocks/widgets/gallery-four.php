<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Gallery Four
 *
 * Elementor widget for gallery
 *
 * @since 1.0.0
 */
class Gallery_Four extends Widget_Base {


	public function get_name() {
		return 'iori-gallery-four';
	}

	public function get_title() {
		return esc_html__( 'Gallery Four', 'iori' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'gallery', 'image', 'picture', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'gallery_four_section',
			array(
				'label' => esc_html__( 'Gallery Four', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_four_top_count_number',
			array(
				'label'       => __( 'Number', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_four_top_count_subject',
			array(
				'label'       => __( 'Subject', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_four_main_img',
			array(
				'label'   => esc_html__( 'Main Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'gallery_four_left_img',
			array(
				'label'   => esc_html__( 'Image Left', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'gallery_four_bottom_img',
			array(
				'label'   => esc_html__( 'Image Bottom', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'gallery_four_count_number',
			array(
				'label'       => __( 'Number', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
				'separator'   => 'before',
			)
		);

		$this->add_control(
			'gallery_four_count_quantity',
			array(
				'label'       => __( 'Quantity', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'gallery_four_count_subject',
			array(
				'label'       => __( 'Subject', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->end_controls_section();

		// top counter styles

		// number
		$this->start_controls_section(
			'gallery_four_top_count_number_style',
			array(
				'label' => __( 'Top Counter Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_four_top_count_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-1 .number' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_four_top_count_number_typography',
				'selector' => '{{WRAPPER}} .box-number-1 .number',
				
			)
		);

		$this->end_controls_section();

		// subject
		$this->start_controls_section(
			'gallery_four_top_count_subject_style',
			array(
				'label' => __( 'Top Counter Subject', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_four_top_count_subject_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-1 .subject' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_four_top_count_subject_typography',
				'selector' => '{{WRAPPER}} .box-number-1 .subject',
				
			)
		);

		$this->end_controls_section();

		// bottom counter styles

		// number
		$this->start_controls_section(
			'gallery_four_count_number_style',
			array(
				'label' => __( 'Bottom Counter Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_four_count_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-2 .count' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_four_count_number_typography',
				'selector' => '{{WRAPPER}} .box-number-2 .count',
				
			)
		);

		$this->end_controls_section();

		// quantity
		$this->start_controls_section(
			'gallery_four_count_quantity_style',
			array(
				'label' => __( 'Bottom Counter Quantity', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_four_count_quantity_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-2 .quantity' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_four_count_quantity_typography',
				'selector' => '{{WRAPPER}} .box-number-2 .quantity',
				
			)
		);

		$this->end_controls_section();

		// subject
		$this->start_controls_section(
			'gallery_four_count_subject_style',
			array(
				'label' => __( 'Bottom Counter Subject', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'gallery_four_count_subject_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-number-2 .subject' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'gallery_four_count_subject_typography',
				'selector' => '{{WRAPPER}} .box-number-2 .subject',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
		<div class="box-business-service">
			<div class="box-number-1 shape-2">
				<div class="cardNumber bg-white">
					<h3 class="number"><?php echo esc_html( $settings['gallery_four_top_count_number'] ); ?></h3>
					<div class="subject"><?php echo esc_html( $settings['gallery_four_top_count_subject'] ); ?></div>
				</div>
			</div>
			<div class="box-image-1 shape-3">
				<img src="<?php echo $settings['gallery_four_left_img']['url']; ?>" alt="iori">
			</div>
			<div class="box-image-2 shape-2">
				<img src="<?php echo $settings['gallery_four_bottom_img']['url']; ?>" alt="iori">
			</div>
			<div class="box-image-3 shape-1">
				<img src="<?php echo $settings['gallery_four_main_img']['url']; ?>" alt="iori">
				<div class="cardNumber box-number-2 bg-white">
					<h2 class="title">
						<span class="count"><?php echo esc_html( $settings['gallery_four_count_number'] ); ?></span>
						<span class="quantity"><?php echo esc_html( $settings['gallery_four_count_quantity'] ); ?></span>
					</h2>
					<p class="subject"><?php echo esc_html( $settings['gallery_four_count_subject'] ); ?></p>
				</div>
			</div>
		</div>

		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				/*---- CounterUp ----*/
				if (jQuery(".count").length) {
					jQuery(".count").counterUp({
						delay: 10,
						time: 600
					});
				}
			</script>
		<?php } ?>

		<?php
	}
}
