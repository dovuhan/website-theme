<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Testimonial
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Button_Group_Two extends Widget_Base {


	public function get_name() {
		return 'iori-button-group-two';
	}

	public function get_title() {
		return esc_html__( 'Button Group Two', 'iori' );
	}

	public function get_icon() {
		return 'eicon-button d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'button', 'group', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Button Group Two', 'iori' ),
			)
		);

		$this->add_control(
			'content_down_btn',
			array(
				'label'       => __( 'Button One', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Download App',
			)
		);

		$this->add_control(
			'content_down_btn_link',
			array(
				'label'       => __( 'Button Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'content_more_btn',
			array(
				'label'       => __( 'Button Two', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Learn More',
			)
		);

		$this->add_control(
			'content_more_btn_link',
			array(
				'label'       => __( 'Button Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);


		$this->end_controls_section();

		// =========== Start Style Section ==========

		// button
		$this->start_controls_section(
			'content_btn_style',
			array(
				'label' => __( 'Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'content_btn_styles' );

		$this->start_controls_tab(
			'content_btn_normal',
			array(
				'label' => __( 'Normal', 'iori' ),
			)
		);

		$this->add_control(
			'content_btn_normal_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'content_btn_bg_normal_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_btn_normal_typography',
				'selector' => '{{WRAPPER}} .btn.btn-brand-1',
				
			)
		);

		$this->add_responsive_control(
			'content_btn_normal_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .btn.btn-brand-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'content_btn_hover',
			array(
				'label' => __( 'Hover', 'iori' ),
			)
		);

		$this->add_control(
			'content_btn_hover_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'content_btn_bg_hover_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .btn.btn-brand-1:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_btn_typography',
				'selector' => '{{WRAPPER}} .btn.btn-brand-1:hover',
				
			)
		);

		$this->add_responsive_control(
			'content_btn_hover_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .btn.btn-brand-1:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="mt-50 text-start wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
			<a class="btn btn-brand-1 hover-up" href="<?php echo esc_html( $settings['content_down_btn_link'] ); ?>"><?php echo esc_html( $settings['content_down_btn'] ); ?></a>
			<a class="btn btn-default font-sm-bold hover-up" href="<?php echo esc_html( $settings['content_more_btn_link'] ); ?>"><?php echo esc_html( $settings['content_more_btn'] ); ?>
				<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
				</svg>
			</a>
		</div>

		<?php
	}
}
