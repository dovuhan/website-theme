<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner Four
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Banner_Four extends Widget_Base {


	public function get_name() {
		return 'iori-banner-four';
	}

	public function get_title() {
		return esc_html__( 'Banner Four', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-four', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_four_section',
			array(
				'label' => __( 'Banner Four', 'iori' ),
			)
		);

		$this->add_control(
			'banner_four_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_four_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_four_top_desc',
			array(
				'label'       => __( 'Top Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_four_bg_img',
			array(
				'label'       => __( 'Background Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_four_play_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => array(
					'active' => true,
				),
				'placeholder' => __( 'https://your-link.com', 'iori' ),
			)
		);

		$this->add_control(
			'banner_four_bottom_desc',
			array(
				'label'       => __( 'Bottom Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		// box one
		$this->add_control(
			'banner_four_box1_img',
			array(
				'label'       => __( 'Box One Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'separator'   => 'before',
			)
		);

		$this->add_control(
			'banner_four_box1_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_four_box1_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_four_box1_title_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_four_box1_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		// box two
		$this->add_control(
			'banner_four_box2_img',
			array(
				'label'       => __( 'Box Two Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'separator'   => 'before',
			)
		);

		$this->add_control(
			'banner_four_box2_img_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_four_box2_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_four_box2_title_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);

		$this->add_control(
			'banner_four_box2_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->end_controls_section();

		// content style

		// subtitle
		$this->start_controls_section(
			'banner_four_subtitle_style',
			array(
				'label' => __( 'Subtitle', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_four_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-5 .title-line' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_four_subtitle_typography',
				'selector' => '{{WRAPPER}} .banner-5 .title-line',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'banner_four_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_four_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-5 .banner_four_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_four_title_typography',
				'selector' => '{{WRAPPER}} .banner-5 .banner_four_title',
				
			)
		);

		$this->end_controls_section();

		// top description
		$this->start_controls_section(
			'banner_four_top_desc_style',
			array(
				'label' => __( 'Top Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_four_top_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-5 .banner_four_top_desc' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_four_top_desc_typography',
				'selector' => '{{WRAPPER}} .banner-5 .banner_four_top_desc',
				
			)
		);

		$this->end_controls_section();

		// bottom description
		$this->start_controls_section(
			'banner_four_bottom_desc_style',
			array(
				'label' => __( 'Bottom Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_four_bottom_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-5 .banner_four_bottom_desc' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_four_bottom_desc_typography',
				'selector' => '{{WRAPPER}} .banner-5 .banner_four_bottom_desc',
				
			)
		);

		$this->end_controls_section();

		// box one
		$this->start_controls_section(
			'banner_four_box1_style',
			array(
				'label' => __( 'Box One', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		// title
		$this->add_control(
			'heading_title',
			array(
				'label'     => __( 'Title', 'iori' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			)
		);

		$this->add_control(
			'banner_four_box1_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-5 .banner_four_box1_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_four_box1_title_typography',
				'selector' => '{{WRAPPER}} .banner-5 .banner_four_box1_title',
				
			)
		);

		// description
		$this->add_control(
			'heading_description',
			array(
				'label'     => __( 'Description', 'iori' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			)
		);

		$this->add_control(
			'banner_four_box1_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-5 .banner_four_box1_desc' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_four_box1_desc_typography',
				'selector' => '{{WRAPPER}} .banner-5 .banner_four_box1_desc',
				
			)
		);

		$this->end_controls_section();

		// box two
		$this->start_controls_section(
			'banner_four_box2_style',
			array(
				'label' => __( 'Box Two', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		// title
		$this->add_control(
			'heading_title_two',
			array(
				'label'     => __( 'Title', 'iori' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			)
		);

		$this->add_control(
			'banner_four_box2_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-5 .banner_four_box2_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_four_box2_title_typography',
				'selector' => '{{WRAPPER}} .banner-5 .banner_four_box2_title',
				
			)
		);

		// description
		$this->add_control(
			'heading_description_two',
			array(
				'label'     => __( 'Description', 'iori' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			)
		);

		$this->add_control(
			'banner_four_box2_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-5 .banner_four_box2_desc' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_four_box2_desc_typography',
				'selector' => '{{WRAPPER}} .banner-5 .banner_four_box2_desc',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<section class="section banner-5">
			<div class="container">
				<div class="mt-65 mb-100">
					<div class="row align-items-end">
						<div class="col-lg-6 mb-20"><span class="title-line wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['banner_four_subtitle'] ); ?></span>
							<h2 class="banner_four_title mt-10 wow animate__animated animate__fadeInUp" data-wow-delay=".2s"><?php echo esc_html( $settings['banner_four_title'] ); ?></h2>
						</div>
						<div class="col-lg-6 mb-20">
							<div class="banner_four_top_desc wow animate__animated animate__fadeInUp" data-wow-delay=".4s"><?php echo $settings['banner_four_top_desc']; ?></div>
						</div>
					</div>
					<div class="box-video-banner">
						<div class="image-banner-5 wow animate__animated animate__fadeIn"><img src="<?php echo $settings['banner_four_bg_img']['url']; ?>" alt="iori"><a class="btn btn-play-center popup-youtube" href="<?php echo esc_url( $settings['banner_four_play_btn_link']['url'] ); ?>"></a></div>
					</div>
					<div class="box-info-video-banner">
						<div class="box-inner-video-banner">
							<div class="row align-items-start">
								<div class="col-lg-5">
									<div class="banner_four_bottom_desc animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo $settings['banner_four_bottom_desc']; ?></div>
								</div>
								<div class="col-lg-7">
									<div class="row">
										<div class="col-lg-6 wow animate__animated animate__fadeIn" data-wow-delay=".1s">
											<div class="card-small card-small-2">
												<div class="card-image">
													<a href="<?php echo esc_html( $settings['banner_four_box1_img_link'] ); ?>">
														<div class="box-image"><img src="<?php echo $settings['banner_four_box1_img']['url']; ?>" alt="iori"></div>
													</a>
												</div>
												<div class="card-info">
													<a href="<?php echo esc_html( $settings['banner_four_box1_title_link'] ); ?>">
														<h6 class="banner_four_box1_title color-brand-1 mt-0 mb-10"><?php echo esc_html( $settings['banner_four_box1_title'] ); ?></h6>
													</a>
													<div class="banner_four_box1_desc"><?php echo $settings['banner_four_box1_desc']; ?></div>
												</div>
											</div>
										</div>
										<div class="col-lg-6 wow animate__animated animate__fadeIn" data-wow-delay=".2s">
											<div class="card-small card-small-2">
												<div class="card-image">
													<a href="<?php echo esc_html( $settings['banner_four_box2_img_link'] ); ?>">
														<div class="box-image"><img src="<?php echo $settings['banner_four_box2_img']['url']; ?>" alt="iori"></div>
													</a>
												</div>
												<div class="card-info">
													<a href="<?php echo esc_html( $settings['banner_four_box2_title_link'] ); ?>">
														<h6 class="banner_four_box2_title color-brand-1 mt-0 mb-10"><?php echo esc_html( $settings['banner_four_box2_title'] ); ?></h6>
													</a>
													<div class="banner_four_box2_desc"><?php echo $settings['banner_four_box2_desc']; ?></div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
