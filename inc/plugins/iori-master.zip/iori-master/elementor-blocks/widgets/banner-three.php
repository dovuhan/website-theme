<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Banner
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Banner_Three extends Widget_Base {


	public function get_name() {
		return 'iori-banner-three';
	}

	public function get_title() {
		return esc_html__( 'Banner Three', 'iori' );
	}

	public function get_icon() {
		return 'eicon-banner d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'banner', 'banner-three', 'hero', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() {
		$this->start_controls_section(
			'banner_three_section',
			array(
				'label' => __( 'Banner Three', 'iori' ),
			)
		);

		$this->add_control(
			'banner_three_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_three_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_three_play_btn_text',
			array(
				'label'       => __( 'Play Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'banner_three_play_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => array(
					'active' => true,
				),
				'placeholder' => __( 'https://your-link.com', 'iori' ),
			)
		);

		$this->add_control(
			'banner_three_chart_img1',
			array(
				'label'       => __( 'Chart Image One', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_three_chart_img2',
			array(
				'label'       => __( 'Chart Image Two', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_three_bg_img',
			array(
				'label'       => __( 'Background Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_three_chart_img3',
			array(
				'label'       => __( 'Chart Image Three', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->end_controls_section();

		// content style

		// subtitle
		$this->start_controls_section(
			'banner_three_subtitle_style',
			array(
				'label' => __( 'Subtitle', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_three_subtitle_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-3 .title-line' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_three_subtitle_typography',
				'selector' => '{{WRAPPER}} .banner-3 .title-line',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'banner_three_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'banner_three_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-3 .banner_three_title' => 'color: {{VALUE}} !important;',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_three_title_typography',
				'selector' => '{{WRAPPER}} .banner-3 .banner_three_title',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<section class="section banner-3">
			<div class="container">
				<div class="banner-1">
					<div class="row align-items-end">
						<div class="col-lg-6 pt-80 pb-50">
							<span class="title-line line-48 wow animate__animated animate__fadeInUp" data-wow-delay=".0s"><?php echo esc_html( $settings['banner_three_subtitle'] ); ?></span>
							<h1 class="banner_three_title mb-20 mt-15 wow animate__animated animate__fadeInUp" data-wow-delay=".2s"><?php echo esc_html( $settings['banner_three_title'] ); ?></h1>
							<div class="box-button-video wow animate__animated animate__fadeInUp" data-wow-delay=".4s"><a class="btn btn-play font-sm-bold popup-youtube color-brand-1 hover-up" href="<?php echo esc_url( $settings['banner_three_play_btn_link']['url'] ); ?>"><?php echo esc_html( $settings['banner_three_play_btn_text'] ); ?></a></div>
							<div class="mt-40 d-flex">
								<div class="wow animate__animated animate__zoomIn" data-wow-delay=".0s">
									<img class="img-banner-1 mr-15" src="<?php echo $settings['banner_three_chart_img1']['url']; ?>" alt="iori">
								</div>
								<div class="wow animate__animated animate__zoomIn" data-wow-delay=".2s"><img class="img-banner-2" src="<?php echo $settings['banner_three_chart_img2']['url']; ?>" alt="iori"></div>
							</div>
						</div>
						<div class="col-lg-6 d-none d-lg-block position-relative">
							<div class="box-image-main wow animate__animated animate__fadeIn" data-wow-delay=".0s"><img class="image-banner-main d-block" src="<?php echo $settings['banner_three_bg_img']['url']; ?>" alt="iori"></div>
							<div class="box-chart"><img class="image-chart shape-1" src="<?php echo $settings['banner_three_chart_img3']['url']; ?>" alt="iori"></div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
