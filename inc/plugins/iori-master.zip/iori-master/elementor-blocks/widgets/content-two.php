<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Testimonial
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Content_Two extends Widget_Base {


	public function get_name() {
		return 'iori-content-two';
	}

	public function get_title() {
		return esc_html__( 'List Content', 'iori' );
	}

	public function get_icon() {
		return 'eicon-post-content d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'content', 'project', 'company', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'content_two_section',
			array(
				'label' => esc_html__( 'Content Two', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'content_two_number',
			array(
				'label'   => __( 'Number', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
			)
		);

		$repeater->add_control(
			'content_two_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'content_two_desc',
			array(
				'label'   => __( 'Description', 'iori' ),
				'type'    => Controls_Manager::TEXTAREA,
			)
		);


		$this->add_control(
			'content_two_list',
			array(
				'label'   => __( 'Content Item List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'content_two_number' => '1',
						'content_two_title'  => 'Lorem ipsum dolor sit amet.',
						'content_two_desc'   => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit, ut.',
					),
					array(
						'content_two_number' => '2',
						'content_two_title'  => 'Lorem ipsum dolor sit amet.',
						'content_two_desc'   => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit, ut.',
					),
					array(
						'content_two_number' => '3',
						'content_two_title'  => 'Lorem ipsum dolor sit amet.',
						'content_two_desc'   => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit, ut.',
					),
				),
			)
		);

		$this->end_controls_section();
		// Content options End

		// =========== Start Style Section ==========

		// number
		$this->start_controls_section(
			'content_two_number_style',
			array(
				'label' => __( 'Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_two_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .item-number .num-ele' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_control(
			'content_two_number_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .item-number .num-ele' => 'background-color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_two_number_typography',
				'selector' => '{{WRAPPER}} .item-number .num-ele',
				
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'content_two_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_two_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .item-number .content_title' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_two_title_typography',
				'selector' => '{{WRAPPER}} .item-number .content_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'content_two_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_two_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .item-number .content_desc' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_two_desc_typography',
				'selector' => '{{WRAPPER}} .item-number .content_desc',
				
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_two_space',
			array(
				'label' => __( 'Specing', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'content_two_specing',
			array(
				'label'      => __( 'Margin', 'sapp' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .item-number' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$content_two_lists = $settings['content_two_list'];

		?>

		<?php
		foreach ( $content_two_lists as $content_two_list ) { 
			?>

			<div class="item-number hover-up">
				<div class="num-ele"><?php echo $content_two_list['content_two_number']; ?></div>
				<div class="info-num">
					<h5 class="content_title mb-15 mt-0"><?php echo esc_html( $content_two_list['content_two_title'] ); ?></h5>
					<p class="content_desc mb-0">
						<?php echo $content_two_list['content_two_desc']; ?>
					</p>
				</div>
			</div>

			<?php
		} 
		?>

		<?php
	}
}
