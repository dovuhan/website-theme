<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Exit if accessed directly

/**
 * App Testimonial
 *
 * Elementor app Testimonial Three
 *
 * @since 1.0.0
 */
class Testimonial_Three extends Widget_Base {


	public function get_name() {
		return 'iori-testimonial-three';
	}

	public function get_title() {
		return __( 'Testimonial Three', 'Iori' );
	}

	public function get_icon() {
		return 'eicon-testimonial d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'testimonial', 'reviews', 'iori' );
	}

	/**
	 * Register image carousel widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'testimonial_three_section',
			array(
				'label' => __( 'Testimonial Three', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'testimonial_three_rating_star',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_three_rating',
			array(
				'label'   => 'Rating',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 1,
				'max'     => 5,
				'step'    => 1,
			)
		);

		$repeater->add_control(
			'testimonial_three_desc',
			array(
				'label'   => 'Description',
				'type'    => \Elementor\Controls_Manager::WYSIWYG,
				'default' => '',
			)
		);

		$repeater->add_control(
			'testimonial_three_author_image',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_three_author_name',
			array(
				'label'       => 'Author Name',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_three_author_name_link',
			array(
				'label'       => 'Link',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'testimonial_three_author_department',
			array(
				'label'       => 'Author Department',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'testimonial_three_list',
			array(
				'label'   => __( 'Testimonial', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'testimonial_three_rating_star'  => '',
						'testimonial_three_rating'       => '',
						'testimonial_three_desc'         => '',
						'testimonial_three_author_image' => '',
						'testimonial_three_author_name'  => '',
						'testimonial_three_author_name_link' => '',
						'testimonial_three_author_department' => '',
					),
					array(
						'testimonial_three_rating_star'  => '',
						'testimonial_three_rating'       => '',
						'testimonial_three_desc'         => '',
						'testimonial_three_author_image' => '',
						'testimonial_three_author_name'  => '',
						'testimonial_three_author_name_link' => '',
						'testimonial_three_author_department' => '',
					),
					array(
						'testimonial_three_rating_star'  => '',
						'testimonial_three_rating'       => '',
						'testimonial_three_desc'         => '',
						'testimonial_three_author_image' => '',
						'testimonial_three_author_name'  => '',
						'testimonial_three_author_name_link' => '',
						'testimonial_three_author_department' => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// =========== testimonial style start ===========

		// description
		$this->start_controls_section(
			'testimonial_three_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_three_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .testimonial_three_desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_three_desc_typography',
				
				'selector' => '{{WRAPPER}} .testimonial_three_desc',
			)
		);

		$this->end_controls_section();

		// author name
		$this->start_controls_section(
			'testimonial_three_author_title_style',
			array(
				'label' => __( 'Author Name', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_three_author_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-author .author-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_three_author_title_typography',
				
				'selector' => '{{WRAPPER}} .box-author .author-name',
			)
		);

		$this->end_controls_section();

		// department
		$this->start_controls_section(
			'testimonial_three_author_department_style',
			array(
				'label' => __( 'Department', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_three_author_department_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-author .department' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'testimonial_three_author_department_typography',
				
				'selector' => '{{WRAPPER}} .box-author .department',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render image carousel widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( empty( $settings['testimonial_three_list'] ) ) {
			return;
		}
		$testimonial_three_lists = $settings['testimonial_three_list'];

		?>

		<div class="box-swiper">
			<div class="swiper-container swiper-group-2">
				<div class="swiper-wrapper">

					<?php
					foreach ( $testimonial_three_lists as $testimonial_three_list ) { 
						?>
						<div class="swiper-slide">
							<div class="card-review">
								<div class="card-info">
									<div class="rating-review">

										<?php
										$author_rating = intval( $testimonial_three_list['testimonial_three_rating'] );

										for ( $i = 1; $i <= $author_rating; $i++ ) {
											echo '<img src="' . $testimonial_three_list['testimonial_three_rating_star']['url'] . '">';
										}
										?>

									</div>
									<div class="testimonial_three_desc mb-20"><?php echo $testimonial_three_list['testimonial_three_desc']; ?></div>
									<div class="box-author">
										<img src="<?php echo $testimonial_three_list['testimonial_three_author_image']['url']; ?>">
										</a>
										<div class="author-info">
											<a href="<?php echo esc_url( $testimonial_three_list['testimonial_three_author_name_link'] ); ?>"><span class="author-name"><?php echo $testimonial_three_list['testimonial_three_author_name']; ?></span></a>
											<span class="department"><?php echo $testimonial_three_list['testimonial_three_author_department']; ?></span>
										</div>
									</div>
								</div>
							</div>
						</div>

					<?php } ?>

				</div>
			</div>
		</div>


		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				jQuery(".swiper-group-2").each(function() {
					var swiper_2_items = new Swiper(this, {
						spaceBetween: 30,
						slidesPerView: 2,
						slidesPerGroup: 1,
						loop: true,
						navigation: {
							nextEl: ".swiper-button-next",
							prevEl: ".swiper-button-prev"
						},
						pagination: {
							el: ".swiper-pagination",
							clickable: true
						},
						autoplay: {
							delay: 10000
						},
						breakpoints: {
							1199: {
								slidesPerView: 2
							},
							1000: {
								slidesPerView: 2
							},
							800: {
								slidesPerView: 1
							},
							600: {
								slidesPerView: 1
							},
							400: {
								slidesPerView: 1
							},
							350: {
								slidesPerView: 1
							}
						}
					});
				});
			</script>

		<?php } ?>

		<?php
	}
}
