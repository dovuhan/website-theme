<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor newsletter two
 *
 * Elementor widget for newsletter
 *
 * @since 1.0.0
 */
class Newsletter_Two extends Widget_Base {


	public function get_name() {
		return 'iori-newsletter-two';
	}

	public function get_title() {
		return esc_html__( 'Newsletter Two', 'iori' );
	}

	public function get_icon() {
		return 'eicon-notes d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'news', 'newsletter', 'subscribe', 'mail', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'newsletter_two_content',
			array(
				'label' => esc_html__( 'Newsletter Two', 'iori' ),
			)
		);

		$this->add_control(
			'newsletter_two_main_img',
			array(
				'label'       => esc_html__( 'Main Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'newsletter_two_subtitle',
			array(
				'label'       => __( 'Sub Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'newsletter_two_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'newsletter_two_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->add_control(
			'mailchimp_text',
			array(
				'label'       => __( 'Mailchimp Shortcode', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
				'label_block' => true,
				'description' => __(
					'Note: (Please replace this code in mailchimp form) <br/> &lt;input name="EMAIL" type="text" placeholder="Enter you mail.."&gt;
				&lt;button class="btn btn-submit-newsletter" type="submit"&gt;
					&lt;svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"&gt;
						&lt;path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"&gt;&lt;/path&gt;
					&lt;/svg&gt;
				&lt;/button&gt;'
				),
			)
		);

		$this->end_controls_section();

		// content style start

		// subtitle
		$this->start_controls_section(
			'newsletter_two_subtitle_style',
			array(
				'label' => esc_html__( 'Sub Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'newsletter_two_subtitle_color',
			array(
				'label'     => esc_html__( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-newsletter-2 .subtitle' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'newsletter_two_subtitle_typography',
				'label'    => esc_html__( 'Typography', 'iori' ),
				
				'selector' => '{{WRAPPER}} .box-newsletter-2 .subtitle',
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'newsletter_two_title_style',
			array(
				'label' => esc_html__( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'newsletter_two_title_color',
			array(
				'label'     => esc_html__( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-newsletter-2 .title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'newsletter_two_title_typography',
				'label'    => esc_html__( 'Typography', 'iori' ),
				
				'selector' => '{{WRAPPER}} .box-newsletter-2 .title',
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'newsletter_two_desc_style',
			array(
				'label' => esc_html__( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'newsletter_two_desc_color',
			array(
				'label'     => esc_html__( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-newsletter-2 .desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'newsletter_two_desc_typography',
				'label'    => esc_html__( 'Typography', 'iori' ),
				
				'selector' => '{{WRAPPER}} .box-newsletter-2 .desc',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$newsletter_two_main_img = $settings['newsletter_two_main_img']['url'];

		?>

		<section class="section">
			<div class="container">
				<div class="box-newsletter box-newsletter-2 wow animate__animated animate__fadeIn" style="background-image: url('<?php echo $newsletter_two_main_img; ?>');">
					<div class="row align-items-center">
						<div class="col-lg-6 col-md-7 m-auto text-center">
							<span class="subtitle wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html( $settings['newsletter_two_subtitle'] ); ?></span>
							<h2 class="title mb-15 mt-5 wow animate__animated animate__fadeIn" data-wow-delay=".1s"><?php echo esc_html( $settings['newsletter_two_title'] ); ?></h2>
							<div class="desc wow animate__animated animate__fadeIn" data-wow-delay=".2s"><?php echo $settings['newsletter_two_desc']; ?>
						   </div>
							<div class="form-newsletter mt-30 wow animate__animated animate__fadeIn" data-wow-delay=".3s">

								<?php echo do_shortcode( $settings['mailchimp_text'] ); ?>

							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
	}
}
