<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Tabs Four
 *
 * @since 1.0.0
 */

class Tabs_Four extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-tabs-four';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Tabs Four', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-tabs d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'tabs', 'four', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

	protected function _register_controls() {
		$repeater = new Repeater();

		$repeater->add_control(
			'heading',
			array(
				'label'       => 'Heading',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'content',
			array(
				'label'      => 'Content',
				'type'       => Controls_Manager::WYSIWYG,
				'default'    => '',
				'show_label' => false,
			)
		);

		$this->start_controls_section(
			'section_table_of_contents',
			array(
				'label' => 'Table of Contents',
			)
		);

		$this->add_control(
			'items',
			array(
				'label'        => 'Items',
				'type'         => Controls_Manager::REPEATER,
				'fields'       => $repeater->get_controls(),
				'default'      => array(
					array(
						'heading' => '',
						'content' => '',
					),
					array(
						'heading' => '',
						'content' => '',
					),
					array(
						'heading' => '',
						'content' => '',
					),
				),
				'title_field'  => '{{{ heading }}}',
			)
		);

		$this->end_controls_section();

		// tab item style
		$this->start_controls_section(
			'tabs_four_item_style',
			array(
				'label' => __( 'Tab Items', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_four_item_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-terms li a' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_four_item_typography',
				'selector' => '{{WRAPPER}} .list-terms li a',
				
			)
		);

		$this->end_controls_section();

		// tabs title style
		$this->start_controls_section(
			'tabs_four_content_title_style',
			array(
				'label' => __( 'Content Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_four_content_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .content-title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_four_content_title_typography',
				'selector' => '{{WRAPPER}} .content-title',
				
			)
		);

		$this->end_controls_section();

		// tabs content description style
		$this->start_controls_section(
			'tabs_four_content_desc_style',
			array(
				'label' => __( 'Content Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tabs_four_content_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .content' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tabs_four_content_desc_typography',
				'selector' => '{{WRAPPER}} .content',
				
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		echo '<div class="row">';
		echo '<div class="col-lg-2 col-md-3">';
		echo '<h6 class="top-title mb-15">Table of contents</h6>';
		echo '<ul class="list-terms">';
		foreach ( $settings['items'] as $item ) {
			$heading = $item['heading'];
			$anchor  = strtolower( str_replace( ' ', '-', $heading ) );
			echo '<li><a href="#' . $anchor . '">' . $heading . '</a></li>';
		}
		echo '</ul>';
		echo '</div>';

		echo '<div class="col-lg-8 col-md-7">';
		foreach ( $settings['items'] as $item ) {
			$heading = $item['heading'];
			$content = $item['content'];
			$anchor  = strtolower( str_replace( ' ', '-', $heading ) );
			echo '<h4 class="content-title mb-20" id="' . $anchor . '">' . $heading . '</h4>';
			echo '<div class="content mb-30">' . $content . '</div>';
		}
		echo '</div>';
		echo '</div>';
	}
}
