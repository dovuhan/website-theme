<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class FeaturedPost extends Widget_Base {


	public function get_name() {
		return 'iori-blog-featured';
	}

	public function get_title() {
		return esc_html__( 'Featured Post', 'iori' );
	}

	public function get_icon() {
		return 'eicon-post-content d-icon';    // eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'blog', 'post', 'iori', 'featured' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/
	// public function get_script_depends() {		//load the dependent scripts defined in the iori-elements.php
	// return [ 'section-header' ];
	// }

	protected function register_controls() {
		// main blog post terms
		$blog_two_terms     = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => false,
			)
		);
		$blog_two_cat_names = array();
		foreach ( $blog_two_terms as $t ) :
			$blog_two_cat_names[ $t->term_id ] = $t->name;
		endforeach;

		// start of a control box
		$this->start_controls_section(
			'blog_post_content',
			array(
				'label' => esc_html__( 'Blog Post', 'iori' ),
			)
		);

		$this->add_control(
			'show_post_by',
			array(
				'label'   => __( 'By Category', 'iori' ),
				'type'    => Controls_Manager::SWITCHER,
			)
		);

		$this->add_control(
			'cat_name',
			array(
				'label'     => __( 'From Category', 'iori' ),
				'type'      => Controls_Manager::SELECT,
				'condition' => array(
					'show_post_by' => 'yes',
				),
				'default'   => 'uncategorized',
				'options'   => $blog_two_cat_names,
			)
		);


		$this->add_control(
			'show_post_by_id',
			array(
				'label'     => __( 'Post By ID', 'iori' ),
				'type'      => Controls_Manager::TEXT,
				'desc'      => 'ID should be numaric and with comma',
				'condition' => array(
					'show_post_by!' => 'yes',
				),
			)
		);

		$this->add_control(
			'show_post',
			array(
				'label'     => __( 'Number Of Post Show', 'iori' ),
				'type'      => Controls_Manager::NUMBER,
				'condition' => array(
					'show_post_by' => 'yes',
				),
				'default'   => 1,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'blog_two_title_style',
			array(
				'label' => esc_html__( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'blog_two_title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#404040',
				'selectors' => array(
					'{{WRAPPER}} .card-blog-grid-2 .blog_two_title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'blog_two_title_typography',
				'selector' => '{{WRAPPER}} .card-blog-grid-2 .blog_two_title'
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'blog_two_desc_style',
			array(
				'label' => esc_html__( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'word_show_post',
			array(
				'label'   => __( 'Word Show', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 145,
			)
		);

		$this->add_control(
			'blog_two_desc_color',
			array(
				'label'     => esc_html__( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .card-blog-grid-2 .blog_two_desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'blog_two_desc_typography',
				'selector' => '{{WRAPPER}} .card-blog-grid-2 .blog_two_desc'
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		// to show on the fontend
		$settings = $this->get_settings_for_display();

		$column_no       = 'col-xl-3 col-lg-6 col-md-6';
		$show_post_by_id = $settings['show_post_by_id'];

		if ( $settings['show_post_by'] == true ) {
			$blog_two = array(
				'cat'                 => $settings['cat_name'],
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'posts_per_page'      => $settings['show_post'],
				'ignore_sticky_posts' => 1,
			);
		} else {
			$post_ids = explode( ',', $show_post_by_id );
			// Convert the values to integers
			$post_ids = array_map( 'intval', $post_ids );

			$blog_two = array(
				'post__in'            => $post_ids,
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'ignore_sticky_posts' => 1,
			);
		}

		$blog_two_query = new \WP_Query( $blog_two );
		if ( $blog_two_query->have_posts() ) :
			while ( $blog_two_query->have_posts() ) :
				$blog_two_query->the_post();

				$cat_names = get_the_category();
				$cat_name  = $cat_names[0]->cat_name;

				?>
		<div class="col-lg-12 mb-60 item-article featured wow animate__ animate__fadeIn animated" data-wow-delay=".0s" style="visibility: visible; animation-delay: 0s; animation-name: fadeIn;">
			<div class="item-1">
				<div class="box-cover-border">
					<div class="row align-items-center">
						<?php if ( has_post_thumbnail() ) { ?>
						<div class="col-lg-6">
							<a href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail(); ?>
							</a>
						</div>
						<?php } ?>

						<div class="col-lg-6">
							<div class="box-info-video"><span class="btn btn-tag"><?php esc_html_e( 'Featured', 'iori' ); ?></span><a href="<?php the_permalink(); ?>">
								<h3 class="color-brand-1 mt-15 mb-20"><?php the_title(); ?></h3></a>
								<div class="mb-25 mt-10"><span class="font-xs-color-grey-500"><?php echo get_the_date(); ?></span><span class="font-xs-color-grey-500 icon-read"><?php echo function_exists( 'iori_reading_time' ) ? iori_reading_time() : ''; ?></span></div>
								<p class="font-md color-grey-500">
								<?php echo $this->the_excerpt_max_charlength( $settings['word_show_post'] ); ?>
								</p>
								<div class="box-button text-start mt-45">
									<a class="btn btn-default font-sm-bold pl-0 hover-up" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'iori' ); ?>
									<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
									</svg>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
			  
			<?php endwhile; ?>
			<?php
		endif;
		wp_reset_postdata();
		?>


			<?php
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				?>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" integrity="sha512-16esztaSRplJROstbIIdwX3N97V1+pZvV33ABoG1H2OyTttBxEGkTsoIVsiP1iaTtM8b3+hu2kB6pQ4Clr5yug==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
			<script>
				//Image amination 1
				const imgOptions2 = {
					root: null,
					rootMargin: "0px",
					threshold: 0.9
				};

				let ImgRevealCallback2 = (entries, self) => {
					entries.forEach((entry) => {
						let container = entry.target;
						let img = entry.target.querySelector("img");
						const easeInOut = "power3.out";
						const revealAnim = gsap.timeline({
							ease: easeInOut
						});

						if (entry.isIntersecting) {
							revealAnim.set(container, {
								visibility: "visible"
							});
							revealAnim.fromTo(
								container, {
									clipPath: "polygon(0 0, 0 0, 0 100%, 0% 100%)",
									webkitClipPath: "polygon(0 0, 0 0, 0 100%, 0% 100%)"
								}, {
									clipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
									webkitClipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
									duration: 1,
									ease: easeInOut
								}
							);
							revealAnim.from(img, 4, {
								scale: 1.4,
								ease: easeInOut,
								delay: -1
							});
							self.unobserve(entry.target);
						}
					});
				};

				let ImRevealObserver2 = new IntersectionObserver(ImgRevealCallback2, imgOptions2);

				document.querySelectorAll(".img-reveal").forEach((reveal) => {
					ImRevealObserver2.observe(reveal);
				});
			</script>

				<?php
			}
	}

	public function the_excerpt_max_charlength( $charlength ) {
		$excerpt = get_the_excerpt();
		$charlength++;

		if ( mb_strlen( $excerpt ) > $charlength ) {
			$subex   = mb_substr( $excerpt, 0, $charlength - 5 );
			$exwords = explode( ' ', $subex );
			$excut   = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
			if ( $excut < 0 ) {
				echo mb_substr( $subex, 0, $excut );
			} else {
				echo $subex;
			}
			echo '';
		} else {
			echo $excerpt;
		}
	}
}
