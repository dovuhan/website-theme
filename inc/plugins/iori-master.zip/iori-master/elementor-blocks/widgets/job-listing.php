<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Job Listing
 *
 * @since 1.0.0
 */

class Job_Listing extends Widget_Base {


	public function get_name() {
		return 'iori-job-listing';
	}

	public function get_title() {
		return esc_html__( 'Job Listing', 'iori' );
	}

	public function get_icon() {
		return 'eicon-post-list d-icon';    // eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'job', 'job-listing', 'post', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/
	// public function get_script_depends() {		//load the dependent scripts defined in the iori-elements.php
	// return [ 'section-header' ];
	// }

	protected function register_controls() {
		// main blog post terms
		$job_listing_terms = get_terms(
			array(
				'taxonomy'   => 'job_listing_tax',
				'hide_empty' => false,
			)
		);

		$job_listing_cat_names = array();

		foreach ( $job_listing_terms as $t ) :
			$job_listing_cat_names[ $t->term_id ] = $t->name;
		endforeach;

		// start of a control box
		$this->start_controls_section(
			'blog_post_content',
			array(
				'label' => esc_html__( 'Job Post Listing', 'iori' ),
			)
		);

		$this->add_control(
			'add_new_item',
			array(
				'label'   => __( 'From Category', 'iori' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'collaborative',
				'options' => $job_listing_cat_names,
			)
		);

		$this->add_control(
			'show_post',
			array(
				'label'   => __( 'Number Of Post Show', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
			)
		);

		$this->add_control(
			'learn_more_btn',
			array(
				'label'       => esc_html__( 'Learn more', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'job_listing_title_style',
			array(
				'label' => esc_html__( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'job_listing_title_color',
			array(
				'label'     => esc_html__( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .title a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'job_listing_title_typography',
				'selector' => '{{WRAPPER}} .card-info .title a'
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'job_listing_content_style',
			array(
				'label' => esc_html__( 'Content', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'job_listing_content_color',
			array(
				'label'     => esc_html__( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#444',
				'selectors' => array(
					'{{WRAPPER}} .card-info .content' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'job_listing_content_typography',
				'selector' => '{{WRAPPER}} .card-info .content'
			)
		);

		$this->add_control(
			'word_show_post',
			array(
				'label'   => __( 'Word Show', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 145,
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		// to show on the fontend
		$settings = $this->get_settings_for_display();

		$column_no = 'col-lg-6';

		?>
		<section class="section">
			<div class="container">
				<div class="row mt-50">

					<?php
					$job_listing_blog = array(
						'term'                 => $settings['add_new_item'],
						'post_type'           => 'job_listing',
						'post_status'         => 'publish',
						'posts_per_page'      => $settings['show_post'],
						'ignore_sticky_posts' => 1,
					);

					$job_listing_query = new \WP_Query( $job_listing_blog );
					if ( $job_listing_query->have_posts() ) :
						while ( $job_listing_query->have_posts() ) :
							$job_listing_query->the_post();
							?>

							<div class="<?php echo esc_attr( $column_no ); ?> wow animate__animated animate__fadeIn" data-wow-delay=".0s">
								<div class="card-offer card-we-do hover-up">
									<div class="card-image">
										<?php if ( has_post_thumbnail() ) { ?>
											<?php iori_post_thumbnail(); ?>
										<?php } ?>
									</div>
									<div class="card-info">
										<h4 class="title mb-10">
											<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
										</h4>
										<p class="content mb-5">
											<?php echo $this->the_excerpt_max_charlength( $settings['word_show_post'] ); ?>
										</p>
										<div class="box-button-offer">
											<a href="<?php echo the_permalink(); ?>" class="btn btn-default font-sm-bold pl-0 color-brand-1"><?php echo esc_html( $settings['learn_more_btn'] ); ?>
												<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
												</svg>
											</a>
										</div>
									</div>
								</div>
							</div>

						<?php endwhile; ?>
						<?php
					endif;
					wp_reset_postdata();
					?>

				</div>
			</div>
		</section>

		<?php
	}

	public function the_excerpt_max_charlength( $charlength ) {
		$excerpt = get_the_excerpt();
		$charlength++;

		if ( mb_strlen( $excerpt ) > $charlength ) {
			$subex   = mb_substr( $excerpt, 0, $charlength - 5 );
			$exwords = explode( ' ', $subex );
			$excut   = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
			if ( $excut < 0 ) {
				echo mb_substr( $subex, 0, $excut );
			} else {
				echo $subex;
			}
			echo '';
		} else {
			echo $excerpt;
		}
	}
}
