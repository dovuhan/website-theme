<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Exit if accessed directly

/**
 * App Reviews
 *
 * Elementor app Reviews
 *
 * @since 1.0.0
 */
class Reviews extends Widget_Base {


	public function get_name() {
		return 'iori-reviews';
	}

	public function get_title() {
		return __( 'Reviews', 'Iori' );
	}

	public function get_icon() {
		return 'eicon-review d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'comment', 'reviews', 'iori' );
	}

	/**
	 * Register image carousel widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'reviews_section',
			array(
				'label' => __( 'Reviews', 'iori' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'reviews_author_img',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'reviews_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'reviews_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'reviews_rating_star',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'reviews_rating',
			array(
				'label'   => 'Rating',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 1,
				'max'     => 5,
				'step'    => 1,
			)
		);

		$this->add_control(
			'reviews_list',
			array(
				'label'   => __( 'Reviews', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'reviews_author_img'        => '',
						'reviews_title'             => '',
						'reviews_desc'              => '',
						'reviews_rating_star'       => '',
						'reviews_rating'            => '',
					),
					array(
						'reviews_author_img'        => '',
						'reviews_title'             => '',
						'reviews_desc'              => '',
						'reviews_rating_star'       => '',
						'reviews_rating'            => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// =========== reviews style start ===========
		// main box style
		$this->start_controls_section(
			'reviews_main_box_style',
			array(
				'label' => __( 'Main Box Style', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'reviews_main_box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-charts .item-chart-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'reviews_main_box_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .box-charts .item-chart-inner' => 'background-color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .box-charts .item-chart-inner',
			)
		);

		$this->add_responsive_control(
			'reviews_main_box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .box-charts .item-chart-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important;',
				),
			)
		);

		$this->end_controls_section();

		// inner box style
		$this->start_controls_section(
			'reviews_inner_box_style',
			array(
				'label' => __( 'Inner Box Style', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'reviews_inner_box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .card-comment' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'reviews_inner_box_bg_color',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-comment' => 'background-color: {{VALUE}};',
				),
				
			)
		);

		$this->add_responsive_control(
			'reviews_inner_box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .card-comment' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important;',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'reviews_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'reviews_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-comment .card-title .title-comment' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'reviews_title_typography',
				
				'selector' => '{{WRAPPER}} .card-comment .card-title .title-comment',
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'reviews_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'reviews_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-comment .desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'reviews_desc_typography',
				
				'selector' => '{{WRAPPER}} .card-comment .desc',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render image carousel widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( empty( $settings['reviews_list'] ) ) {
			return;
		}
		$reviews_lists = $settings['reviews_list'];

		$column_no = 'col-lg-6';

		?>
		<div class="box-charts">
			<div class="box-reviews">
				<div class="item-chart-inner">
					<div class="row">
						<?php
						foreach ( $reviews_lists as $reviews_list ) {
							?>
							<div class="<?php echo esc_attr( $column_no ); ?> mb-20 wow animate__animated animate__fadeIn" data-wow-delay=".2s">
								<div class="card-comment">
									<div class="card-image">
										<img src="<?php echo $reviews_list['reviews_author_img']['url']; ?>" alt="iori">
									</div>
									<div class="card-info">
										<div class="card-title">
											<span class="title title-comment"><?php echo esc_html( $reviews_list['reviews_title'] ); ?></span>
											<div class="rating">
												<?php
												$author_rating = intval( $reviews_list['reviews_rating'] );
												for ( $i = 1; $i <= $author_rating; $i++ ) {
													echo '<img src="' . $reviews_list['reviews_rating_star']['url'] . '">';
												}
												?>
											</div>
										</div>
										<div class="desc"><?php echo $reviews_list['reviews_desc']; ?></div>
									</div>
								</div>
							</div>
							<?php
						}
						?>
					</div>
				</div>
			</div>
		</div>

		<?php

	}
}
