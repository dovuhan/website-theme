<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for video popup two
 *
 * @since 1.0.0
 */

class Video_Popup_Two extends Widget_Base {


	public function get_name() {
		return 'iori-video-popup-two';
	}

	public function get_title() {
		return 'Video Popup Two';
	}

	public function get_icon() {
		return 'eicon-video-playlist d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'video', 'popup', 'video-popup' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.0
	 **/
	protected function register_controls() {
		// ========= Start Content Section =========

		$this->start_controls_section(
			'video_popup_two_section',
			array(
				'label' => esc_html__( 'Video Popup Two', 'iori' ),
			)
		);

		$this->add_control(
			'video_popup_two_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => array(
					'active' => true,
				),
				'placeholder' => __( 'https://your-link.com', 'iori' ),
			)
		);

		$this->add_control(
			'video_popup_two_img',
			array(
				'label'       => esc_html__( 'Upload Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the html.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="item-video wow animate__animated animate__fadeIn" data-wow-delay=".0s">
			<a class="btn btn-play-center popup-youtube" href="<?php echo esc_url( $settings['video_popup_two_link']['url'] ); ?>"></a>
			<img class="bd-rd4" src="<?php echo $settings['video_popup_two_img']['url']; ?>" alt="iori">
		</div>

		<?php

	}
}
