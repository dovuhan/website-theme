<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Card Five
 *
 * @since 1.0.0
 */

class Card_Five extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-card-five';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Card Five', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-menu-card d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'card', 'five', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'card_five_section',
			array(
				'label' => __( 'Card Five', 'iori' ),
			)
		);

		$this->add_control(
			'card_five_img',
			array(
				'label'       => __( 'Image', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
			)
		);

		$this->add_control(
			'card_five_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'card_five_desc',
			array(
				'label'       => __( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'card_five_btn',
			array(
				'label'       => __( 'Button', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$this->add_control(
			'card_five_btn_link',
			array(
				'label'       => __( 'Link', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#',
			)
		);


		$this->end_controls_section();

		// start style here

		// card style
		$this->start_controls_section(
			'card_five_option_style',
			array(
				'label' => __( 'Card Option', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_five_option_border_width',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'range'      => array(
					'px' => array(
						'max' => 20,
					),
					'em' => array(
						'max' => 2,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .card-offer' => 'border-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_five_option_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-offer' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_five_option_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .card-offer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_five_option_shadow',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .card-offer',
			)
		);

		$this->add_control(
			'card_five_option_bg',
			array(
				'label'     => esc_html__( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-offer' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		// card-image style
		$this->start_controls_section(
			'card_five_image_style',
			array(
				'label' => __( 'Card Image', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'card_five_image_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .card-offer-style-2 .card-offer .card-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_five_image_shadow',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .card-offer-style-2 .card-offer .card-image',
			)
		);

		$this->add_control(
			'card_five_image_bg',
			array(
				'label'     => esc_html__( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-offer-style-2 .card-offer .card-image' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		// title
		$this->start_controls_section(
			'card_five_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'card_five_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-offer .card_five_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_five_title_typography',
				'selector' => '{{WRAPPER}} .card-offer .card_five_title',
				
			)
		);

		$this->end_controls_section();

		// description
		$this->start_controls_section(
			'card_five_desc_style',
			array(
				'label' => __( 'Description', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'card_five_desc_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-offer .card_five_desc' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_five_desc_typography',
				'selector' => '{{WRAPPER}} .card-offer .card_five_desc',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="card-offer-style-2 wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
			<div class="card-offer hover-up">
				<div class="card-image"><img src="<?php echo esc_url( $settings['card_five_img']['url'] ); ?>" alt="iori"></div>
				<div class="card-info">
					<h4 class="card_five_title mb-15"><?php echo esc_html( $settings['card_five_title'] ); ?></h4>
					<div class="card_five_desc mb-15"><?php echo $settings['card_five_desc']; ?></div>
					<div class="box-button-offer"><a href="<?php echo esc_url( $settings['card_five_btn_link'] ); ?>" class="btn btn-default font-sm-bold pl-0 color-brand-1"><?php echo esc_html( $settings['card_five_btn'] ); ?>
							<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
								<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
							</svg>
						</a>
					</div>
				</div>
			</div>
		</div>

		<?php
	}
}
