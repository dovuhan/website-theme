<?php

namespace Iori\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Exit if accessed directly

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class Logo extends Widget_Base {


	public function get_name() {
		return 'iori_logo';
	}

	public function get_title() {
		return 'Logo'; // title to show on iori
	}

	public function get_icon() {
		return 'eicon-site-logo d-icon'; // eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return array( 'iori-master-elements' ); // category of the widget
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since  2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'logo', 'header', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/
	// public function get_script_depends() {        //load the dependent scripts defined in the iori-elements.php
	// return [ 'section-header' ];
	// }

	protected function register_controls() { 
		// start of a control box
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Section Settings', 'iori' ), // section name for controler view
			)
		);

		$this->add_control(
			'banner_bg_img',
			array(
				'label'       => esc_html__( 'Upload Logo', 'iori' ),
				'type'        => Controls_Manager::MEDIA,
				'default'     => array(
					'url' => get_template_directory_uri() . '/assets/images/logo.png',
				),
				'label_block' => true,
			)
		);

		$this->add_control(
			'logo_text',
			array(
				'label'       => esc_html__( 'Logo Text', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'banner_desc',
			array(
				'label'       => esc_html__( 'Description', 'iori' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_responsive_control(
			'align',
			array(
				'label'     => __( 'Alignment', 'iori' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'    => array(
						'title' => __( 'Left', 'iori' ),
						'icon'  => 'fa fa-align-left',
					),
					'center'  => array(
						'title' => __( 'Center', 'iori' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'   => array(
						'title' => __( 'Right', 'iori' ),
						'icon'  => 'fa fa-align-right',
					),
					'justify' => array(
						'title' => __( 'Justified', 'iori' ),
						'icon'  => 'fa fa-align-justify',
					),
				),
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
		// End  of a control box

		$this->start_controls_section(
			'section_social_style',
			array(
				'label' => __( 'Logo Style', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$logo_spacing = 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: {{SIZE}}{{UNIT}};';

		$this->add_responsive_control(
			'logo_spacing',
			array(
				'label'     => __( 'Spacing', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 300,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .iori-logo-img' => $logo_spacing,
				),
			)
		);

		$logo_size = 'width: {{SIZE}}{{UNIT}}; height: auto;';

		$this->add_responsive_control(
			'logo_size',
			array(
				'label'     => __( 'Logo Size', 'iori' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 300,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .iori-logo-img' => $logo_size,
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			array(
				'label' => __( 'Content', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => 'title_typography',
				'fields_options' => array(

					'font_family' => array(
						'default' => 'Roboto',
					),

				),
				'selector'       => '{{WRAPPER}} .iori-logo-desc, {{WRAPPER}} .iori-logo-desc p',
			)
		);

		$this->end_controls_section();
	}

	// end of control box

	/**
	 * Render function.
	 *
	 * @return mix
	 */
	protected function render() {
		// to show on the fontend
		$settings      = $this->get_settings_for_display();
		$banner_bg_img = $settings['banner_bg_img']['url'];
		$this->add_inline_editing_attributes( 'banner_desc' );
		$this->add_inline_editing_attributes( 'logo_text' );

		$editor_content = $this->get_settings_for_display( 'banner_desc' );
		$editor_content = $this->parse_text_editor( $editor_content );
		$this->add_inline_editing_attributes( 'banner_desc' );
		$this->add_render_attribute( 'banner_desc', 'class', 'p-lg' );

		?>
		<div class="iori-logo-info p-right-30">
			<div class="logo-block">
				<div class="d-flex align-items-center">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<?php if ( ! empty( $banner_bg_img ) ) { ?>
							<img class="iori-logo-img lazyestload" src="<?php echo esc_url( $banner_bg_img ); ?>" alt="footer-logo">
						<?php } else { ?>
							<?php if ( ! empty( $settings['logo_text'] ) ) { ?>
								<span><?php echo esc_html( $settings['logo_text'] ); ?></span>
							<?php } ?>
						<?php } ?>
					</a>
				</div>
			</div>
			<?php if ( ! empty( $settings['banner_desc'] ) ) { ?>
				<!-- Text -->
				<div class="iori-logo-desc">
					<?php echo wpautop( $editor_content ); ?>
				</div>
			<?php } ?>
		</div>
		<?php
	}

	/**
	 * Render heading widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to
	 * generate the live preview.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function content_template() {         
		?>
		<# var desc=settings.banner_desc; var side_img=settings.banner_bg_img.url; view.addInlineEditingAttributes( 'desc' ); view.addInlineEditingAttributes( 'settings.logo_text' ); #>
			<div class="iori-logo-info p-right-30 m-bottom-40">

				<div class="hero-app-logo">
					<div class="d-flex align-items-center">
						<img class="iori-logo-img" src="{{{ side_img }}}" alt="footer-logo">
						<# if(settings.logo_text !='' ) { #>
							<span>{{{settings.logo_text}}}</span>
							<# } #>
					</div>
				</div>
				<!-- Text -->
				<div class="iori-logo-desc">
					{{{ desc }}}
				</div>
			</div>

		<?php
	}
}
