<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for Button
 *
 * @since 1.0.0
 */

class Portfolio extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-button-portfolio';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Portfolio', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'button', 'filter', 'tabs', 'portfolio' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'button_section',
			array(
				'label' => __( 'Portfolio', 'iori' ),
			)
		);

		$this->add_control(
			'portfolio_tab_item_column',
			[
				'label' => __('Columns', 'iori'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'options' => [
					'2' => __('2 Columns', 'iori'),
					'3' => __('3 Columns', 'iori'),
					'4' => __('4 Columns', 'iori'),
				],
				'separator' => 'after'
			]
		);

		$repeater = new Repeater();

        $repeater->add_control(
            'portfolio_tab_type', [
                'label' => __('Tab Type', 'iori'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('all', 'iori'),
                'label_block' => true,
            ]
        );

		$repeater->add_control(
			'portfolio_tab_item_img',
			array(
				'label'   => esc_html__( 'Upload Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);

		$repeater->add_control(
			'portfolio_tab_item_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'portfolio_tab_item_title_url',
			array(
				'label'   => esc_html__( 'Single Post URL', 'iori' ),
				'type'    => Controls_Manager::URL,
			)
		);

		$this->add_control(
            'filter_list',
            [
                'label' => __('Tabs', 'daisy'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'portfolio_tab_type' => '',
                        'portfolio_tab_item_img' => '',
                        'portfolio_tab_item_title'  => '',
                        'portfolio_tab_item_title_url' => '',
                    ],
                    [
                        'portfolio_tab_type' => '',
                        'portfolio_tab_item_img' => '',
                        'portfolio_tab_item_title'  => '',
                        'portfolio_tab_item_title_url' => '',
                    ],
                    [
                        'portfolio_tab_type' => '',
                        'portfolio_tab_item_img' => '',
                        'portfolio_tab_item_title'  => '',
                        'portfolio_tab_item_title_url' => '',
                    ],
                ],
            ]
        );

		$this->end_controls_section();

		// style content here

		// tab button text
		$this->start_controls_section(
			'portfolio_tab_btn_style',
			array(
				'label' => __( 'Tab Button', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'portfolio_tab_btn_styles' );

		$this->start_controls_tab(
			'portfolio_tab_btn_normal',
			array(
				'label' => __( 'Normal', 'iori' ),
			)
		);

		$this->add_control(
			'portfolio_tab_btn_color_normal',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-buttons li a' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_control(
			'portfolio_tab_btn_bg_color_normal',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-buttons li a' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'portfolio_tab_btn_typography_normal',
				'selector' => '{{WRAPPER}} .list-buttons li a',
				
			)
		);

		$this->add_control(
			'portfolio_tab_btn_border_width',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'range'      => array(
					'px' => array(
						'max' => 20,
					),
					'em' => array(
						'max' => 2,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .list-buttons li a' => 'border-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'portfolio_tab_btn_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-buttons li a' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'portfolio_tab_btn_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .list-buttons li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'portfolio_tab_btn_shadow',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .list-buttons li a',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'portfolio_tab_btn_hover',
			array(
				'label' => __( 'Hover', 'iori' ),
			)
		);

		$this->add_control(
			'portfolio_tab_btn_color_hover',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-buttons li a:hover' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_control(
			'portfolio_tab_btn_bg_color_hover',
			array(
				'label'     => __( 'Background', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-buttons li a:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'portfolio_tab_btn_typographyr_hover',
				'selector' => '{{WRAPPER}} .list-buttons li a:hover',
				
			)
		);

		$this->add_control(
			'portfolio_tab_btn_border_width_hover',
			array(
				'label'      => esc_html__( 'Border Width', 'iori' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'range'      => array(
					'px' => array(
						'max' => 20,
					),
					'em' => array(
						'max' => 2,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .list-buttons li a:hover' => 'border-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'portfolio_tab_btn_border_color_hover',
			array(
				'label'     => esc_html__( 'Border Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .list-buttons li a:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'portfolio_tab_btn_border_radius_hover',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .list-buttons li a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'portfolio_tab_btn_shadow_hover',
				'label'    => __( 'Box Shadow', 'iori' ),
				'selector' => '{{WRAPPER}} .list-buttons li a:hover',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		// content title
		$this->start_controls_section(
			'portfolio_tab_content_title_style',
			array(
				'label' => __( 'Content Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'portfolio_tab_content_title_styles' );

		$this->start_controls_tab(
			'portfolio_tab_content_title_normal',
			array(
				'label' => __( 'Normal', 'iori' ),
			)
		);

		$this->add_control(
			'portfolio_tab_content_title_normal_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .color-brand-1' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'portfolio_tab_content_title_normal_typography',
				'selector' => '{{WRAPPER}} .color-brand-1',
				
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'portfolio_tab_content_title_hover',
			array(
				'label' => __( 'Hover', 'iori' ),
			)
		);

		$this->add_control(
			'portfolio_tab_content_title_hover_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .color-brand-1:hover' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'portfolio_tab_content_title_typography',
				'selector' => '{{WRAPPER}} .color-brand-1:hover',
				
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$filter_lists = $settings['filter_list'];
		$tab_columns = $settings['portfolio_tab_item_column'];

		// Collect unique tab types
		$unique_tab_types = [];
		foreach ($filter_lists as $filter_list) {
			$tab_type = $filter_list['portfolio_tab_type'];
			if (!in_array($tab_type, $unique_tab_types)) {
				$unique_tab_types[] = $tab_type;
			}
		}

		// Determine the column class based on the selected value
		$column_class = '';
		switch ($tab_columns) {
			case '2':
				$column_class = 'col-lg-6 col-md-6';
				break;
			case '3':
				$column_class = 'col-lg-4 col-md-6';
				break;
			case '4':
				$column_class = 'col-lg-3 col-md-6';
				break;
			default:
				$column_class = 'col-lg-4 col-md-6';
		}

		?>

		<section class="section">
			<div class="container">
				<div class="tab-titles">
					<ul class="list-buttons">
							<li class="wow animate__animated animate__fadeIn" data-wow-delay=".0s">
								<a href="#" data-type="all" class="active">
									<?php echo __('All', 'iori'); ?>
								</a>
							</li>
						<?php foreach ($unique_tab_types as $index => $tab_type): ?>
							<li class="wow animate__animated animate__fadeIn" data-wow-delay=".<?php echo $index; ?>s">
								<a href="#" data-type="<?php echo esc_attr($tab_type); ?>" class="text-capitalize">
									<?php echo esc_html($tab_type); ?>
								</a>
							</li>
                       <?php endforeach; ?>
					</ul>
				</div>

				<div class="tab-contents row">
					<?php foreach ($filter_lists as $index => $filter_list): ?>
						<div class="tab-content-item <?php echo esc_attr($column_class); ?> <?php echo esc_attr($filter_list['portfolio_tab_type']); ?>" style="<?php echo $index === 0 ? '' : 'display: none;'; ?>">
						  <div class="item-article">
							<div class="card-blog-grid card-blog-grid-3 hover-up">
								<div class="card-image">
									<img src="<?php echo $filter_list['portfolio_tab_item_img']['url']; ?>" alt="iori">
								</div>
								<div class="card-info">
									<a href="<?php echo esc_url($filter_list['portfolio_tab_item_title_url']['url']); ?>">
									<h4 class="color-brand-1">
										<?php echo esc_html( $filter_list['portfolio_tab_item_title'] ); ?>
									</h4>
									</a>
								</div>
							</div>
						  </div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
		
		<script>
			jQuery(document).ready(function($) {
				const $tabs = $('.list-buttons a');
				const $contents = $('.tab-content-item');

				// Initially display all items
				$contents.show();

				$tabs.on('click', function(e) {
					e.preventDefault();
					
					$tabs.removeClass('active');
					$(this).addClass('active');
					
					const type = $(this).data('type');
					
					$contents.each(function() {
						if (type === 'all' || $(this).hasClass(type)) {
							$(this).show();
						} else {
							$(this).hide();
						}
					});
				});
			});
		</script>
	  <?php
	}
}
