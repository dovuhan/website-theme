<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Testimonial
 *
 * Elementor widget for testimoinal
 *
 * @since 1.0.0
 */
class Video_Player extends Widget_Base {


	public function get_name() {
		return 'iori-video-player';
	}

	public function get_title() {
		return esc_html__( 'Video Player', 'iori' );
	}

	public function get_icon() {
		return 'eicon-video-camera d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'video', 'player', 'youtube', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Testimonial Items', 'iori' ),
			)
		);

		$this->add_control(
			'dynamic',
			array(
				'label' => esc_html__( 'Dynamic', 'iori' ),
				'type'  => Controls_Manager::SWITCHER,
			)
		);

		$this->add_control(
			'post_type',
			array(
				'label'     => esc_html__( 'Post Type', 'iori' ),
				'type'      => Controls_Manager::SELECT,
				'condition' => array(
					'dynamic' => 'yes',
				),
				'options'   => array(
					'post'    => 'Post',
					'product' => 'Product',
				),
			)
		);

		$this->add_control(
			'number',
			array(
				'label'     => esc_html__( 'Number of Item', 'iori' ),
				'type'      => Controls_Manager::NUMBER,
				'condition' => array(
					'dynamic' => 'yes',
				),
			)
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'title',
			array(
				'label'   => esc_html__( 'Title', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Jonathan Morgan', 'iori' ),
			)
		);

		$repeater->add_control(
			'designation',
			array(
				'label'   => esc_html__( 'Designation', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Jonathan Morgan', 'iori' ),
			)
		);

		$repeater->add_control(
			'testimoni_image',
			array(
				'label'   => esc_html__( 'Testimonial Image', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => IORI_PLG_URL . 'assets/images/testimonial-demo.jpg',
				),
			)
		);

		$repeater->add_control(
			'testimoni_content_title',
			array(
				'label'   => esc_html__( 'Content Title', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Super Support', 'iori' ),
			)
		);

		$repeater->add_control(
			'testimoni_content',
			array(
				'label'   => esc_html__( 'Description', 'iori' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__(
					'Corem ipsum dolor si amet consectetur adipisic ingelit sed do adipisicido executiv
					sunse pit lore kome.',
					'iori'
				),
			)
		);

		$this->add_control(
			'testimonial_option',
			array(
				'label'       => esc_html__( 'Testimonials Options', 'iori' ),
				'type'        => Controls_Manager::REPEATER,
				'show_label'  => true,
				'condition'   => array(
					'dynamic!' => 'yes',
				),
				'default'     => array(
					array(
						'title'                   => esc_html__( 'Jonathan Morgan', 'iori' ),
						'designation'             => esc_html__( 'Marketting', 'iori' ),
						'testimoni_content_title' => 'Super Support',
						'testimoni_content'       => 'Enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo conse quat. Duis aute irure dolor in reprehenderit in voluptate.',
						'testimoni_image'         => array(
							'url' => IORI_PLG_URL . 'assets/images/review-author-1.jpg',
						),
					),
					array(
						'title'                   => esc_html__( 'Harsul Hisham', 'iori' ),
						'designation'             => esc_html__( 'Engineer', 'iori' ),
						'testimoni_content_title' => 'What a theme!',
						'testimoni_content'       => 'Enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo conse quat. Duis aute irure dolor in reprehenderit in voluptate.',
						'testimoni_image'         => array(
							'url' => IORI_PLG_URL . 'assets/images/review-author-2.jpg',
						),
					),
					array(
						'title'                   => esc_html__( 'Teem Southy', 'iori' ),
						'designation'             => esc_html__( 'Developer', 'iori' ),
						'testimoni_content_title' => 'Outstanding Support',
						'testimoni_content'       => 'Enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo conse quat. Duis aute irure dolor in reprehenderit in voluptate.',
						'testimoni_image'         => array(
							'url' => IORI_PLG_URL . 'assets/images/review-author-3.jpg',
						),
					),
					array(
						'title'                   => esc_html__( 'Harsul Hisham', 'iori' ),
						'designation'             => esc_html__( 'Engineer', 'iori' ),
						'testimoni_content_title' => 'Happy!!',
						'testimoni_content'       => 'Enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo conse quat. Duis aute irure dolor in reprehenderit in voluptate.',
						'testimoni_image'         => array(
							'url' => IORI_PLG_URL . 'assets/images/review-author-4.jpg',
						),
					),
					array(
						'title'                   => esc_html__( 'Jake Margin', 'iori' ),
						'designation'             => esc_html__( 'Marketing', 'iori' ),
						'testimoni_content_title' => 'Nice Person',
						'testimoni_content'       => 'Enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo conse quat. Duis aute irure dolor in reprehenderit in voluptate.',
						'testimoni_image'         => array(
							'url' => IORI_PLG_URL . 'assets/images/review-author-5.jpg',
						),
					),
				),
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{title}}}',
			)
		);

		$this->end_controls_section();

		// Content options End
		$this->start_controls_section(
			'layout_style',
			array(
				'label' => esc_html__( 'Layout', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'testimonial_style',
			array(
				'label'   => esc_html__( 'Display Style', 'iori' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '3',
				'options' => array(
					'1' => esc_html__( 'Style 1', 'iori' ),
					'2' => esc_html__( 'Style 2', 'iori' ),
				),
			)
		);

		$this->add_control(
			'testimonial_items',
			array(
				'label'   => esc_html__( 'Items Shows', 'iori' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '3',
				'options' => array(
					'1' => esc_html__( 'Item 1', 'iori' ),
					'2' => esc_html__( 'Item 2', 'iori' ),
					'3' => esc_html__( 'Item 3', 'iori' ),
				),
			)
		);

		$this->add_control(
			'layout_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => array(
					'{{WRAPPER}} .st-testimonial' => 'background-color: {{VALUE}};',

				),
			)
		);

		$this->add_control(
			'autoplay_enable',
			array(
				'label'   => esc_html__( 'Auto Play Enable/Disable', 'iori' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'yes'     => esc_html__( 'True', 'iori' ),
				'no'      => esc_html__( 'False', 'iori' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			array(
				'label' => esc_html__( 'Content', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Title Typography', 'iori' ),
				'selector' => '{{WRAPPER}} .st-testimonial .playfair-display',
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#676767',
				'selectors' => array(
					'{{WRAPPER}} .st-testimonial .playfair-display' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_typography',
				'label'    => esc_html__( 'Content Typography', 'iori' ),
				'selector' => '{{WRAPPER}} .st-testimonial p',
			)
		);

		$this->add_control(
			'testimoni_color',
			array(
				'label'     => esc_html__( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#676767',
				'selectors' => array(
					'{{WRAPPER}} .st-testimonial p' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_name',
			array(
				'label' => esc_html__( 'Name/Designation', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'name_color',
			array(
				'label'     => esc_html__( 'Name Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#182432',
				'selectors' => array(
					'{{WRAPPER}} .testimonial-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'name_typography',
				'label'    => esc_html__( 'Name Typography', 'iori' ),
				'selector' => '{{WRAPPER}} .testimonial-name',
			)
		);

		$this->add_control(
			'designation_color',
			array(
				'label'     => esc_html__( 'Designation Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#989898',
				'selectors' => array(
					'{{WRAPPER}}  .testimonial-position' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'designation_typography',
				'label'    => esc_html__( 'Designation Typography', 'iori' ),
				'selector' => '{{WRAPPER}} .testimonial-position',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="box-button-video wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
			<a class="btn btn-play font-sm-bold popup-youtube hover-up" href="https://www.youtube.com/watch?v=sVPYIRF9RCQ">Play Video</a>
		</div>

		<?php
	}
}
