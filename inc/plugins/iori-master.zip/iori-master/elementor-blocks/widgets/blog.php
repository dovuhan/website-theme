<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for header
 *
 * @since 1.0.0
 */

class Blog extends Widget_Base {


	public function get_name() {
		return 'iori-blog';
	}

	public function get_title() {
		return esc_html__( 'Grid Blog', 'iori' );
	}

	public function get_icon() {
		return 'eicon-post-content d-icon';    // eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'blog', 'post', 'iori', 'grid' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/
	// public function get_script_depends() {		//load the dependent scripts defined in the iori-elements.php
	// return [ 'section-header' ];
	// }

	protected function register_controls() {
		// main blog post terms
		$terms     = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => false,
			)
		);
		$cat_names = array();
		foreach ( $terms as $t ) :
			$cat_names[ $t->term_id ] = $t->name;
		endforeach;

		// sidebar post terms
		$sidebar_terms     = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => false,
			)
		);
		$sidebar_cat_names = array();
		foreach ( $sidebar_terms as $t ) :
			$sidebar_cat_names[ $t->term_id ] = $t->name;
		endforeach;


		// start of a control box
		$this->start_controls_section(
			'blog_post_content',
			array(
				'label' => esc_html__( 'Post Layout', 'iori' ),
			)
		);


		$this->add_control(
			'show_post_by',
			array(
				'label'   => __( 'By Category', 'iori' ),
				'type'    => Controls_Manager::SWITCHER,
			)
		);

		$this->add_control(
			'cat_name',
			array(
				'label'     => __( 'From Category', 'iori' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'uncategorized',
				'condition' => array(
					'show_post_by' => 'yes',
				),
				'options'   => $cat_names,
			)
		);

		$this->add_control(
			'show_post',
			array(
				'label'   => __( 'Number Of Post Show', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
			)
		);

		$this->add_control(
			'learn_more_btn',
			array(
				'label'       => esc_html__( 'Learn more', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'iori' ),
			)
		);


		$this->end_controls_section();

		// start of a control box
		$this->start_controls_section(
			'sidebar_blog_post_content',
			array(
				'label' => esc_html__( 'Sidebar Post Layout', 'iori' ),
			)
		);

		$this->add_control(
			'sidebar_cat_name',
			array(
				'label'   => __( 'From Category', 'iori' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'uncategorized',
				'options' => $sidebar_cat_names,
			)
		);

		$this->add_control(
			'sidebar_show_post',
			array(
				'label'   => __( 'Number Of Post Show', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
			)
		);

	


		$this->end_controls_section();


		$this->start_controls_section(
			'section_title',
			array(
				'label' => esc_html__( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .card-info .title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .card-info .title'
			)
		);

		$this->add_responsive_control(
			'title_space',
			array(
				'label'      => esc_html__( 'Title Spacing', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .card-info .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_style',
			array(
				'label' => esc_html__( 'Content', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'word_show_post',
			array(
				'label'   => __( 'Word Show', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 145,
			)
		);

		$this->add_control(
			'content_color',
			array(
				'label'     => esc_html__( 'Content Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#444',
				'selectors' => array(
					'{{WRAPPER}} .card-info .desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .card-info .desc'
			)
		);

		$this->add_responsive_control(
			'content_space',
			array(
				'label'      => esc_html__( 'Content Spacing', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .card-info .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'content_show',
			array(
				'label' => __( 'Show', 'iori' ),
				'type'  => Controls_Manager::SWITCHER,
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		// to show on the fontend
		$settings = $this->get_settings_for_display();

		$column_no = 'col-lg-4 col-md-6';

		?>

		<section class="section">
			<div class="container">
				<div class="row">

					<?php
					if ( $settings['show_post_by'] == 'yes' ) {
						$blog = array(
							'cat'                 => $settings['cat_name'],
							'post_type'           => 'post',
							'post_status'         => 'publish',
							'posts_per_page'      => $settings['show_post'],
							'ignore_sticky_posts' => 1,
						);
					} else {
						$blog = array(
							'post_type'           => 'post',
							'post_status'         => 'publish',
							'posts_per_page'      => $settings['show_post'],
							'ignore_sticky_posts' => 1,
						);
					}

					$blog_query = new \WP_Query( $blog );
					if ( $blog_query->have_posts() ) :
						while ( $blog_query->have_posts() ) :
							$blog_query->the_post();
							?>

							<div class="<?php echo esc_attr( $column_no ); ?> wow animate__animated animate__fadeInUp" data-wow-delay=".0s">
								<div class="card-blog-grid hover-up mt-lg-2">
									<div class="card-image">
										<a href="<?php the_permalink(); ?>">
											<?php if ( has_post_thumbnail() ) { ?>
												<?php iori_post_thumbnail(); ?>
											<?php } ?>
										</a>
									</div>
									<div class="card-info">
										<a href="<?php the_permalink(); ?>">
											<h4 class="title"><?php the_title(); ?></h4>
										</a>
										<div class="mt-20"><span class="date-post font-xs color-grey-300">
												<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
												</svg><?php echo get_the_date(); ?></span><span class="time-read font-xs color-grey-300">
												<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
												</svg><?php echo iori_reading_time(); ?></span></div>
										<p class="desc mt-20"><?php echo $this->the_excerpt_max_charlength( $settings['word_show_post'] ); ?></p>
										<div class="mt-20 d-flex">
											<div class="box-author">
												<?php 
												if ( $avatar = get_avatar( get_the_author_meta( 'ID' ) ) !== false && ( ! empty( $avatar ) ) ) :
													?>
													<img src="<?php echo $avatar; ?>" alt="iori">
												<?php endif; ?>
												<div class="author-info"><a href="<?php echo the_permalink(); ?>"><span class="font-md-bold color-brand-1 author-name"><?php echo get_the_author(); ?></span></a>
												</span></div>
											</div>
											<div class="box-button-more text-end">
												<a class="btn btn-default font-sm-bold" href="<?php echo the_permalink(); ?>">
													<?php echo $settings['learn_more_btn']; ?>
													<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
														<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
													</svg>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>

						<?php endwhile; ?>
						<?php
					endif;
					wp_reset_postdata();
					?>

					<div class="col-lg-4">
						<ul class="list-blogs">

							<?php
							$sidebar_blog = array(
								'cat'                 => $settings['sidebar_cat_name'],
								'post_type'           => 'post',
								'post_status'         => 'publish',
								'posts_per_page'      => $settings['sidebar_show_post'],
								'offset'              => -2,
								'ignore_sticky_posts' => 1,
							);

							$sidebar_blog_query = new \WP_Query( $sidebar_blog );
							if ( $sidebar_blog_query->have_posts() ) :
								while ( $sidebar_blog_query->have_posts() ) :
									$sidebar_blog_query->the_post();
									?>

									<li class="wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
										<div class="card-blog-list hover-up">
											<div class="card-info"><a href="<?php echo the_permalink(); ?>">
													<h5 class="title mt-0"><?php the_title(); ?></h5>
												</a>
												<div class="mt-10"><span class="date-post font-xs color-grey-300">
														<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
															<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
														</svg><span><?php echo get_the_date(); ?></span></span>
													<span class="time-read font-xs color-grey-300">
														<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
															<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
														</svg>
														<span><?php echo iori_reading_time(); ?></span>
													</span>
												</div>
											</div>
											<div class="card-image">
											  <a href="<?php the_permalink(); ?>">
												<?php if ( has_post_thumbnail() ) { ?>
													<?php iori_post_thumbnail(); ?>
												<?php } ?>
											  </a>
											</div>
										</div>
									</li>

								<?php endwhile; ?>
								<?php
							endif;
							wp_reset_postdata();
							?>

						</ul>
					</div>
				</div>
			</div>
		</section>


		<?php
	}

	public function the_excerpt_max_charlength( $charlength ) {
		$excerpt = get_the_excerpt();

		if ( mb_strlen( $excerpt ) > $charlength ) {
			$subex   = mb_substr( $excerpt, 0, $charlength - 5 );
			$exwords = explode( ' ', $subex );
			$excut   = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
			if ( $excut < 0 ) {
				echo mb_substr( $subex, 0, $excut );
			} else {
				echo $subex;
			}
			echo '';
		} else {
			echo $excerpt;
		}
	}
}
