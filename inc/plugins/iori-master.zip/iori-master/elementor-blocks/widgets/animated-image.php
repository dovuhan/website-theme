<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Animated Image
 *
 * Elementor widget for Animated Image
 *
 * @since 1.0.0
 */
class Animated_Image extends Widget_Base {


	public function get_name() {
		return 'iori-animated-image';
	}

	public function get_title() {
		return esc_html__( 'Animated Image', 'iori' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry d-icon';
	}

	public function get_categories() {
		return array( 'iori-master-elements' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'animation', 'image', 'picture', 'iori' );
	}

	/**
	 * A list of scripts that the widgets is depended in
	 *
	 * @since 1.3.0
	 **/

	protected function register_controls() { 
		// Content options Start
		$this->start_controls_section(
			'animated_image_section',
			array(
				'label' => esc_html__( 'Animated Image', 'iori' ),
			)
		);

		$this->add_control(
			'animated_image',
			array(
				'label'   => esc_html__( 'Upload', 'iori' ),
				'type'    => Controls_Manager::MEDIA,
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .anim-img-wrap img',
			)
		);

		$this->add_responsive_control(
			'banner_twelve_box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'iori' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .anim-img-wrap img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important;',
				),
			)
		);

		$this->end_controls_section();
		
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
		<div class="anim-img-wrap img-reveal">
			<img class="d-block" src="<?php echo $settings['animated_image']['url']; ?>" alt="iori">
		</div>

		<?php
		if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" integrity="sha512-16esztaSRplJROstbIIdwX3N97V1+pZvV33ABoG1H2OyTttBxEGkTsoIVsiP1iaTtM8b3+hu2kB6pQ4Clr5yug==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
	
//Image amination 1
const imgOptions = {
	root: null,
	rootMargin: "0px",
	threshold: 0.9
  };

let ImgRevealCallback = (entries, self) => {
	entries.forEach((entry) => {
	  let container = entry.target;
	  let img = entry.target.querySelector("img");
	  const easeInOut = "power3.out";
	  const revealAnim = gsap.timeline({ ease: easeInOut });

	  if (entry.isIntersecting) {
		revealAnim.set(container, {
		  visibility: "visible"
		});
		revealAnim.fromTo(
		  container,
		  {
			clipPath: "polygon(0 0, 0 0, 0 100%, 0% 100%)",
			webkitClipPath: "polygon(0 0, 0 0, 0 100%, 0% 100%)"
		  },
		  {
			clipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
			webkitClipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
			duration: 1,
			ease: easeInOut
		  }
		);
		revealAnim.from(img, 4, {
		  scale: 1.4,
		  ease: easeInOut,
		  delay: -1
		});
		self.unobserve(entry.target);
	  }
	});
  };

let ImRevealObserver = new IntersectionObserver(ImgRevealCallback, imgOptions);

document.querySelectorAll(".img-reveal").forEach((reveal) => {
	ImRevealObserver.observe(reveal);
});
</script>
			<?php
		}

	}
}
