<?php

namespace Iori\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Style for counter two
 *
 * @since 1.0.0
 */

class Counter_Two extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve icon box widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'iori-counter-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve icon box widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Counter Two', 'iori' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon box widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter d-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'counter', 'client', 'iori' );
	}

	/**
	 * Get widget cateogory.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {
		return array( 'iori-master-elements' );    // category of the widget
	}

	/**
	 * Register icon box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'counter_two_section',
			array(
				'label' => __( 'Counter Two', 'iori' ),
			)
		);

		$this->add_control(
			'counter_two_title',
			array(
				'label'       => __( 'Title', 'iori' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'counter_two_number',
			array(
				'label'   => __( 'Number', 'iori' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '',
			)
		);

		$repeater->add_control(
			'counter_two_quantity',
			array(
				'label'   => __( 'Quantity', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'counter_two_subject',
			array(
				'label'   => __( 'Subject', 'iori' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'counter_two_list',
			array(
				'label'   => __( 'Counter List', 'iori' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'counter_two_number'   => '',
						'counter_two_quantity' => '',
						'counter_two_subject'  => '',
					),
					array(
						'counter_two_number'   => '',
						'counter_two_quantity' => '',
						'counter_two_subject'  => '',
					),
					array(
						'counter_two_number'   => '',
						'counter_two_quantity' => '',
						'counter_two_subject'  => '',
					),
				),
			)
		);

		$this->end_controls_section();

		// content style start 

		// title
		$this->start_controls_section(
			'counter_two_title_style',
			array(
				'label' => __( 'Title', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_two_title_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .counter_title' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_two_title_typography',
				'selector' => '{{WRAPPER}} .counter_title',
				
			)
		);

		$this->end_controls_section();

		// number
		$this->start_controls_section(
			'counter_two_number_style',
			array(
				'label' => __( 'Number', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_two_number_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .counter_number_content .counter' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_two_number_typography',
				'selector' => '{{WRAPPER}} .counter_number_content .counter',
				
			)
		);

		$this->end_controls_section();


		// quantity
		$this->start_controls_section(
			'counter_two_quantity_style',
			array(
				'label' => __( 'Quantity', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_two_quantity_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .counter_number_content .quantity' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_two_quantity_typography',
				'selector' => '{{WRAPPER}} .counter_number_content .quantity',
				
			)
		);

		$this->end_controls_section();

		// subject
		$this->start_controls_section(
			'counter_two_subject_style',
			array(
				'label' => __( 'Subject', 'iori' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_two_subject_color',
			array(
				'label'     => __( 'Color', 'iori' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subject' => 'color: {{VALUE}};',
				),
				
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'counter_two_subject_typography',
				'selector' => '{{WRAPPER}} .subject',
				
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render team image with detail widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$counter_two_lists = $settings['counter_two_list'];

		$column1 = 'col-xl-4 col-lg-3';
		$column2 = 'col-xl-8 col-lg-9';
		$column3 = 'col-lg-3 col-md-3 col-sm-6 col-6';

		?>

		<section class="section">
			<div class="container">
				<div class="row">
					<div class="<?php echo esc_attr( $column1 ); ?>">
						<h3 class="counter_title mb-20 wow animate__animated animate__fadeIn" data-wow-delay=".0s"><?php echo esc_html( $settings['counter_two_title'] ); ?></h3>
					</div>
					<div class="<?php echo esc_attr( $column2 ); ?>">
						<div class="row">

							<?php
							foreach ( $counter_two_lists as $counter_two_list ) { 
								?>

								<div class="<?php echo esc_attr( $column3 ); ?> text-lg-end text-center mb-20">
									<h2 class="counter_number_content">
										<span class="counter"><?php echo esc_html( $counter_two_list['counter_two_number'] ); ?></span>
										<span class="quantity"><?php echo esc_html( $counter_two_list['counter_two_quantity'] ); ?></span>
									</h2>
									<p class="subject"><?php echo esc_html( $counter_two_list['counter_two_subject'] ); ?></p>
								</div>

								<?php
							} 
							?>

						</div>
					</div>
				</div>

			</div>
			<div class="border-bottom mt-70"></div>
		</section>

		<?php if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
			<script>
				/*---- CounterUp ----*/
				if (jQuery(".count").length) {
					jQuery(".count").counterUp({
						delay: 10,
						time: 600
					});
				}

				if (jQuery(".counter").length) {
					jQuery(".counter").counterUp({
						delay: 10,
						time: 600
					});
				}
			</script>
		<?php } ?>

		<?php
	}
}
