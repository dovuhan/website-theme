<?php
namespace Iori\Elementor\HeaderFooterBuilder;

defined( 'ABSPATH' ) || exit;

class HeaderFooterBuilder_Api {
	public $prefix  = '';
	public $ajax    = '';
	public $param   = '';
	public $request = null;

	public function __construct() {
		$this->config();
		$this->init();
	}

	public function config() {
		$this->prefix = 'my-template';
		$this->ajax   = 'ajaxselect2';
		$this->param  = '/(?P<id>\w+)/';
	}

	public function init() {
		add_action(
			'rest_api_init',
			function () {
				register_rest_route(
					untrailingslashit( 'iori-master/v1/' . $this->prefix ),
					'/(?P<action>\w+)/' . trim( $this->param, '/' ),
					array(
						'methods'             => \WP_REST_Server::ALLMETHODS,
						'callback'            => array( $this, 'callback' ),
						'permission_callback' => '__return_true',
					// all permissions are implimented inside the callback action
					)
				);

				register_rest_route(
					untrailingslashit( 'iori-master/v1/' . $this->ajax ),
					'/(?P<action>\w+)/' . ( '/' ),
					array(
						'methods'             => \WP_REST_Server::ALLMETHODS,
						'callback'            => array( $this, 'callback' ),
						'permission_callback' => '__return_true',
					)
				);
			}
		);
	}

	public function callback( $request ) {
		$this->request = $request;
		$action_class  = strtolower( $this->request->get_method() ) . '_' . $this->request['action'];
		if ( method_exists( $this, $action_class ) ) {
			return $this->{$action_class}();
		}
	}

	public function get_post_list() {

		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		$query_args = array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 15,
		);

		if ( isset( $this->request['ids'] ) ) {
			$ids                    = explode( ',', $this->request['ids'] );
			$query_args['post__in'] = $ids;
		}
		if ( isset( $this->request['s'] ) ) {
			$query_args['s'] = $this->request['s'];
		}

		$query   = new \WP_Query( $query_args );
		$options = array();
		if ( $query->have_posts() ) :
			while ( $query->have_posts() ) {
				$query->the_post();
				$options[] = array(
					'id'   => get_the_ID(),
					'text' => get_the_title(),
				);
			}
		endif;

		return array( 'results' => $options );
		wp_reset_postdata();
	}

	public function get_page_list() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		$query_args = array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 15,
		);

		if ( isset( $this->request['ids'] ) ) {
			$ids                    = explode( ',', $this->request['ids'] );
			$query_args['post__in'] = $ids;
		}
		if ( isset( $this->request['s'] ) ) {
			$query_args['s'] = $this->request['s'];
		}

		$query   = new \WP_Query( $query_args );
		$options = array();
		if ( $query->have_posts() ) :
			while ( $query->have_posts() ) {
				$query->the_post();
				$options[] = array(
					'id'   => get_the_ID(),
					'text' => get_the_title(),
				);
			}
		endif;

		return array( 'results' => $options );
		wp_reset_postdata();
	}

	public function get_singular_list() {
		$query_args = array(
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'post_type'      => 'any',
		);

		if ( isset( $this->request['ids'] ) ) {
			$ids                    = explode( ',', $this->request['ids'] );
			$query_args['post__in'] = $ids;
		}
		if ( isset( $this->request['s'] ) ) {
			$query_args['s'] = $this->request['s'];
		}

		$query   = new \WP_Query( $query_args );
		$options = array();
		if ( $query->have_posts() ) :
			while ( $query->have_posts() ) {
				$query->the_post();
				$options[] = array(
					'id'   => get_the_ID(),
					'text' => get_the_title(),
				);
			}
		endif;

		return array( 'results' => $options );
		wp_reset_postdata();
	}

	public function get_category() {

		$taxonomy   = 'category';
		$query_args = array(
			'taxonomy'   => array( 'category' ), // taxonomy name
			'orderby'    => 'name',
			'order'      => 'DESC',
			'hide_empty' => true,
			'number'     => 10,
		);

		if ( isset( $this->request['ids'] ) ) {
			$ids                   = explode( ',', $this->request['ids'] );
			$query_args['include'] = $ids;
		}
		if ( isset( $this->request['s'] ) ) {
			$query_args['name__like'] = $this->request['s'];
		}

		$terms = get_terms( $query_args );

		$options = array();

		if ( is_countable( $terms ) && count( $terms ) > 0 ) :

			foreach ( $terms as $term ) {
				$options[] = array(
					'id'   => $term->term_id,
					'text' => $term->name,
				);
			}
		endif;
		return array( 'results' => $options );
	}

	public function get_product_list() {
		$query_args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 15,
		);

		if ( isset( $this->request['ids'] ) ) {
			$ids                    = explode( ',', $this->request['ids'] );
			$query_args['post__in'] = $ids;
		}
		if ( isset( $this->request['s'] ) ) {
			$query_args['s'] = $this->request['s'];
		}

		$query   = new \WP_Query( $query_args );
		$options = array();
		if ( $query->have_posts() ) :
			while ( $query->have_posts() ) {
				$query->the_post();
				$options[] = array(
					'id'   => get_the_ID(),
					'text' => get_the_title(),
				);
			}
		endif;

		return array( 'results' => $options );
		wp_reset_postdata();
	}

	public function get_product_cat() {
		$query_args = array(
			'taxonomy'   => array( 'product_cat' ), // taxonomy name
			'orderby'    => 'name',
			'order'      => 'DESC',
			'hide_empty' => false,
			'number'     => 6,
		);

		if ( isset( $this->request['ids'] ) ) {
			$ids                   = explode( ',', $this->request['ids'] );
			$query_args['include'] = $ids;
		}
		if ( isset( $this->request['s'] ) ) {
			$query_args['name__like'] = $this->request['s'];
		}

		$terms = get_terms( $query_args );

		$options = array();

		if ( is_countable( $terms ) && count( $terms ) > 0 ) :
			foreach ( $terms as $term ) {
				$options[] = array(
					'id'   => $term->term_id,
					'text' => $term->name,
				);
			}
		endif;

		return array( 'results' => $options );
	}

	public function get_update() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$id          = $this->request['id'];
		$open_editor = $this->request['open_editor'];

		$title                 = ( $this->request['title'] == '' ) ? ( 'Iori Template #' . time() ) : $this->request['title'];
		$activation            = $this->request['activation'];
		$type                  = $this->request['type'];
		$condition_a           = ( $type == 'section' ) ? '' : $this->request['condition_a'];
		$condition_singular    = ( $type == 'section' ) ? '' : $this->request['condition_singular'];
		$condition_singular_id = ( $type == 'section' ) ? '' : ( is_array( $this->request['condition_singular_id'] ) ? implode( ',', $this->request['condition_singular_id'] ) : $this->request['condition_singular_id'] );

		$post_data = array(
			'post_title'  => $title,
			'post_status' => 'publish',
			'post_type'   => 'iori_template',
		);

		$post = get_post( $id );

		if ( $post == null ) {
			// $post_data['post_author'] = $this->request['post_author'];
			$id = wp_insert_post( $post_data );
		} else {
			$post_data['ID'] = $id;
			wp_update_post( $post_data );
		}

		update_post_meta( $id, '_wp_page_template', 'elementor_canvas' );
		update_post_meta( $id, 'iori_template_activation', $activation );
		update_post_meta( $id, 'iori_template_type', $type );
		update_post_meta( $id, 'iori_template_condition_a', $condition_a );
		update_post_meta( $id, 'iori_template_condition_singular', $condition_singular );
		update_post_meta( $id, 'iori_template_condition_singular_id', $condition_singular_id );

		if ( $open_editor == 'true' ) {
			$url = get_admin_url() . '/post.php?post=' . $builder_post_id . '&action=elementor';
			wp_redirect( $url );
			exit;
		} else {
			$cond = ucwords(
				str_replace(
					'_',
					' ',
					$condition_a
					. ( ( $condition_a == 'singular' )
					? ( ( $condition_singular != '' )
						? ( ' > ' . $condition_singular
						. ( ( $condition_singular_id != '' )
							? ' > ' . $condition_singular_id
							: '' ) )
						: '' )
					: '' )
				)
			);

			return array(
				'saved' => true,
				'data'  => array(
					'id'         => $id,
					'title'      => $title,
					'type'       => $type,
					'activation' => $activation,
					'cond_text'  => $cond,
					'type_html'  => ( ucfirst( $type ) . ( ( $activation == 'yes' )
						? ( '<span class="iori-headerfooter-status iori-headerfooter-status-active">' . esc_html__( 'Active', 'iori' ) . '</span>' )
						: ( '<span class="iori-headerfooter-status iori-headerfooter-status-inactive">' . esc_html__( 'Inactive', 'iori' ) . '</span>' ) ) ),
				),
			);
		}
	}

	public function get_get() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$id   = $this->request['id'];
		$post = get_post( $id );
		if ( $post != null ) {
			return array(
				'title'                 => $post->post_title,
				'status'                => $post->post_status,
				'activation'            => get_post_meta( $post->ID, 'iori_template_activation', true ),
				'type'                  => get_post_meta( $post->ID, 'iori_template_type', true ),
				'condition_a'           => get_post_meta( $post->ID, 'iori_template_condition_a', true ),
				'condition_singular'    => get_post_meta( $post->ID, 'iori_template_condition_singular', true ),
				'condition_singular_id' => get_post_meta( $post->ID, 'iori_template_condition_singular_id', true ),
			);
		}
		return true;
	}
}
new HeaderFooterBuilder_Api();
