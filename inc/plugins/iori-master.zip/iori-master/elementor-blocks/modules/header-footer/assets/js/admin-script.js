jQuery(document).ready(function (t) {
    "use strict";
    function e(e) {
        t(".iori-template-modalinput-title").val(e.title),
            t(".iori-template-modalinput-condition_a").val(e.condition_a),
            t(".iori-template-modalinput-condition_singular").val(e.condition_singular),
            t(".iori-template-modal-condition_singular_id").val(e.condition_singular_id),
            t(".iori-template-modalinput-type").val(e.type);
        var a = t(".iori-template-modalinput-activition");
        "yes" == e.activation ? a.attr("checked", !0) : a.removeAttr("checked"),
            t(".iori-template-modalinput-activition, .iori-template-modalinput-type, .iori-template-modalinput-condition_a, .iori-template-modalinput-condition_singular").trigger("change");
        var i = t(".iori-template-modal-condition_singular_id");
        t.ajax({ url: window.iori.resturl + "ajaxselect2/singular_list", dataType: "json", data: { ids: String(e.condition_singular_id) } }).then(function (e) {
            null !== e &&
                e.results.length > 0 &&
                (i.html(" "),
                    t.each(e.results, function (t, e) {
                        var a = new Option(e.text, e.id, !0, !0);
                        i.append(a).trigger("change");
                    }),
                    i.trigger({ type: "select2:select", params: { data: e } }));
        });
    }
    t(".row-actions .edit a, .page-title-action, .row-title").on("click", function (a) {
        a.preventDefault();
        var i = 0,
            n = t("#iori_headerfooter_modal"),
            l = t(this).parents(".column-title"),
            o = t("#iori-template-modal-form").attr("data-nonce");
        if ((n.addClass("loading"), n.modal('show'), l.length > 0))
            (i = l.find(".hidden").attr("id").split("_")[1]),
                t.ajax({
                    url: window.iori.resturl + "my-template/get/" + i,
                    type: "get",
                    headers: { "X-WP-Nonce": o },
                    dataType: "json",
                    success: function (t) {
                        e(t), n.removeClass("loading");
                    },
                });
        else {
            e({ title: "", type: "header", condition_a: "entire_site", condition_singular: "all", activation: "" }), n.removeClass("loading");
        }
        n.find("form").attr("data-iori-id", i);
    }),
        t(".iori-template-modalinput-type").on("change", function () {
            var e = t(this).val(),
                a = t(".iori-template-headerfooter-option-container");
            "section" == e ? a.hide() : a.show();
        }),
        t(".iori-template-modalinput-condition_a").on("change", function () {
            var e = t(this).val(),
                a = t(".iori-template-modalinput-condition_singular-container");
            "singular" == e ? a.show() : a.hide();
        }),
        t(".iori-template-modalinput-condition_singular").on("change", function () {
            var e = t(this).val(),
                a = t(".iori-template-modal-condition_singular_id-container");
            "selective" == e ? a.show() : a.hide();
        }),
        t(".iori-template-save-btn-editor").on("click", function () {
            var e = t("#iori-template-modal-form");
            e.attr("data-open-editor", "1"), e.trigger("submit");
        }),
        t("#iori-template-modal-form").on("submit", function (e) {
            e.preventDefault();
            var a = t("#iori_headerfooter_modal");
            a.addClass("loading");
            var i = t(this).serialize(),
                n = t(this).attr("data-iori-id"),
                l = t(this).attr("data-open-editor"),
                o = t(this).attr("data-editor-url"),
                r = t(this).attr("data-nonce");
            t.ajax({
                url: window.iori.resturl + "my-template/update/" + n,
                data: i,
                type: "get",
                headers: { "X-WP-Nonce": r },
                dataType: "json",
                success: function (e) {
                    a.removeClass("loading");
                    var i = t("#post-" + e.data.id);
                    i.length > 0 && (i.find(".column-type").html(e.data.type_html), i.find(".column-condition").html(e.data.cond_text), i.find(".row-title").html(e.data.title).attr("aria-label", e.data.title)),
                        "1" == l ? (window.location.href = o + "?post=" + e.data.id + "&action=elementor") : "0" == n && location.reload();
                },
            });
        }),
        t(".iori-template-modal-condition_singular_id").select2({
            ajax: {
                url: window.iori.resturl + "ajaxselect2/singular_list",
                dataType: "json",
                data: function (t) {
                    return { s: t.term };
                },
            },
            cache: !0,
            placeholder: "--",
            dropdownParent: t("#iori_headerfooter_modal_body"),
        });
    var a = t(".wp-header-end"),
        i = "",
        n = new URL(window.location.href).searchParams.get("iori_type_filter");
    (n = null == n ? "all" : n),
        t.each({ all: "All", header: "Header", footer: "Footer" }, function (t, e) {
            var a = (function (t, e, a) {
                null == a && (a = "");
                var i = new RegExp("\\b(" + e + "=).*?(&|#|$)");
                return t.search(i) >= 0 ? t.replace(i, "$1" + a + "$2") : (t = t.replace(/[?#]$/, "")) + (t.indexOf("?") > 0 ? "&" : "?") + e + "=" + a;
            })(window.location.href, "iori_type_filter", t);
            (i += `\n            <a href="${a}" class="${n == t ? "iori_type_filter_active nav-tab-active" : " "} iori_type_filter_tab_item nav-tab">${e}</a>\n        `), (i += "\n");
        }),
        a.after('<div class="iori_type_filter_tab_container nav-tab-wrapper">' + i + "</div><br/>");
});
