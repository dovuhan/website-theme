<?php

use Iori\Elementor\HeaderFooterBuilder\Activator;
use Iori\Elementor\HeaderFooterBuilder\Init;

do_action( 'iori/template/before_footer' ); ?>
<div class="iori-template-content-footer">
<?php
$template = Activator::template_ids();
echo Init::render_builder_content( $template[1] );
?>
</div>
<?php do_action( 'iori/template/after_footer' ); ?>
<?php wp_footer(); ?>

</body>
</html>
