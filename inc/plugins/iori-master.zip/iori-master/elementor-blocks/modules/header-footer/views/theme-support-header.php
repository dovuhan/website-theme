<?php
use Iori\Elementor\HeaderFooterBuilder\Activator;
use Iori\Elementor\HeaderFooterBuilder\Init;
if ( function_exists( 'iori_is_ajax' ) && ! iori_is_ajax() ) { // for ajaxify
	?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'iori' ); ?></a>

	<?php do_action( 'iori_template_before_header' ); ?>
<header class="iori-header-builder">
	<?php
	$template = Activator::template_ids();
	echo Init::render_builder_content( $template[0] );
	?>
</header>
	<?php do_action( 'iori_template_after_header' );
}
?>
