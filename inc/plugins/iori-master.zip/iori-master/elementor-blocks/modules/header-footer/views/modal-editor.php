<div class="modal fade" id="iori_headerfooter_modal" tabindex="-1" role="dialog"
	aria-labelledby="iori_headerfooter_modalLabel">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<form action="" mathod="get" id="iori-template-modal-form" data-open-editor="0"
			data-editor-url="<?php echo get_admin_url(); ?>" data-nonce="<?php echo wp_create_nonce( 'wp_rest' ); ?>">
			<!-- <input type="hidden" name="post_author" value ="<?php echo get_current_user_id(); ?>"> -->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
							aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="iori_headerfooter_modalLabel"><?php esc_html_e( 'Template Settings', 'iori' ); ?></h4>
				</div>
				<div class="modal-body" id="iori_headerfooter_modal_body">
					<div class="iori-input-group">
						<label class="input-label"><?php esc_html_e( 'Title:', 'iori' ); ?></label>
						<input required type="text" name="title" class="iori-template-modalinput-title form-control">
					</div>
					<br />
					<div class="iori-input-group">
						<label class="input-label"><?php esc_html_e( 'Type:', 'iori' ); ?></label>
						<select name="type" class="iori-template-modalinput-type form-control">
							<option value="header"><?php esc_html_e( 'Header', 'iori' ); ?></option>
							<option value="footer"><?php esc_html_e( 'Footer', 'iori' ); ?></option>
						</select>
					</div>
					<br />

					<div class="iori-template-headerfooter-option-container">
						<div class="iori-input-group">
							<label class="input-label"><?php esc_html_e( 'Conditions:', 'iori' ); ?></label>
							<select name="condition_a" class="iori-template-modalinput-condition_a form-control">
								<option value="entire_site"><?php esc_html_e( 'Entire Site', 'iori' ); ?></option>
								<option value="singular"><?php esc_html_e( 'Singular', 'iori' ); ?></option>
								<option value="archive"><?php esc_html_e( 'Archive', 'iori' ); ?></option>
							</select>
						</div>
						<br>

						<div class="iori-template-modalinput-condition_singular-container">
							<div class="iori-input-group">
								<label class="input-label"></label>
								<select name="condition_singular"
									class="iori-template-modalinput-condition_singular form-control">
									<option value="all"><?php esc_html_e( 'All Singulars', 'iori' ); ?></option>
									<option value="front_page"><?php esc_html_e( 'Front Page', 'iori' ); ?></option>
									<option value="all_posts"><?php esc_html_e( 'All Posts', 'iori' ); ?></option>
									<option value="all_pages"><?php esc_html_e( 'All Pages', 'iori' ); ?></option>
									<option value="selective"><?php esc_html_e( 'Selective Singular', 'iori' ); ?>
									</option>
									<option value="404page"><?php esc_html_e( '404 Page', 'iori' ); ?></option>
								</select>
							</div>
							<br>

							<div class="iori-template-modal-condition_singular_id-container iori_multipile_ajax_search_filed">
								<div class="iori-input-group">
									<label class="input-label"></label>
									<select multiple name="condition_singular_id[]" class="iori-template-modal-condition_singular_id"></select>
								</div>
								<br />
							</div>
							<br>
						</div>


						<div class="iori-switch-group">
							<label class="input-label"><?php esc_html_e( 'Activition:', 'iori' ); ?></label>
							<div class="iori-admin-input-switch">
								<input checked="" type="checkbox" value="yes"
									class="iori-admin-control-input iori-template-modalinput-activition"
									name="activation" id="iori_activation_modal_input">
								<label class="iori-admin-control-label" for="iori_activation_modal_input">
									<span class="iori-admin-control-label-switch" data-active="ON"
										data-inactive="OFF"></span>
								</label>
							</div>
						</div>
					</div>
					<br>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default iori-template-save-btn-editor"><?php esc_html_e( 'Edit with Elementor', 'iori' ); ?></button>
					<button type="submit" class="btn btn-primary iori-template-save-btn"><i class="iori-admin-save-icon fa fa-check-circle"></i><?php esc_html_e( 'Save changes', 'iori' ); ?></button>
				</div>
				<div class="iori-spinner"></div>
			</div>
		</form>
	</div>
</div>
