<?php
namespace Iori\Elementor\HeaderFooterBuilder;

defined( 'ABSPATH' ) || exit;

use Elementor\Plugin;

class Init {

	public $dir;

	public $url;

	public function __construct() {

		// get current directory path
		$this->dir = dirname( __FILE__ ) . '/';

		// get current module's url
		$this->url = IORI_PLG_URL . 'elementor-blocks/modules/header-footer/';

		// enqueue scripts
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		// include all necessary files
		$this->include_files();

		add_action( 'admin_footer', array( $this, 'modal_view' ) );

		// inline script
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_js' ) );
		add_action( 'admin_print_scripts', array( $this, 'admin_js' ) );

		Cpt_Hooks::instance();
		Activator::instance();
	}

	public function include_files() {
		include_once $this->dir . 'cpt.php';
		include_once $this->dir . 'cpt-api.php';
		include_once $this->dir . 'cpt-hooks.php';
		include_once $this->dir . 'activator.php';
		include_once $this->dir . 'hooks/theme-support.php';
	}

	public function modal_view() {
		$screen = get_current_screen();
		if ( $screen->id == 'edit-iori_template' ) {
			include_once $this->dir . 'views/modal-editor.php';
		}
	}

	 // scripts for common end, admin & frontend
	public function common_js() {
		ob_start(); ?>

		var iori = {
			resturl: '<?php echo get_rest_url() . 'iori-master/v1/'; ?>',
		}
		<?php
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}

	// scripts for frontend
	public function frontend_js() {
		$js = $this->common_js();
		wp_add_inline_script( 'iori-master-framework-js-frontend', $js );
	}

	// scripts for admin
	public function admin_js() {
		echo "<script type='text/javascript'>\n";
		echo $this->common_js();
		echo "\n</script>";
	}

	public function enqueue_styles() {
		$screen = get_current_screen();
		if ( $screen->id == 'edit-iori_template' ) {
			wp_enqueue_style( 'select2', $this->url . 'assets/css/select2.min.css', false, 1.0 );
			wp_enqueue_style( 'iori-menu-admin-style', $this->url . 'assets/css/admin-style.css', false, 1.0 );
		}
	}

	public function enqueue_scripts() {
		$screen = get_current_screen();
		if ( $screen->id == 'edit-iori_template' ) {
			wp_enqueue_script( 'select2', $this->url . 'assets/js/select2.min.js', array( 'jquery' ), true, 1.0 );
			wp_enqueue_script( 'iori-menu-admin-script', $this->url . 'assets/js/admin-script.js', array( 'jquery' ), true, 1.0 );
		}
	}

	public static function render_builder_content( $content ) {

		$elementor_instance = Plugin::instance();
		$has_css            = false;

		/**
		 * CSS Print Method Internal and Exteral option support for Header and Footer Builder.
		 */
		if ( ( 'internal' === get_option( 'elementor_css_print_method' ) ) || Plugin::$instance->preview->is_preview_mode() ) {
			$has_css = true;
		}

		return $elementor_instance->frontend->get_builder_content_for_display( $content, $has_css );
	}
}

new Init();
