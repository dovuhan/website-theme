<?php

/**
 * elementors blocks
 *
 * @since 1.0.0
 * @return void
 */
function iori_load_elements() {

	// Notice if the Elementor is not active
	if ( ! did_action( 'elementor/loaded' ) ) {
		add_action( 'admin_notices', 'iori_elementor_fail_load' );
		return;
	}

	// Check version required
	$elementor_version_required = '2.0.0';
	if ( ! version_compare( ELEMENTOR_VERSION, $elementor_version_required, '>=' ) ) {
		add_action( 'admin_notices', 'iori_elementor_is_active' );
		return;
	}

	// Require the main plugin file
	require __DIR__ . '/elementor-blocks.php';   // loading the main plugin
	include_once IORI_PLG_DIR . '/elementor-blocks/modules/header-footer/init.php';

}

add_action( 'plugins_loaded', 'iori_load_elements' );   // notiung but checking and notice

function iori_elementor_fail_load() {
	$message = '<p>' . __( 'Please Install and Active Elementor Plugin First. Iori Theme require Elementor Plugin to work perfectly.', 'iori' ) . '</p>';

	echo '<div class="error">' . $message . '</div>';
}

function iori_elementor_is_active() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	$file_path = 'elementor/elementor.php';

	$upgrade_link = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' ) . $file_path, 'upgrade-plugin_' . $file_path );
	$message      = '<p>' . __( 'Iori Master may not work or is not compatible because you are using an old version of Elementor.', 'iori' ) . '</p>';
	$message     .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $upgrade_link, __( 'Update Elementor Now', 'iori' ) ) . '</p>';

	echo '<div class="error">' . $message . '</div>';
}
