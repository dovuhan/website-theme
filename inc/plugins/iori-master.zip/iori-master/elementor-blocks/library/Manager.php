<?php
namespace Iori\Elementor\Library;

use Elementor\Plugin;
use Elementor\Core\Common\Modules\Ajax\Module as Ajax;

defined( 'ABSPATH' ) || die();

class Manager {


	protected static $source = null;

	public static function init() {
		add_action( 'elementor/editor/footer', array( __CLASS__, 'print_template_views' ) );
		add_action( 'elementor/ajax/register_actions', array( __CLASS__, 'register_ajax_actions' ) );
	}

	public static function print_template_views() {
		include_once IORI_PLG_DIR . '/elementor-blocks/library/templates.php';
	}

	/**
	 * Librabry Source
	 *
	 * @return Source
	 */
	public static function get_source() {
		if ( is_null( self::$source ) ) {
			self::$source = new Source();
		}
		return self::$source;
	}

	/**
	 * Register ajax
	 */
	public static function register_ajax_actions( Ajax $ajax ) {
		$ajax->register_ajax_action(
			'get_iori_library_data',
			function( $data ) {
				if ( ! current_user_can( 'edit_posts' ) ) {
					throw new \Exception( 'Access Denied' );
				}

				if ( ! empty( $data['editor_post_id'] ) ) {
					$editor_post_id = absint( $data['editor_post_id'] );

					if ( ! get_post( $editor_post_id ) ) {
						throw new \Exception( __( 'Post not found.', 'iori' ) );
					}

					Plugin::instance()->db->switch_to_post( $editor_post_id );
				}

				$result = self::get_library_data( $data );

				return $result;
			}
		);

		$ajax->register_ajax_action(
			'get_iori_template_data',
			function( $data ) {
				if ( ! current_user_can( 'edit_posts' ) ) {
					throw new \Exception( 'Access Denied' );
				}

				if ( ! empty( $data['editor_post_id'] ) ) {
					$editor_post_id = absint( $data['editor_post_id'] );

					if ( ! get_post( $editor_post_id ) ) {
						throw new \Exception( __( 'Post not found', 'iori' ) );
					}

					Plugin::instance()->db->switch_to_post( $editor_post_id );
				}

				if ( empty( $data['template_id'] ) ) {
					throw new \Exception( __( 'Template id missing', 'iori' ) );
				}

				$result = self::get_template_data( $data );

				return $result;
			}
		);
	}

	public static function get_template_data( array $args ) {
		$source = self::get_source();
		$data   = $source->get_data( $args );
		return $data;
	}

	/**
	 * Get library data from cache or remote
	 *
	 * type_tags has been added in version 2.15.0
	 *
	 * @param array $args
	 *
	 * @return array
	 */
	public static function get_library_data( array $args ) {
		$source = self::get_source();

		if ( ! empty( $args['sync'] ) ) {
			Source::get_library_data( true );
		}

		return array(
			'templates' => $source->get_items(),
			'tags'      => $source->get_tags(),
			'type_tags' => $source->get_type_tags(),
		);
	}
}

Manager::init();
