<?php

namespace Iori\Master;

use Elementor\Plugin;

class Init {
	protected static $_instance = null;

	public function __construct() {
		add_action( 'init', array( $this, 'register_blocks' ), 1 );
		// $this->register_blocks();

		add_action( 'admin_menu', array( $this, 'cpt_menu' ) );

		// Add shortcode column to block list
		add_filter( 'manage_edit-dy_block_columns', array( $this, 'edit_html_blocks_columns' ) );
		add_action( 'manage_dy_block_posts_custom_column', array( $this, 'manage_html_blocks_columns' ), 10, 2 );

		add_shortcode( 'html_block', array( $this, 'render_shortcode' ) );
	}

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	// **********************************************************************//
	// ! Register Custom Post Type for HTML Blocks
	// **********************************************************************//

	public function register_blocks() {
		$labels = array(
			'name'               => esc_html__( 'Extra Blocks', 'iori' ),
			'singular_name'      => esc_html__( 'Extra Block', 'iori' ),
			'menu_name'          => esc_html__( 'Extra Blocks', 'iori' ),
			'parent_item_colon'  => esc_html__( 'Parent Item:', 'iori' ),
			'all_items'          => esc_html__( 'All Items', 'iori' ),
			'view_item'          => esc_html__( 'View Item', 'iori' ),
			'add_new_item'       => esc_html__( 'Add New Item', 'iori' ),
			'add_new'            => esc_html__( 'Add New', 'iori' ),
			'edit_item'          => esc_html__( 'Edit Item', 'iori' ),
			'update_item'        => esc_html__( 'Update Item', 'iori' ),
			'search_items'       => esc_html__( 'Search Item', 'iori' ),
			'not_found'          => esc_html__( 'Not found', 'iori' ),
			'not_found_in_trash' => esc_html__( 'Not found in Trash', 'iori' ),
		);

		$args = array(
			'label'               => esc_html__( 'dy_block', 'iori' ),
			'description'         => esc_html__( 'CMS Blocks for custom Extra to place in your pages', 'iori' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'editor', 'elementor' ),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => true,
			'menu_position'       => 29,
			'menu_icon'           => 'dashicons-schedule',
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => true,
			'rewrite'             => false,
			'capability_type'     => 'page',
		);

		register_post_type( 'dy_block', $args );
	}

	public function cpt_menu() {
		$link_our_new_cpt = 'edit.php?post_type=dy_block';
		add_submenu_page( 'iori', esc_html__( 'Mega Menu', 'iori' ), esc_html__( 'Mega Menu', 'iori' ), 'manage_options', $link_our_new_cpt, '', 1000 );
	}

	public function edit_html_blocks_columns( $columns ) {
		$columns = array(
			'cb'        => '<input type="checkbox" />',
			'title'     => esc_html__( 'Title', 'iori' ),
			'shortcode' => esc_html__( 'Shortcode', 'iori' ),
			'date'      => esc_html__( 'Date', 'iori' ),
		);

		return $columns;
	}

	public function manage_html_blocks_columns( $column, $post_id ) {
		switch ( $column ) {
			case 'shortcode':
				echo '<strong>[html_block id="' . $post_id . '"]</strong>';
				break;
		}
	}

	public function render_shortcode( $atts ) {
		extract(
			shortcode_atts(
				array(
					'id' => 0,
				),
				$atts
			)
		);

		if ( did_action( 'elementor/loaded' ) ) {
			$inline_css = apply_filters( 'iori_elementor_content_inline_css', true );

			$content = Plugin::$instance->frontend->get_builder_content_for_display( $id, $inline_css );

			if ( $inline_css ) {
				wp_deregister_style( 'elementor-post-' . $id );
				wp_dequeue_style( 'elementor-post-' . $id );
			}
		} else {
			$content = do_shortcode( $post->post_content );
		}

		return $content;
	}
}

// Init();
function Iori_Theme_Plugin() {
	return Init::instance();
}

$GLOBALS['iori_theme_plugin'] = Iori_Theme_Plugin();
