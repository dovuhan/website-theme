<?php

namespace Iori\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/*
 - Path define same as class name of the widget
====================================================================================================*/

use Elementor\Plugin;
use Iori\Widgets\Logo;
use Iori\Widgets\Header;
use Iori\Widgets\Nav_Menu;
use Iori\Widgets\Accordion;
use Iori\Widgets\Accordion_Two;
use Iori\Widgets\Account_Box;
use Iori\Widgets\Account_Box_Two;
use Iori\Widgets\Animated_Image;
use Iori\Widgets\Banner;
use Iori\Widgets\Banner_Two;
use Iori\Widgets\Banner_Three;
use Iori\Widgets\Banner_Four;
use Iori\Widgets\Banner_Five;
use Iori\Widgets\Banner_Six;
use Iori\Widgets\Banner_Seven;
use Iori\Widgets\Banner_Eight;
use Iori\Widgets\Banner_Nine;
use Iori\Widgets\Banner_Ten;
use Iori\Widgets\Banner_Eleven;
use Iori\Widgets\Banner_Twelve;
use Iori\Widgets\Banner_Thirteen;
use Iori\Widgets\Banner_Fourteen;
use Iori\Widgets\FeaturedPost;
use Iori\Widgets\Blog_Two;
use Iori\Widgets\Blog;
use Iori\Widgets\Brand;
use Iori\Widgets\Brand_Two;
use Iori\Widgets\Button;
use Iori\Widgets\Button_Group;
use Iori\Widgets\Button_Group_Two;
use Iori\Widgets\Button_Group_Three;
use Iori\Widgets\FilterTabs;
use Iori\Widgets\Brand_Slider;
use Iori\Widgets\Card;
use Iori\Widgets\Card_Two;
use Iori\Widgets\Card_Three;
use Iori\Widgets\Card_Four;
use Iori\Widgets\Card_Five;
use Iori\Widgets\Card_Small;
use Iori\Widgets\Card_Six;
use Iori\Widgets\Card_Seven;
use Iori\Widgets\Card_Eight;
use Iori\Widgets\Contact_Info;
use Iori\Widgets\Content;
use Iori\Widgets\Content_Item;
use Iori\Widgets\Content_Two;
use Iori\Widgets\Content_Box;
use Iori\Widgets\Content_Box_Two;
use Iori\Widgets\Content_Box_Three;
use Iori\Widgets\Counter;
use Iori\Widgets\Counter_Two;
use Iori\Widgets\Counter_Three;
use Iori\Widgets\Counter_Four;
use Iori\Widgets\Job_Listing;
use Iori\Widgets\Top_Content;
use Iori\Widgets\Gallery;
use Iori\Widgets\Gallery_Two;
use Iori\Widgets\Gallery_Three;
use Iori\Widgets\Gallery_Four;
use Iori\Widgets\Gallery_Five;
use Iori\Widgets\Member;
use Iori\Widgets\Newsletter;
use Iori\Widgets\Newsletter_Two;
use Iori\Widgets\Portfolio;
use Iori\Widgets\Price;
use Iori\Widgets\Price_Two;
use Iori\Widgets\Price_Table;
use Iori\Widgets\List_Table;
use Iori\Widgets\Tabs;
use Iori\Widgets\Tabs_Two;
use Iori\Widgets\Tabs_Three;
use Iori\Widgets\Tabs_Four;
use Iori\Widgets\Team;
use Iori\Widgets\Testimonial;
use Iori\Widgets\Testimonial_Two;
use Iori\Widgets\Testimonial_Three;
use Iori\Widgets\Testimonial_Four;
use Iori\Widgets\Testimonial_Five;
use Iori\Widgets\Sub_Title;
use Iori\Widgets\Search_Box;
use Iori\Widgets\Section_Title;
use Iori\Widgets\Service_Banner;
use Iori\Widgets\Slider;
use Iori\Widgets\Slider_Two;
use Iori\Widgets\Slider_Three;
use Iori\Widgets\Slider_Four;
use Iori\Widgets\Product;
use Iori\Widgets\Video_Popup;
use Iori\Widgets\Video_Popup_Two;
use Iori\Widgets\Login;
use Iori\Widgets\Register;
use Iori\Widgets\Reviews;

/*
 - End Of path define same as class name of the widget
====================================================================================================*/

function iori_insert_elementor( $atts ) {

	$post_id  = $atts['id'];
	$response = Plugin::instance()->frontend->get_builder_content_for_display( $post_id );
	return $response;
}

add_shortcode( 'IORI_ELEMENTOR', '\Iori\iori_insert_elementor' );



// Add a custom category for panel widgets
add_action(
	'elementor/init',
	function () {
		Plugin::$instance->elements_manager->add_category(
			'iori-master-elements',                 // the name of the category
			array(
				'title' => __( 'Iori', 'iori' ),
				'icon'  => 'fa fa-header', // default icon
			),
			5 // position
		);
	}
);




/**
 * Main Plugin Class
 *
 * Register new elementor widget.
 *
 * @since 1.0.0
 */
class Iori_Elementor {


	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */

	public function __construct() {
		 // $this->library();
		$this->add_actions();
	}

	/**
	 * Include library files
	 */
	public function library() {
		if ( is_user_logged_in() ) {
			include_once IORI_PLG_DIR . '/elementor-blocks/library/Manager.php';
			include_once IORI_PLG_DIR . '/elementor-blocks/library/Source.php';
		}
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function add_actions() {
		add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'enqueue_custom_admin_style' ), 999 );
		add_action( 'elementor/frontend/after_enqueue_styles', array( $this, 'enqueue_custom_frontend_style' ), 999 );

		add_action( 'elementor/widgets/register', array( $this, 'widgets_registered' ) );

		// editor scripts
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'editor_enqueue' ) );
	}


	public function enqueue_custom_admin_style() {
		wp_enqueue_style( 'iori-admin-style', plugins_url( '/assets/css/elementor-styles.css', __FILE__ ), false, '1.0.0' );
	}

	public function enqueue_custom_frontend_style() {
		wp_enqueue_style( 'iori-frontend-style', plugins_url( '/assets/css/frontend-styles.css', __FILE__ ), false, '1.0.0' );
	}


	public function editor_enqueue() {
		// wp_enqueue_script( 'iori-elementor-editor', plugins_url( '/assets/js/editor.js', __FILE__ ), array('elementor-editor', 'jquery'), '1.0.0', true );

		$localize_data = array(
			'placeholder_widgets' => array(),
			'hasPro'              => $this->is_has_pro(),
			'editor_nonce'        => wp_create_nonce( 'iori_editor_nonce' ),
			'i18n'                => array(
				'promotionDialogHeader'     => esc_html__( '%s Widget', 'iori' ),
				'promotionDialogMessage'    => esc_html__( 'Use %s widget with other exclusive pro widgets and 100% unique features to extend your toolbox and build sites faster and better.', 'iori' ),
				'templatesEmptyTitle'       => esc_html__( 'Currently no templates found', 'iori' ),
				'templatesEmptyMessage'     => esc_html__( 'Try different category or sync for new templates.', 'iori' ),
				'templatesNoResultsTitle'   => esc_html__( 'No Results Found', 'iori' ),
				'templatesNoResultsMessage' => esc_html__( 'Please make sure your search correctly or try a different words.', 'iori' ),
			),
		);

		wp_localize_script(
			'iori-elementor-editor',
			'IoriEditor',
			$localize_data
		);
	}


	// pro version
	public function is_has_pro() {
		return defined( 'IORI_PRO_VERSION' );
	}

	/**
	 * On Widgets Registered
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function widgets_registered() {
		$this->widgets_includes();
		$this->register_widget();
	}

	/**
	 * Includes
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function widgets_includes() {
		
		$void_widgets = array_map( 'basename', glob( dirname( __FILE__ ) . '/widgets/*.php' ) );
		// include the widgets here
		foreach ( $void_widgets as $key => $value ) {
			require __DIR__ . '/widgets/' . $value;
		}
	}



	/*
	 - Register all elements widget
	====================================================================================================*/

	/**
	 * Register Widget
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function register_widget() {
		Plugin::instance()->widgets_manager->register( new Logo() );
		Plugin::instance()->widgets_manager->register( new Header() );
		Plugin::instance()->widgets_manager->register( new Nav_Menu() );
		Plugin::instance()->widgets_manager->register( new Accordion() );
		Plugin::instance()->widgets_manager->register( new Accordion_Two() );
		Plugin::instance()->widgets_manager->register( new Account_Box() );
		Plugin::instance()->widgets_manager->register( new Account_Box_Two() );
		Plugin::instance()->widgets_manager->register( new Animated_Image() );
		Plugin::instance()->widgets_manager->register( new Banner() );
		Plugin::instance()->widgets_manager->register( new Banner_Two() );
		Plugin::instance()->widgets_manager->register( new Banner_Three() );
		Plugin::instance()->widgets_manager->register( new Banner_Four() );
		Plugin::instance()->widgets_manager->register( new Banner_Five() );
		Plugin::instance()->widgets_manager->register( new Banner_Six() );
		Plugin::instance()->widgets_manager->register( new Banner_Seven() );
		Plugin::instance()->widgets_manager->register( new Banner_Eight() );
		Plugin::instance()->widgets_manager->register( new Banner_Nine() );
		Plugin::instance()->widgets_manager->register( new Banner_Ten() );
		Plugin::instance()->widgets_manager->register( new Banner_Eleven() );
		Plugin::instance()->widgets_manager->register( new Banner_Twelve() );
		Plugin::instance()->widgets_manager->register( new Banner_Thirteen() );
		Plugin::instance()->widgets_manager->register( new Banner_Fourteen() );
		Plugin::instance()->widgets_manager->register( new FeaturedPost() );
		Plugin::instance()->widgets_manager->register( new Blog_Two() );
		Plugin::instance()->widgets_manager->register( new Blog() );
		Plugin::instance()->widgets_manager->register( new Brand() );
		Plugin::instance()->widgets_manager->register( new Brand_Two() );
		Plugin::instance()->widgets_manager->register( new Button() );
		Plugin::instance()->widgets_manager->register( new Button_Group() );
		Plugin::instance()->widgets_manager->register( new Button_Group_Two() );
		Plugin::instance()->widgets_manager->register( new Button_Group_Three() );
		Plugin::instance()->widgets_manager->register( new FilterTabs() );
		Plugin::instance()->widgets_manager->register( new Brand_Slider() );
		Plugin::instance()->widgets_manager->register( new Card() );
		Plugin::instance()->widgets_manager->register( new Card_Two() );
		Plugin::instance()->widgets_manager->register( new Card_Three() );
		Plugin::instance()->widgets_manager->register( new Card_Four() );
		Plugin::instance()->widgets_manager->register( new Card_Five() );
		Plugin::instance()->widgets_manager->register( new Card_Small() );
		Plugin::instance()->widgets_manager->register( new Card_Six() );
		Plugin::instance()->widgets_manager->register( new Card_Seven() );
		Plugin::instance()->widgets_manager->register( new Card_Eight() );
		Plugin::instance()->widgets_manager->register( new Contact_Info() );
		Plugin::instance()->widgets_manager->register( new Content() );
		Plugin::instance()->widgets_manager->register( new Content_Item() );
		Plugin::instance()->widgets_manager->register( new Content_Two() );
		Plugin::instance()->widgets_manager->register( new Content_Box() );
		Plugin::instance()->widgets_manager->register( new Content_Box_Two() );
		Plugin::instance()->widgets_manager->register( new Content_Box_Three() );
		Plugin::instance()->widgets_manager->register( new Counter() );
		Plugin::instance()->widgets_manager->register( new Counter_Two() );
		Plugin::instance()->widgets_manager->register( new Counter_Three() );
		Plugin::instance()->widgets_manager->register( new Counter_Four() );
		Plugin::instance()->widgets_manager->register( new Job_Listing() );
		Plugin::instance()->widgets_manager->register( new Top_Content() );
		Plugin::instance()->widgets_manager->register( new Gallery() );
		Plugin::instance()->widgets_manager->register( new Gallery_Two() );
		Plugin::instance()->widgets_manager->register( new Gallery_Three() );
		Plugin::instance()->widgets_manager->register( new Gallery_Four() );
		Plugin::instance()->widgets_manager->register( new Gallery_Five() );
		Plugin::instance()->widgets_manager->register( new Search_Box() );
		Plugin::instance()->widgets_manager->register( new Section_Title() );
		Plugin::instance()->widgets_manager->register( new Service_Banner() );
		Plugin::instance()->widgets_manager->register( new Slider() );
		Plugin::instance()->widgets_manager->register( new Slider_Two() );
		Plugin::instance()->widgets_manager->register( new Slider_Three() );
		Plugin::instance()->widgets_manager->register( new Slider_Four() );
		Plugin::instance()->widgets_manager->register( new Portfolio());
		Plugin::instance()->widgets_manager->register( new Price() );
		Plugin::instance()->widgets_manager->register( new Price_Two() );
		Plugin::instance()->widgets_manager->register( new Price_Table() );
		Plugin::instance()->widgets_manager->register( new List_Table() );
		Plugin::instance()->widgets_manager->register( new Product() );
		Plugin::instance()->widgets_manager->register( new Video_Popup() );
		Plugin::instance()->widgets_manager->register( new Video_Popup_Two() );
		Plugin::instance()->widgets_manager->register( new Team() );
		Plugin::instance()->widgets_manager->register( new Testimonial() );
		Plugin::instance()->widgets_manager->register( new Testimonial_Two() );
		Plugin::instance()->widgets_manager->register( new Testimonial_Three() );
		Plugin::instance()->widgets_manager->register( new Testimonial_Four() );
		Plugin::instance()->widgets_manager->register( new Testimonial_Five() );
		Plugin::instance()->widgets_manager->register( new Tabs() );
		Plugin::instance()->widgets_manager->register( new Tabs_Two() );
		Plugin::instance()->widgets_manager->register( new Tabs_Three() );
		Plugin::instance()->widgets_manager->register( new Tabs_Four() );
		Plugin::instance()->widgets_manager->register( new Member() );
		Plugin::instance()->widgets_manager->register( new Newsletter() );
		Plugin::instance()->widgets_manager->register( new Newsletter_Two() );
		Plugin::instance()->widgets_manager->register( new Sub_Title() );
		Plugin::instance()->widgets_manager->register( new Login() );
		Plugin::instance()->widgets_manager->register( new Register() );
		Plugin::instance()->widgets_manager->register( new Reviews() );
	}
}

new Iori_Elementor();
