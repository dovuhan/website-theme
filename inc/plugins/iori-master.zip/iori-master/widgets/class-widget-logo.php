<?php
if ( ! function_exists( 'iori_widget_init' ) ) {

	function iori_widget_init() {
		register_widget( 'Iori_Logo_Info_Widget' );
		register_widget( 'Iori_Recent_Post' );
		register_widget( 'Iori_Widget_Layered_Nav' );
	}

	add_action( 'widgets_init', 'iori_widget_init', 2 );
}

/*
  ============================================================================================================================*/
/*
   - Brand logo Widget
  /*============================================================================================================================*/
if ( ! class_exists( 'Iori_Logo_Info_Widget' ) ) {
	class Iori_Logo_Info_Widget extends Iori_WPH_Widget {
	

		function __construct() { 
			$widget_ops = array(
				'classname'   => 'iori_logo_info_widget',
				'description' => 'Logo Widget.',
			);

			parent::__construct( 'iori_logo_info_widget', 'Iori:: Logo info', $widget_ops );
		}

		function widget( $args, $instance ) {

			extract( $args );

			echo $before_widget;

			?>
			<div class="footer-content">
				<?php if ( ! empty( $instance['iori_footer_logo'] ) ) { ?>
					<img class="mb-20" src="<?php echo esc_url( $instance['iori_footer_logo'] ); ?>" alt="">
				<?php } ?>
				<?php if ( ! empty( $instance['iori_logo_copywrite'] ) ) { ?>
					<p class="font-md mb-20 color-grey-400"><?php echo wp_kses_post( $instance['iori_logo_copywrite'] ); ?></p>
				<?php } ?>

				<?php if ( ! empty( $instance['start_end_time'] ) ) { ?>
					<div class="font-md mb-20 color-grey-400"><?php echo wp_kses_post( $instance['start_end_time'] ); ?></div>
				<?php } ?>

				<?php if ( $instance['iori_social_link'] ) { ?>
					<h6 class="color-brand-1">Follow Us</h6>
				<?php } ?>
				<div class="mt-15">
					<a href="<?php echo esc_url( $instance['iori_social_link'] ); ?>"><span class="<?php echo esc_attr( $instance['iori_social_icon'] ); ?>"></span></a>
					<a href="<?php echo esc_url( $instance['iori_social_link2'] ); ?>"><span class="<?php echo esc_attr( $instance['iori_social_icon2'] ); ?>"></span></a>
					<a href="<?php echo esc_url( $instance['iori_social_link3'] ); ?>"><span class="<?php echo esc_attr( $instance['iori_social_icon3'] ); ?>"></span></a>
					<a href="<?php echo esc_url( $instance['iori_social_link4'] ); ?>"><span class="<?php echo esc_attr( $instance['iori_social_icon4'] ); ?>"></span></a>
					<a href="<?php echo esc_url( $instance['iori_social_link5'] ); ?>"><span class="<?php echo esc_attr( $instance['iori_social_icon5'] ); ?>"></span></a>
				</div>
			</div>

			<?php
			echo $after_widget;
		}

		function update( $new_instance, $old_instance ) {

			$instance                        = $old_instance;
			$instance['title']               = $new_instance['title'];
			$instance['iori_footer_logo']    = $new_instance['iori_footer_logo'];
			$instance['iori_logo_copywrite'] = $new_instance['iori_logo_copywrite'];
			$instance['start_end_time']      = $new_instance['start_end_time'];
			$instance['iori_social_link']    = $new_instance['iori_social_link'];
			$instance['iori_social_icon']    = $new_instance['iori_social_icon'];
			$instance['iori_social_link2']   = $new_instance['iori_social_link2'];
			$instance['iori_social_icon2']   = $new_instance['iori_social_icon2'];
			$instance['iori_social_link3']   = $new_instance['iori_social_link3'];
			$instance['iori_social_icon3']   = $new_instance['iori_social_icon3'];
			$instance['iori_social_link4']   = $new_instance['iori_social_link4'];
			$instance['iori_social_icon4']   = $new_instance['iori_social_icon4'];
			$instance['iori_social_link5']   = $new_instance['iori_social_link5'];
			$instance['iori_social_icon5']   = $new_instance['iori_social_icon5'];

			return $instance;
		}

		function form( $instance ) {

			//
			// Title Field Defaults
			// -------------------------------------------------
			$instance = wp_parse_args(
				$instance,
				array(
					'title'               => 'Iori',
					'iori_footer_logo'    => IORI_PLG_URL . 'framework/assets/images/logo.png',
					'iori_logo_copywrite' => '',
					'start_end_time'      => '',
					'iori_social_link'    => '#',
					'iori_social_icon'    => '',
					'iori_social_link2'   => '#',
					'iori_social_icon2'   => '',
					'iori_social_link3'   => '#',
					'iori_social_icon3'   => '',
					'iori_social_link4'   => '#',
					'iori_social_icon4'   => '',
					'iori_social_link5'   => '#',
					'iori_social_icon5'   => '',
				)
			);

			//
			// Title Field
			// -------------------------------------------------
			$text_value = esc_attr( $instance['title'] );
			$text_field = array(
				'id'    => $this->get_field_name( 'title' ),
				'name'  => $this->get_field_name( 'title' ),
				'type'  => 'text',
				'title' => 'Title',
			);

			echo iori_add_element( $text_field, $text_value );

			//
			// apps one Logo Upload
			// -------------------------------------------------
			$iori_footer_logo_value = esc_attr( $instance['iori_footer_logo'] );
			$iori_footer_logo_field = array(
				'id'    => $this->get_field_name( 'iori_footer_logo' ),
				'name'  => $this->get_field_name( 'iori_footer_logo' ),
				'type'  => 'upload',
				'title' => 'Logo Image',
			);

			echo iori_add_element( $iori_footer_logo_field, $iori_footer_logo_value );

			//
			// apps one link
			// -------------------------------------------------
			$iori_logo_copywrite_value = esc_attr( $instance['iori_logo_copywrite'] );
			$iori_logo_copywrite_field = array(
				'id'    => $this->get_field_name( 'iori_logo_copywrite' ),
				'name'  => $this->get_field_name( 'iori_logo_copywrite' ),
				'type'  => 'textarea',
				'title' => 'Text',
			);

			echo iori_add_element( $iori_logo_copywrite_field, $iori_logo_copywrite_value );

			//
			// start end time
			// -------------------------------------------------
			$start_end_time_value = esc_attr( $instance['start_end_time'] );
			$start_end_time_field = array(
				'id'    => $this->get_field_name( 'start_end_time' ),
				'name'  => $this->get_field_name( 'start_end_time' ),
				'type'  => 'textarea',
				'title' => 'Text',
			);

			echo iori_add_element( $start_end_time_field, $start_end_time_value );


			$iori_social_link_value = esc_attr( $instance['iori_social_link'] );
			$iori_social_link_field = array(
				'id'    => $this->get_field_name( 'iori_social_link' ),
				'name'  => $this->get_field_name( 'iori_social_link' ),
				'type'  => 'text',
				'title' => 'Social Link',
			);

			echo iori_add_element( $iori_social_link_field, $iori_social_link_value );

			$iori_social_icon_value = esc_attr( $instance['iori_social_icon'] );
			$iori_social_icon_field = array(
				'id'    => $this->get_field_name( 'iori_social_icon' ),
				'name'  => $this->get_field_name( 'iori_social_icon' ),
				'type'  => 'icon',
				'title' => 'Social Icon',
			);

			echo iori_add_element( $iori_social_icon_field, $iori_social_icon_value );

			$iori_social_link2_value = esc_attr( $instance['iori_social_link2'] );
			$iori_social_link2_field = array(
				'id'    => $this->get_field_name( 'iori_social_link2' ),
				'name'  => $this->get_field_name( 'iori_social_link2' ),
				'type'  => 'text',
				'title' => 'Social Link 2',
			);

			echo iori_add_element( $iori_social_link2_field, $iori_social_link2_value );

			$iori_social_icon2_value = esc_attr( $instance['iori_social_icon2'] );
			$iori_social_icon2_field = array(
				'id'    => $this->get_field_name( 'iori_social_icon2' ),
				'name'  => $this->get_field_name( 'iori_social_icon2' ),
				'type'  => 'icon',
				'title' => 'Social Icon 2',
			);

			echo iori_add_element( $iori_social_icon2_field, $iori_social_icon2_value );

			$iori_social_link3_value = esc_attr( $instance['iori_social_link3'] );
			$iori_social_link3_field = array(
				'id'    => $this->get_field_name( 'iori_social_link3' ),
				'name'  => $this->get_field_name( 'iori_social_link3' ),
				'type'  => 'text',
				'title' => 'Social Link 3',
			);

			echo iori_add_element( $iori_social_link3_field, $iori_social_link3_value );

			$iori_social_icon3_value = esc_attr( $instance['iori_social_icon3'] );
			$iori_social_icon3_field = array(
				'id'    => $this->get_field_name( 'iori_social_icon3' ),
				'name'  => $this->get_field_name( 'iori_social_icon3' ),
				'type'  => 'icon',
				'title' => 'Social Icon 3',
			);

			echo iori_add_element( $iori_social_icon3_field, $iori_social_icon3_value );

			$iori_social_link4_value = esc_attr( $instance['iori_social_link4'] );
			$iori_social_link4_field = array(
				'id'    => $this->get_field_name( 'iori_social_link4' ),
				'name'  => $this->get_field_name( 'iori_social_link4' ),
				'type'  => 'text',
				'title' => 'Social Link 4',
			);

			echo iori_add_element( $iori_social_link4_field, $iori_social_link4_value );

			$iori_social_icon4_value = esc_attr( $instance['iori_social_icon4'] );
			$iori_social_icon4_field = array(
				'id'    => $this->get_field_name( 'iori_social_icon4' ),
				'name'  => $this->get_field_name( 'iori_social_icon4' ),
				'type'  => 'icon',
				'title' => 'Social Icon 4',
			);

			echo iori_add_element( $iori_social_icon4_field, $iori_social_icon4_value );

			$iori_social_link5_value = esc_attr( $instance['iori_social_link5'] );
			$iori_social_link5_field = array(
				'id'    => $this->get_field_name( 'iori_social_link5' ),
				'name'  => $this->get_field_name( 'iori_social_link5' ),
				'type'  => 'text',
				'title' => 'Social Link 5',
			);

			echo iori_add_element( $iori_social_link5_field, $iori_social_link5_value );

			$iori_social_icon5_value = esc_attr( $instance['iori_social_icon5'] );
			$iori_social_icon5_field = array(
				'id'    => $this->get_field_name( 'iori_social_icon5' ),
				'name'  => $this->get_field_name( 'iori_social_icon5' ),
				'type'  => 'icon',
				'title' => 'Social Icon 5',
			);

			echo iori_add_element( $iori_social_icon5_field, $iori_social_icon5_value );
		}
	}
}
