<?php

/**
 * one click demo
 */
class Iori_OneClickDemo {

	public $minimum_capability = 'manage_options';

	/**
	 * load intially
	 */
	public function __construct() {
		 add_action( 'admin_menu', array( $this, 'admin_menus' ) );

		add_action( 'admin_enqueue_scripts', array( $this, 'iori_plugin_scripts' ) );

		// ajax
		add_action( 'wp_ajax_nopriv_iori_ajax_import_options', array( $this, 'iori_ajax_import_options' ) );
		add_action( 'wp_ajax_iori_ajax_import_options', array( $this, 'iori_ajax_import_options' ) );

	}

	/**
	 * register style
	 */
	public function iori_plugin_scripts() {
		wp_enqueue_style( 'importer-styles', IORI_PLG_URL . 'demo-importer/engine/css/style.css', false, false, 'all' );
	}

	/**
	 * Register the Admin Pages
	 *
	 * @since 1.0
	 * @return string
	 */
	public function admin_menus() {

		add_menu_page(
			'iori',
			'Iori',
			'manage_options',
			'iori',
			array( $this, 'iori' ),
			'',
			100
		);

		add_submenu_page(
			'iori',
			__( 'Theme Option', 'iori' ),
			__( 'Theme Option', 'iori' ),
			$this->minimum_capability,
			'iori',
			'',
			10
		);

		// quick install
		add_submenu_page(
			'iori',
			__( 'Quick Install', 'iori' ),
			__( 'Quick Install', 'iori' ),
			$this->minimum_capability,
			'demo-importer',
			array( $this, '_load_demo_content_page' )
		);

	}

	public function iori() {
		// echo 'echo';
	}

	public function _load_demo_content_page() {
		include_once IORI_PLG_DIR . '/demo-importer/engine/index.php';
	}

	// ajax import option
	public function iori_ajax_import_options() {
		include_once IORI_PLG_DIR . '/demo-importer/engine/content_importer.php';
		parse_str( $_POST['options'], $options );
		if ( ! empty( $options['template'] ) ) {
			$content_importer = new ContentImporter( $_POST['options'] );
			$content_importer->import();
			$options['template'] = '';
		}
	}
}

new Iori_OneClickDemo();
